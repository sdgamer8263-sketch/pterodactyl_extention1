<?php

use Illuminate\Support\Facades\Route;
use Pterodactyl\BlueprintFramework\Extensions\pluginbrowser\PluginController;

Route::post('/download/modrinth', [PluginController::class, 'downloadModrinth'])->name('extension.pluginbrowser.download.modrinth');
Route::post('/download/spigot',   [PluginController::class, 'downloadSpigot'])->name('extension.pluginbrowser.download.spigot');
Route::post('/download/hangar',   [PluginController::class, 'downloadHangar'])->name('extension.pluginbrowser.download.hangar');
