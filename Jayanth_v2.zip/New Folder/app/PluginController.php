<?php

namespace Pterodactyl\BlueprintFramework\Extensions\pluginbrowser;

use Illuminate\Http\Request;
use Pterodactyl\Models\Server;
use Illuminate\Support\Facades\Http;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Repositories\Wings\DaemonFileRepository;
use Pterodactyl\Exceptions\Http\Connection\DaemonConnectionException;

class PluginController extends Controller
{
    private DaemonFileRepository $fileRepository;

    public function __construct(DaemonFileRepository $fileRepository)
    {
        $this->fileRepository = $fileRepository;
    }

    /**
     * Download a plugin from Modrinth (direct CDN URL).
     */
    public function downloadModrinth(Request $request)
    {
        $request->validate([
            'downloadUrl' => 'required|url',
            'filename'    => 'required|string|ends_with:.jar',
            'serverUuid'  => 'required|string|exists:servers,uuid',
        ]);

        $server = Server::where('uuid', $request->input('serverUuid'))->firstOrFail();
        $this->authorize('file.create', $server);

        try {
            $response = Http::withHeaders([
                'User-Agent' => 'PluginBrowser/1.0 (Pterodactyl)',
            ])->withOptions(['allow_redirects' => true])->get($request->input('downloadUrl'));

            if (!$response->successful()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Failed to download from Modrinth. HTTP ' . $response->status(),
                ], 502);
            }

            $content = $response->body();

            if (strlen($content) < 4 || substr($content, 0, 2) !== 'PK') {
                return response()->json([
                    'success' => false,
                    'message' => 'Downloaded file is not a valid JAR.',
                ], 422);
            }

            $path = '/plugins/' . $request->input('filename');
            $this->fileRepository->setServer($server)->putContent($path, $content);

            return response()->json(['success' => true, 'path' => $path]);

        } catch (DaemonConnectionException $ex) {
            return response()->json(['success' => false, 'message' => 'Daemon connection failed.', 'error' => $ex->getMessage()], 500);
        } catch (\Exception $ex) {
            return response()->json(['success' => false, 'message' => $ex->getMessage()], 500);
        }
    }

    /**
     * Download a plugin from SpigotMC via Spiget API.
     * Spiget returns a redirect — we follow it with cURL to get the actual JAR.
     */
    public function downloadSpigot(Request $request)
    {
        $request->validate([
            'resourceId' => 'required|integer',
            'versionId'  => 'nullable|integer',
            'filename'   => 'required|string|ends_with:.jar',
            'serverUuid' => 'required|string|exists:servers,uuid',
        ]);

        $server = Server::where('uuid', $request->input('serverUuid'))->firstOrFail();
        $this->authorize('file.create', $server);

        $resourceId = (int) $request->input('resourceId');
        $versionId  = $request->input('versionId');

        // Build Spiget download URL
        if ($versionId && (int)$versionId > 0) {
            $spigetUrl = "https://api.spiget.org/v2/resources/{$resourceId}/versions/{$versionId}/download";
        } else {
            $spigetUrl = "https://api.spiget.org/v2/resources/{$resourceId}/download";
        }

        try {
            $content = $this->downloadWithCurl($spigetUrl);

            if ($content === false || strlen($content) < 4) {
                return response()->json([
                    'success' => false,
                    'message' => 'Failed to download from SpigotMC. The plugin may be premium or externally hosted.',
                ], 502);
            }

            // Validate JAR (PK magic bytes)
            if (substr($content, 0, 2) !== 'PK') {
                return response()->json([
                    'success' => false,
                    'message' => 'Downloaded file is not a valid JAR. This plugin may be premium (requires SpigotMC account) or externally hosted.',
                ], 422);
            }

            $path = '/plugins/' . $request->input('filename');
            $this->fileRepository->setServer($server)->putContent($path, $content);

            return response()->json(['success' => true, 'path' => $path]);

        } catch (DaemonConnectionException $ex) {
            return response()->json(['success' => false, 'message' => 'Daemon connection failed.', 'error' => $ex->getMessage()], 500);
        } catch (\Exception $ex) {
            return response()->json(['success' => false, 'message' => $ex->getMessage()], 500);
        }
    }

    /**
     * Download a plugin from Hangar (PaperMC's official plugin repository).
     * Uses Hangar API v1 — no authentication required for public plugins.
     */
    public function downloadHangar(Request $request)
    {
        $request->validate([
            'author'      => 'required|string',
            'slug'        => 'required|string',
            'version'     => 'required|string',
            'platform'    => 'required|string|in:PAPER,WATERFALL,VELOCITY',
            'filename'    => 'required|string|ends_with:.jar',
            'serverUuid'  => 'required|string|exists:servers,uuid',
        ]);

        $server = Server::where('uuid', $request->input('serverUuid'))->firstOrFail();
        $this->authorize('file.create', $server);

        $author   = $request->input('author');
        $slug     = $request->input('slug');
        $version  = $request->input('version');
        $platform = strtoupper($request->input('platform'));

        // Hangar download URL
        $hangarUrl = "https://hangar.papermc.io/api/v1/projects/{$author}/{$slug}/versions/{$version}/{$platform}/download";

        try {
            $content = $this->downloadWithCurl($hangarUrl);

            if ($content === false || strlen($content) < 4) {
                return response()->json([
                    'success' => false,
                    'message' => 'Failed to download from Hangar. The plugin version may not be available.',
                ], 502);
            }

            // Validate JAR (PK magic bytes)
            if (substr($content, 0, 2) !== 'PK') {
                return response()->json([
                    'success' => false,
                    'message' => 'Downloaded file is not a valid JAR.',
                ], 422);
            }

            $path = '/plugins/' . $request->input('filename');
            $this->fileRepository->setServer($server)->putContent($path, $content);

            return response()->json(['success' => true, 'path' => $path]);

        } catch (DaemonConnectionException $ex) {
            return response()->json(['success' => false, 'message' => 'Daemon connection failed.', 'error' => $ex->getMessage()], 500);
        } catch (\Exception $ex) {
            return response()->json(['success' => false, 'message' => $ex->getMessage()], 500);
        }
    }

    /**
     * Download a URL using cURL, following all redirects.
     * Returns file content as string, or false on failure.
     */
    private function downloadWithCurl(string $url): string|false
    {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 10,
            CURLOPT_TIMEOUT        => 60,
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_USERAGENT      => 'PluginBrowser/1.0 (Pterodactyl)',
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_HTTPHEADER     => [
                'Accept: application/octet-stream, application/java-archive, */*',
            ],
        ]);

        $content  = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error    = curl_error($ch);
        curl_close($ch);

        if ($content === false || !empty($error) || $httpCode < 200 || $httpCode >= 400) {
            return false;
        }

        return $content;
    }
}
