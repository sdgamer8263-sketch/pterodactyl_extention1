import React, { useEffect, useState, useCallback, useRef, useMemo } from 'react';
import { ServerContext } from '@/state/server';
import http from '@/api/http';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
    faSearch, faSlidersH, faDownload, faClock, faSpinner,
    faTimes, faCube, faChevronDown, faExclamationTriangle,
    faCheck, faExternalLinkAlt, faTag, faFire,
} from '@fortawesome/free-solid-svg-icons';
import debounce from 'lodash-es/debounce';
import tw from 'twin.macro';
import styled from 'styled-components/macro';

// ─── Types ────────────────────────────────────────────────────────────────────

type Platform = 'modrinth' | 'spigotmc' | 'hangar';
type InstallStatus = 'idle' | 'loading' | 'done' | 'error';

interface UnifiedPlugin {
    id: string;
    platform: Platform;
    title: string;
    description: string;
    author: string;
    downloads: number;
    rating: number;
    iconUrl: string;
    categories: string[];
    dateUpdated: string;
    premium: boolean;
    external: boolean;
    testedVersions: string[];
    // Hangar-specific
    namespace?: { owner: string; slug: string };
}

interface UnifiedVersion {
    id: string;
    name: string;
    type: 'release' | 'beta' | 'alpha';
    datePublished: string;
    downloads: number;
    files: { url: string; filename: string; size: number }[];
    gameVersions: string[];
    loaders: string[];
    // Hangar-specific
    hangarPlatforms?: string[];
}

interface DropdownOption { id: string; name: string; }

// ─── Styled components ────────────────────────────────────────────────────────

const platformColor = (p: Platform, alpha = 1) => {
    if (p === 'modrinth')  return `rgba(30,215,96,${alpha})`;
    if (p === 'spigotmc')  return `rgba(234,88,12,${alpha})`;
    if (p === 'hangar')    return `rgba(0,185,255,${alpha})`;
    return `rgba(99,102,241,${alpha})`;
};
const platformText = (p: Platform) => {
    if (p === 'modrinth')  return 'rgb(74,222,128)';
    if (p === 'spigotmc')  return 'rgb(251,146,60)';
    if (p === 'hangar')    return 'rgb(56,211,255)';
    return 'white';
};

const Panel = styled.div`
    ${tw`rounded-2xl p-6 mb-6`};
    background: rgba(15, 23, 42, 0.6);
    backdrop-filter: blur(14px);
    border: 1px solid rgba(255, 255, 255, 0.07);
    box-shadow: 0 4px 24px rgba(0,0,0,0.25);
`;

const Card = styled.div<{ platform: Platform }>`
    ${tw`rounded-xl p-5 cursor-pointer transition-all duration-300 relative overflow-hidden`};
    background: rgba(15, 23, 42, 0.45);
    border: 1px solid rgba(255, 255, 255, 0.06);
    &:hover {
        background: rgba(15, 23, 42, 0.75);
        border-color: ${p => platformColor(p.platform, 0.4)};
        transform: translateY(-3px);
        box-shadow: 0 12px 28px rgba(0,0,0,0.3);
    }
`;

const PlatformBadge = styled.span<{ platform: Platform }>`
    ${tw`text-xs px-2 py-0.5 rounded-full font-bold tracking-wide`};
    background: ${p => platformColor(p.platform, 0.15)};
    color: ${p => platformText(p.platform)};
    border: 1px solid ${p => platformColor(p.platform, 0.3)};
`;

const CategoryBadge = styled.span`
    ${tw`text-xs px-2 py-0.5 rounded-full font-medium`};
    background: rgba(99,102,241,0.15);
    color: rgb(165,180,252);
`;

const DropdownWrap = styled.div`${tw`relative w-full`}`;

const DropBtn = styled.button`
    ${tw`w-full text-neutral-300 text-sm rounded-xl p-2.5 outline-none flex items-center justify-between transition-all`};
    background: rgba(15,23,42,0.6);
    border: 1px solid rgba(255,255,255,0.09);
    &:focus { border-color: rgba(99,102,241,0.6); box-shadow: 0 0 0 2px rgba(99,102,241,0.15); }
`;

const DropMenu = styled.div`
    ${tw`absolute z-50 w-full mt-2 rounded-xl overflow-hidden shadow-2xl`};
    background: rgba(10,15,30,0.98);
    border: 1px solid rgba(255,255,255,0.08);
    backdrop-filter: blur(16px);
    max-height: 240px;
    overflow-y: auto;
    &::-webkit-scrollbar { width: 4px; }
    &::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.08); border-radius: 2px; }
`;

const DropItem = styled.div<{ active: boolean }>`
    ${tw`px-4 py-2.5 text-sm cursor-pointer transition-colors`};
    background: ${p => p.active ? 'rgba(99,102,241,0.18)' : 'transparent'};
    color: ${p => p.active ? 'white' : 'rgb(156,163,175)'};
    &:hover { background: rgba(255,255,255,0.05); color: white; }
`;

const PlatTab = styled.button<{ active: boolean; plat: Platform }>`
    ${tw`px-5 py-2.5 rounded-xl font-semibold text-sm transition-all flex items-center gap-2.5`};
    background: ${p => p.active ? platformColor(p.plat, 0.18) : 'rgba(15,23,42,0.5)'};
    color: ${p => p.active ? platformText(p.plat) : 'rgb(107,114,128)'};
    border: 1px solid ${p => p.active ? platformColor(p.plat, 0.35) : 'rgba(255,255,255,0.06)'};
    &:hover { color: white; }
`;

const InstallBtn = styled.button<{ status: InstallStatus; platform: Platform }>`
    ${tw`px-4 py-2 rounded-lg text-sm font-semibold text-white flex items-center gap-2 transition-all whitespace-nowrap`};
    background: ${p =>
        p.status === 'done'    ? 'rgba(22,163,74,0.85)' :
        p.status === 'error'   ? 'rgba(220,38,38,0.75)' :
        p.status === 'loading' ? 'rgba(99,102,241,0.5)' :
        platformColor(p.platform, 0.25)};
    border: 1px solid ${p =>
        p.status === 'done'  ? 'rgba(22,163,74,0.5)'  :
        p.status === 'error' ? 'rgba(220,38,38,0.5)'  :
        platformColor(p.platform, 0.4)};
    color: ${p => p.status === 'idle' ? platformText(p.platform) : 'white'};
    opacity: ${p => p.status === 'loading' ? 0.7 : 1};
    cursor: ${p => p.status === 'loading' || p.status === 'done' ? 'not-allowed' : 'pointer'};
    &:hover:not(:disabled) { filter: brightness(1.2); }
`;

// ─── Dropdown ─────────────────────────────────────────────────────────────────

const Dropdown = ({ value, options, onChange, placeholder = 'All' }: {
    value: string; options: DropdownOption[]; onChange: (v: string) => void; placeholder?: string;
}) => {
    const [open, setOpen] = useState(false);
    const ref = useRef<HTMLDivElement>(null);
    const active = useMemo(() => options.find(o => o.id === value), [value, options]);

    useEffect(() => {
        const fn = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false); };
        document.addEventListener('mousedown', fn);
        return () => document.removeEventListener('mousedown', fn);
    }, []);

    return (
        <DropdownWrap ref={ref} style={{ zIndex: open ? 50 : undefined }}>
            <DropBtn type='button' onClick={() => setOpen(o => !o)}>
                <span className={active ? 'text-white' : 'text-neutral-500'}>{active?.name ?? placeholder}</span>
                <FontAwesomeIcon icon={faChevronDown} className={`text-xs text-neutral-500 transition-transform ${open ? 'rotate-180' : ''}`} />
            </DropBtn>
            {open && (
                <DropMenu>
                    {options.map(o => (
                        <DropItem key={o.id} active={o.id === value} onClick={() => { onChange(o.id); setOpen(false); }}>
                            {o.name}
                        </DropItem>
                    ))}
                </DropMenu>
            )}
        </DropdownWrap>
    );
};

// ─── Constants ────────────────────────────────────────────────────────────────

const MODRINTH_CATEGORIES: DropdownOption[] = [
    { id: 'adventure', name: 'Adventure' }, { id: 'economy', name: 'Economy' },
    { id: 'game-mechanics', name: 'Game Mechanics' }, { id: 'library', name: 'Library' },
    { id: 'magic', name: 'Magic' }, { id: 'management', name: 'Management' },
    { id: 'minigame', name: 'Minigame' }, { id: 'mobs', name: 'Mobs' },
    { id: 'optimization', name: 'Optimization' }, { id: 'social', name: 'Social' },
    { id: 'storage', name: 'Storage' }, { id: 'technology', name: 'Technology' },
    { id: 'transportation', name: 'Transportation' }, { id: 'utility', name: 'Utility' },
    { id: 'worldgen', name: 'World Generation' },
];

const SPIGOT_CATEGORIES: DropdownOption[] = [
    { id: '4', name: 'Spigot' }, { id: '2', name: 'Bungee - Spigot' },
    { id: '6', name: 'Chat' }, { id: '7', name: 'Tools & Utilities' },
    { id: '8', name: 'Misc' }, { id: '9', name: 'Libraries / APIs' },
    { id: '11', name: 'Anti-Griefing' }, { id: '13', name: 'Admin Tools' },
    { id: '17', name: 'Economy' }, { id: '18', name: 'Game Mode' },
    { id: '22', name: 'World Management' }, { id: '23', name: 'Mechanics' },
    { id: '24', name: 'Fun' }, { id: '27', name: 'Skript' },
];

const HANGAR_CATEGORIES: DropdownOption[] = [
    { id: 'ADMIN_TOOLS', name: 'Admin Tools' }, { id: 'CHAT', name: 'Chat' },
    { id: 'DEV_TOOLS', name: 'Dev Tools' }, { id: 'ECONOMY', name: 'Economy' },
    { id: 'ENTERTAINMENT', name: 'Entertainment' }, { id: 'FOOD', name: 'Food' },
    { id: 'GAME', name: 'Game' }, { id: 'LANGUAGE', name: 'Language' },
    { id: 'MOBS', name: 'Mobs' }, { id: 'OPTIMIZATION', name: 'Optimization' },
    { id: 'PERMISSION', name: 'Permission' }, { id: 'REGION_MANAGEMENT', name: 'Region Management' },
    { id: 'ROLE_PLAYING', name: 'Role Playing' }, { id: 'WORLD_MANAGEMENT', name: 'World Management' },
    { id: 'MISC', name: 'Misc' },
];

const HANGAR_PLATFORMS: DropdownOption[] = [
    { id: 'PAPER', name: 'Paper' }, { id: 'WATERFALL', name: 'Waterfall' }, { id: 'VELOCITY', name: 'Velocity' },
];

const MODRINTH_LOADERS: DropdownOption[] = ['paper','purpur','spigot','bukkit','folia','velocity','waterfall','bungeecord']
    .map(l => ({ id: l, name: l }));

const MODRINTH_SORT: DropdownOption[] = [
    { id: 'relevance', name: 'Relevance' }, { id: 'downloads', name: 'Downloads' },
    { id: 'follows', name: 'Follows' }, { id: 'newest', name: 'Newest' }, { id: 'updated', name: 'Updated' },
];

const SPIGOT_SORT: DropdownOption[] = [
    { id: '-downloads', name: 'Most Downloaded' }, { id: '-updateDate', name: 'Recently Updated' },
    { id: '-releaseDate', name: 'Newest' }, { id: '-rating', name: 'Top Rated' },
];

const HANGAR_SORT: DropdownOption[] = [
    { id: 'downloads', name: 'Most Downloaded' }, { id: 'newest', name: 'Newest' },
    { id: 'stars', name: 'Most Starred' }, { id: 'updated', name: 'Recently Updated' },
    { id: 'recent_downloads', name: 'Recent Downloads' },
];

const PAGE_SIZE = 12;

// ─── API helpers ──────────────────────────────────────────────────────────────

async function searchModrinth(
    q: string, page: number,
    filters: { category: string; loader: string; sort: string }
): Promise<{ plugins: UnifiedPlugin[]; total: number }> {
    const facets = [['project_type:plugin']];
    if (filters.category) facets.push([`categories:${filters.category}`]);
    if (filters.loader)   facets.push([`categories:${filters.loader}`]);

    const params = new URLSearchParams({
        facets: JSON.stringify(facets),
        limit: PAGE_SIZE.toString(),
        offset: (page * PAGE_SIZE).toString(),
        index: filters.sort || 'relevance',
    });
    if (q.trim()) params.append('query', q.trim());

    const res  = await fetch(`https://api.modrinth.com/v2/search?${params}`);
    const data = await res.json();

    return {
        total: data.total_hits ?? 0,
        plugins: (data.hits ?? []).map((p: any): UnifiedPlugin => ({
            id: p.project_id, platform: 'modrinth',
            title: p.title, description: p.description, author: p.author,
            downloads: p.downloads, rating: 0, iconUrl: p.icon_url ?? '',
            categories: p.categories ?? [], dateUpdated: p.date_modified,
            premium: false, external: false, testedVersions: [],
        })),
    };
}

async function searchSpigot(
    q: string, page: number,
    filters: { category: string; sort: string }
): Promise<{ plugins: UnifiedPlugin[]; total: number }> {
    const pageNum = page + 1;
    let url: string;
    if (q.trim()) {
        url = `https://api.spiget.org/v2/search/resources/${encodeURIComponent(q.trim())}?field=name&size=${PAGE_SIZE}&page=${pageNum}&sort=${filters.sort || '-downloads'}`;
    } else if (filters.category) {
        url = `https://api.spiget.org/v2/categories/${filters.category}/resources?size=${PAGE_SIZE}&page=${pageNum}&sort=${filters.sort || '-downloads'}`;
    } else {
        url = `https://api.spiget.org/v2/resources?size=${PAGE_SIZE}&page=${pageNum}&sort=${filters.sort || '-downloads'}`;
    }
    const res  = await fetch(url);
    const data = await res.json();
    const arr  = Array.isArray(data) ? data : [];
    return {
        total: 999,
        plugins: arr.map((p: any): UnifiedPlugin => ({
            id: p.id.toString(), platform: 'spigotmc',
            title: p.name, description: p.tag ?? '',
            author: p.author?.name ?? 'Unknown',
            downloads: p.downloads ?? 0,
            rating: p.rating?.average ?? 0,
            iconUrl: p.icon?.url ? `https://www.spigotmc.org/${p.icon.url}` : '',
            categories: p.category ? [p.category.name ?? 'Plugin'] : ['Plugin'],
            dateUpdated: p.updateDate ? new Date(p.updateDate * 1000).toISOString() : '',
            premium: p.premium ?? false, external: p.external ?? false,
            testedVersions: p.testedVersions ?? [],
        })),
    };
}

async function searchHangar(
    q: string, page: number,
    filters: { category: string; platform: string; sort: string }
): Promise<{ plugins: UnifiedPlugin[]; total: number }> {
    const params = new URLSearchParams({
        limit: PAGE_SIZE.toString(),
        offset: (page * PAGE_SIZE).toString(),
        sort: filters.sort || 'downloads',
    });
    if (q.trim())          params.append('query', q.trim());
    if (filters.category)  params.append('category', filters.category);
    if (filters.platform)  params.append('platform', filters.platform);

    const res  = await fetch(`https://hangar.papermc.io/api/v1/projects?${params}`, {
        headers: { 'User-Agent': 'PluginBrowser/1.0' },
    });
    const data = await res.json();
    const results = data.result ?? [];

    return {
        total: data.pagination?.count ?? results.length,
        plugins: results.map((p: any): UnifiedPlugin => ({
            id: `${p.namespace.owner}/${p.namespace.slug}`,
            platform: 'hangar',
            title: p.name,
            description: p.description ?? '',
            author: p.namespace.owner,
            downloads: p.stats?.downloads ?? 0,
            rating: 0,
            iconUrl: p.avatarUrl ?? '',
            categories: p.category ? [p.category] : [],
            dateUpdated: p.lastUpdated ?? '',
            premium: false,
            external: false,
            testedVersions: [],
            namespace: { owner: p.namespace.owner, slug: p.namespace.slug },
        })),
    };
}

async function fetchModrinthVersions(id: string): Promise<UnifiedVersion[]> {
    const res  = await fetch(`https://api.modrinth.com/v2/project/${id}/version`);
    const data = await res.json();
    return (data ?? []).map((v: any): UnifiedVersion => ({
        id: v.id, name: v.name, type: v.version_type,
        datePublished: v.date_published, downloads: v.downloads,
        files: (v.files ?? []).map((f: any) => ({ url: f.url, filename: f.filename, size: f.size ?? 0 })),
        gameVersions: v.game_versions ?? [], loaders: v.loaders ?? [],
    }));
}

async function fetchSpigotVersions(id: string): Promise<UnifiedVersion[]> {
    const res  = await fetch(`https://api.spiget.org/v2/resources/${id}/versions?size=20&sort=-releaseDate`);
    const data = await res.json();
    const arr  = Array.isArray(data) ? data : [];

    const versions: UnifiedVersion[] = [];
    arr.forEach((v: any) => {
        const vid = parseInt(v.id?.toString() ?? '0');
        if (!vid || vid <= 0) return;
        versions.push({
            id: vid.toString(),
            name: v.name || `v${vid}`,
            type: 'release',
            datePublished: v.releaseDate ? new Date(v.releaseDate * 1000).toISOString() : '',
            downloads: 0,
            files: [{ url: `https://api.spiget.org/v2/resources/${id}/versions/${vid}/download`, filename: '', size: 0 }],
            gameVersions: [], loaders: ['spigot','paper','bukkit'],
        });
    });

    versions.unshift({
        id: '0', name: 'Latest (auto)', type: 'release', datePublished: '',
        downloads: 0,
        files: [{ url: `https://api.spiget.org/v2/resources/${id}/download`, filename: '', size: 0 }],
        gameVersions: [], loaders: ['spigot','paper','bukkit'],
    });

    return versions;
}

async function fetchHangarVersions(owner: string, slug: string): Promise<UnifiedVersion[]> {
    const res  = await fetch(
        `https://hangar.papermc.io/api/v1/projects/${owner}/${slug}/versions?limit=20&offset=0`,
        { headers: { 'User-Agent': 'PluginBrowser/1.0' } }
    );
    const data = await res.json();
    const results = data.result ?? [];

    return results.map((v: any): UnifiedVersion => {
        const platformKeys = Object.keys(v.downloads ?? {});
        const files = platformKeys.map((plat: string) => ({
            url: `https://hangar.papermc.io/api/v1/projects/${owner}/${slug}/versions/${encodeURIComponent(v.name)}/${plat}/download`,
            filename: '',
            size: 0,
        }));
        return {
            id: v.name,
            name: v.name,
            type: v.channel?.name?.toLowerCase() === 'release' ? 'release' : 'beta',
            datePublished: v.createdAt ?? '',
            downloads: v.stats?.totalDownloads ?? 0,
            files,
            gameVersions: v.platformDependencies?.PAPER ?? v.platformDependencies?.WATERFALL ?? [],
            loaders: platformKeys.map((k: string) => k.toLowerCase()),
            hangarPlatforms: platformKeys,
        };
    });
}

// ─── Main Component ───────────────────────────────────────────────────────────

export default () => {
    const server = ServerContext.useStoreState(s => s.server.data);

    const [platform, setPlatform]     = useState<Platform>('modrinth');
    const [query, setQuery]           = useState('');
    const [showFilters, setShowFilters] = useState(false);
    const [mFilters, setMFilters]     = useState({ category: '', loader: '', sort: 'relevance' });
    const [sFilters, setSFilters]     = useState({ category: '', sort: '-downloads' });
    const [hFilters, setHFilters]     = useState({ category: '', platform: 'PAPER', sort: 'downloads' });

    const [plugins, setPlugins]       = useState<UnifiedPlugin[]>([]);
    const [total, setTotal]           = useState(0);
    const [page, setPage]             = useState(0);
    const [loading, setLoading]       = useState(false);
    const [hasMore, setHasMore]       = useState(true);

    const [selected, setSelected]     = useState<UnifiedPlugin | null>(null);
    const [versions, setVersions]     = useState<UnifiedVersion[]>([]);
    const [loadingVer, setLoadingVer] = useState(false);
    const [vFilter, setVFilter]       = useState({ gameVersion: '', loader: '', type: '' });
    const [installState, setInstallState] = useState<Record<string, InstallStatus>>({});
    const [installErrors, setInstallErrors] = useState<Record<string, string>>({});

    // ── Search ──────────────────────────────────────────────────────────────

    const doSearch = useCallback(async (q: string, pg: number) => {
        setLoading(true);
        try {
            let result: { plugins: UnifiedPlugin[]; total: number };
            if (platform === 'modrinth') {
                result = await searchModrinth(q, pg, mFilters);
            } else if (platform === 'spigotmc') {
                result = await searchSpigot(q, pg, sFilters);
            } else {
                result = await searchHangar(q, pg, hFilters);
            }
            setPlugins(result.plugins);
            setTotal(result.total);
            setHasMore(result.plugins.length === PAGE_SIZE);
        } catch (e) {
            console.error(e);
            setPlugins([]);
        } finally {
            setLoading(false);
        }
    }, [platform, mFilters, sFilters, hFilters]);

    const debounced = useCallback(debounce((q: string) => {
        setPage(0);
        doSearch(q, 0);
    }, 550), [doSearch]);

    useEffect(() => { debounced(query); }, [query, mFilters, sFilters, hFilters, platform]);

    useEffect(() => {
        if (page > 0) doSearch(query, page);
    }, [page]);

    useEffect(() => {
        setQuery('');
        setPage(0);
        setMFilters({ category: '', loader: '', sort: 'relevance' });
        setSFilters({ category: '', sort: '-downloads' });
        setHFilters({ category: '', platform: 'PAPER', sort: 'downloads' });
    }, [platform]);

    // ── Versions ────────────────────────────────────────────────────────────

    const openPlugin = async (p: UnifiedPlugin) => {
        setSelected(p);
        setVersions([]);
        setLoadingVer(true);
        setInstallState({});
        setInstallErrors({});
        setVFilter({ gameVersion: '', loader: '', type: '' });
        try {
            let v: UnifiedVersion[];
            if (p.platform === 'modrinth') {
                v = await fetchModrinthVersions(p.id);
            } else if (p.platform === 'spigotmc') {
                v = await fetchSpigotVersions(p.id);
            } else {
                const ns = p.namespace ?? { owner: p.author, slug: p.id.split('/')[1] ?? p.id };
                v = await fetchHangarVersions(ns.owner, ns.slug);
            }
            setVersions(v);
        } catch (e) { console.error(e); }
        finally { setLoadingVer(false); }
    };

    // ── Install ─────────────────────────────────────────────────────────────

    const install = async (plugin: UnifiedPlugin, version: UnifiedVersion) => {
        if (!server) return;
        const key = version.id;

        setInstallState(s => ({ ...s, [key]: 'loading' }));
        setInstallErrors(s => { const n = { ...s }; delete n[key]; return n; });

        const safe = (s: string) => s.replace(/[^a-zA-Z0-9._-]/g, '_');

        try {
            if (plugin.platform === 'modrinth') {
                const file = version.files.find(f => f.filename.endsWith('.jar')) ?? version.files[0];
                if (!file || !file.url) throw new Error('No downloadable JAR file found for this version.');
                await http.post('/extensions/pluginbrowser/download/modrinth', {
                    downloadUrl: file.url,
                    filename:    file.filename || `${safe(plugin.title)}-${safe(version.name)}.jar`,
                    serverUuid:  server.uuid,
                });
            } else if (plugin.platform === 'spigotmc') {
                const versionId = parseInt(version.id);
                await http.post('/extensions/pluginbrowser/download/spigot', {
                    resourceId:  parseInt(plugin.id),
                    versionId:   isNaN(versionId) || versionId <= 0 ? null : versionId,
                    filename:    `${safe(plugin.title)}-${safe(version.name)}.jar`,
                    serverUuid:  server.uuid,
                });
            } else {
                // Hangar
                const ns = plugin.namespace ?? { owner: plugin.author, slug: plugin.id.split('/')[1] ?? plugin.id };
                // Pick first available platform (prefer PAPER)
                const hangarPlatform = version.hangarPlatforms?.includes('PAPER') ? 'PAPER'
                    : version.hangarPlatforms?.[0] ?? 'PAPER';
                await http.post('/extensions/pluginbrowser/download/hangar', {
                    author:      ns.owner,
                    slug:        ns.slug,
                    version:     version.name,
                    platform:    hangarPlatform,
                    filename:    `${safe(plugin.title)}-${safe(version.name)}.jar`,
                    serverUuid:  server.uuid,
                });
            }
            setInstallState(s => ({ ...s, [key]: 'done' }));
        } catch (e: any) {
            console.error(e);
            const msg: string =
                e?.response?.data?.message ||
                e?.message ||
                'Install failed. This plugin may be premium or externally hosted.';
            setInstallState(s => ({ ...s, [key]: 'error' }));
            setInstallErrors(s => ({ ...s, [key]: msg }));
        }
    };

    // ── Helpers ─────────────────────────────────────────────────────────────

    const fmt = (n: number) =>
        n >= 1_000_000 ? `${(n/1_000_000).toFixed(1)}M`
        : n >= 1_000   ? `${(n/1_000).toFixed(1)}k`
        : String(n);

    const filteredVersions = useMemo(() => versions.filter(v => {
        if (vFilter.gameVersion && !v.gameVersions.includes(vFilter.gameVersion)) return false;
        if (vFilter.loader && !v.loaders.includes(vFilter.loader)) return false;
        if (vFilter.type && v.type !== vFilter.type) return false;
        return true;
    }), [versions, vFilter]);

    const allGameVersions = useMemo(() =>
        [...new Set(versions.flatMap(v => v.gameVersions))].sort().reverse(), [versions]);
    const allLoaders = useMemo(() =>
        [...new Set(versions.flatMap(v => v.loaders))], [versions]);

    const currentCategories = platform === 'modrinth' ? MODRINTH_CATEGORIES
        : platform === 'spigotmc' ? SPIGOT_CATEGORIES
        : HANGAR_CATEGORIES;
    const currentSort = platform === 'modrinth' ? MODRINTH_SORT
        : platform === 'spigotmc' ? SPIGOT_SORT
        : HANGAR_SORT;
    const currentFilters = platform === 'modrinth' ? mFilters
        : platform === 'spigotmc' ? sFilters
        : hFilters;
    const setCurrentFilters = platform === 'modrinth'
        ? (f: any) => setMFilters(prev => ({ ...prev, ...f }))
        : platform === 'spigotmc'
        ? (f: any) => setSFilters(prev => ({ ...prev, ...f }))
        : (f: any) => setHFilters(prev => ({ ...prev, ...f }));

    // ── Render ───────────────────────────────────────────────────────────────

    return (
        <div className='min-h-screen text-neutral-200' style={{ background: 'linear-gradient(135deg, #070b14 0%, #0d1424 100%)' }}>
            <div className='max-w-7xl mx-auto p-4 md:p-8'>

                {/* ── Header ── */}
                <Panel className='flex flex-col md:flex-row justify-between items-center gap-5'>
                    <div className='flex items-center gap-4'>
                        <div className='w-12 h-12 rounded-xl flex items-center justify-center'
                             style={{ background: 'rgba(99,102,241,0.15)', border: '1px solid rgba(99,102,241,0.3)' }}>
                            <FontAwesomeIcon icon={faCube} className='text-2xl text-indigo-400' />
                        </div>
                        <div>
                            <h1 className='text-2xl font-bold text-white tracking-tight'>Jayanth Plugin</h1>
                            <p className='text-neutral-500 text-sm'>Modrinth · SpigotMC · Hangar — one-click install to /plugins/</p>
                        </div>
                    </div>

                    {/* Platform tabs */}
                    <div className='flex gap-2 flex-wrap justify-center'>
                        <PlatTab active={platform === 'modrinth'} plat='modrinth' onClick={() => setPlatform('modrinth')}>
                            <svg viewBox='0 0 512 514' className='w-4 h-4' fill='currentColor'>
                                <path d='M503.16 323.56C514.55 281.47 515.32 235.91 503.2 190.76C466.57 54.2299 326.04 -26.8001 189.33 9.77991C83.8101 38.0199 11.3899 128.07 0.689941 230.47H43.99C54.29 147.33 113.74 74.7298 199.75 51.7098C306.05 23.2598 415.13 80.6699 453.17 181.38L411.03 192.65C391.64 145.8 352.57 111.45 306.3 96.8198L298.56 140.66C335.09 154.13 364.72 184.5 375.56 224.91C391.36 283.8 361.94 344.14 308.56 369.17L320.09 412.16C390.25 383.21 432.4 310.3 422.43 235.14L464.41 223.91C468.91 252.62 467.35 281.16 460.55 308.07L503.16 323.56Z'/>
                            </svg>
                            Modrinth
                        </PlatTab>
                        <PlatTab active={platform === 'spigotmc'} plat='spigotmc' onClick={() => setPlatform('spigotmc')}>
                            <svg viewBox='0 0 24 24' className='w-4 h-4' fill='currentColor'>
                                <path d='M13.606 23.333c1.97-1.127 3.553-2.95 4.97-4.707 3.033-3.76 1.76-10.274-1.28-12.727-2.733-2.147-3.693-1.073-4.14-1.073-.447 0-1.407-1.074-4.14 1.073-3.04 2.453-4.314 8.967-1.28 12.727 1.413 1.76 3 3.6 4.97 4.707.24.126.66.126.9.006v-.006Zm-.553-15.68c.533.4 1.253.307 1.633.007.247-.194.254-.38.007-.58-.58-.46-1.547-.46-2.126 0-.247.2-.24.386.006.58.38.3 1.1.4 1.633-.007-.353-.273-.86-.273-1.213 0 .02-.02.046-.033.06-.033.012 0 .04.013.06.033-.147.113-.374.113-.52-.007v.007Z'/>
                            </svg>
                            SpigotMC
                        </PlatTab>
                        <PlatTab active={platform === 'hangar'} plat='hangar' onClick={() => setPlatform('hangar')}>
                            <svg viewBox='0 0 24 24' className='w-4 h-4' fill='currentColor'>
                                <path d='M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5'/>
                            </svg>
                            Hangar
                        </PlatTab>
                    </div>
                </Panel>

                {/* ── Search bar ── */}
                <Panel className='!py-4'>
                    <div className='flex gap-3'>
                        <div className='relative flex-1'>
                            <FontAwesomeIcon icon={faSearch} className='absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-600 text-sm' />
                            <input
                                value={query}
                                onChange={e => setQuery(e.target.value)}
                                placeholder={
                                    platform === 'modrinth' ? 'Search Modrinth plugins...' :
                                    platform === 'spigotmc' ? 'Search SpigotMC plugins...' :
                                    'Search Hangar (PaperMC) plugins...'
                                }
                                className='w-full text-sm rounded-xl pl-10 pr-4 py-2.5 outline-none text-neutral-200 placeholder-neutral-600 transition-all'
                                style={{ background: 'rgba(15,23,42,0.7)', border: '1px solid rgba(255,255,255,0.07)' }}
                            />
                        </div>
                        <button
                            onClick={() => setShowFilters(f => !f)}
                            className='px-4 py-2.5 rounded-xl text-sm font-medium flex items-center gap-2 transition-all'
                            style={{
                                background: showFilters ? 'rgba(99,102,241,0.2)' : 'rgba(15,23,42,0.6)',
                                border: `1px solid ${showFilters ? 'rgba(99,102,241,0.4)' : 'rgba(255,255,255,0.07)'}`,
                                color: showFilters ? 'rgb(165,180,252)' : 'rgb(107,114,128)',
                            }}
                        >
                            <FontAwesomeIcon icon={faSlidersH} />
                            <span className='hidden sm:inline'>Filters</span>
                        </button>
                    </div>
                </Panel>

                {/* ── Filters ── */}
                {showFilters && (
                    <Panel className='relative z-20'>
                        <div className='grid grid-cols-1 md:grid-cols-3 gap-5'>
                            <div>
                                <label className='block mb-2 text-xs font-semibold text-neutral-400 uppercase tracking-widest'>Category</label>
                                <Dropdown
                                    value={currentFilters.category}
                                    options={[{ id: '', name: 'All Categories' }, ...currentCategories]}
                                    onChange={val => setCurrentFilters({ category: val })}
                                />
                            </div>
                            {platform === 'modrinth' && (
                                <div>
                                    <label className='block mb-2 text-xs font-semibold text-neutral-400 uppercase tracking-widest'>Loader</label>
                                    <Dropdown
                                        value={mFilters.loader}
                                        options={[{ id: '', name: 'All Loaders' }, ...MODRINTH_LOADERS]}
                                        onChange={val => setMFilters(f => ({ ...f, loader: val }))}
                                    />
                                </div>
                            )}
                            {platform === 'hangar' && (
                                <div>
                                    <label className='block mb-2 text-xs font-semibold text-neutral-400 uppercase tracking-widest'>Platform</label>
                                    <Dropdown
                                        value={hFilters.platform}
                                        options={[{ id: '', name: 'All Platforms' }, ...HANGAR_PLATFORMS]}
                                        onChange={val => setHFilters(f => ({ ...f, platform: val }))}
                                    />
                                </div>
                            )}
                            <div>
                                <label className='block mb-2 text-xs font-semibold text-neutral-400 uppercase tracking-widest'>Sort By</label>
                                <Dropdown
                                    value={currentFilters.sort}
                                    options={currentSort}
                                    onChange={val => setCurrentFilters({ sort: val })}
                                />
                            </div>
                        </div>
                    </Panel>
                )}

                {/* ── Results ── */}
                {loading ? (
                    <div className='flex items-center justify-center py-24'>
                        <div className='w-12 h-12 border-4 rounded-full animate-spin'
                             style={{ borderColor: 'rgba(99,102,241,0.2)', borderTopColor: 'rgb(99,102,241)' }}/>
                    </div>
                ) : (
                    <>
                        <div className='mb-4 flex items-center justify-between'>
                            <p className='text-neutral-600 text-sm'>
                                Showing <span className='text-neutral-400 font-medium'>{plugins.length}</span> of {total.toLocaleString()} plugins
                            </p>
                            <PlatformBadge platform={platform}>
                                {platform === 'modrinth' ? 'Modrinth' : platform === 'spigotmc' ? 'SpigotMC' : 'Hangar'}
                            </PlatformBadge>
                        </div>

                        <div className='grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5 mb-8'>
                            {plugins.map(p => (
                                <Card key={`${p.platform}-${p.id}`} platform={p.platform} onClick={() => openPlugin(p)}>
                                    <div className='flex gap-3 mb-3'>
                                        {p.iconUrl ? (
                                            <img src={p.iconUrl} alt={p.title}
                                                 className='w-14 h-14 rounded-xl object-cover flex-shrink-0'
                                                 onError={e => { (e.target as HTMLImageElement).style.display='none'; }} />
                                        ) : (
                                            <div className='w-14 h-14 rounded-xl flex items-center justify-center flex-shrink-0'
                                                 style={{ background: platformColor(p.platform, 0.1) }}>
                                                <FontAwesomeIcon icon={faCube}
                                                    className='text-2xl' style={{ color: platformText(p.platform) }} />
                                            </div>
                                        )}
                                        <div className='flex-1 min-w-0'>
                                            <div className='flex items-start justify-between gap-1 mb-0.5'>
                                                <h3 className='text-sm font-bold text-white truncate'>{p.title}</h3>
                                                {p.premium && (
                                                    <span className='text-[10px] px-1.5 py-0.5 rounded font-bold uppercase flex-shrink-0'
                                                          style={{ background: 'rgba(234,179,8,0.18)', color: 'rgb(250,204,21)' }}>
                                                        Pro
                                                    </span>
                                                )}
                                            </div>
                                            <p className='text-neutral-500 text-xs truncate'>{p.author}</p>
                                            {p.rating > 0 && (
                                                <span className='text-xs' style={{ color: 'rgb(251,191,36)' }}>
                                                    {'★'.repeat(Math.round(p.rating))}{'☆'.repeat(5 - Math.round(p.rating))}
                                                </span>
                                            )}
                                        </div>
                                    </div>

                                    <p className='text-neutral-500 text-xs mb-3 line-clamp-2 leading-relaxed'>
                                        {p.description || 'No description available.'}
                                    </p>

                                    <div className='flex flex-wrap gap-1.5 mb-3'>
                                        {p.categories.slice(0,2).map(c => <CategoryBadge key={c}>{c}</CategoryBadge>)}
                                        {p.testedVersions.slice(0,2).map(v => (
                                            <span key={v} className='text-xs px-2 py-0.5 rounded-full'
                                                  style={{ background: 'rgba(51,65,85,0.5)', color: 'rgb(100,116,139)' }}>
                                                {v}
                                            </span>
                                        ))}
                                    </div>

                                    <div className='flex justify-between items-center text-xs pt-3'
                                         style={{ borderTop: '1px solid rgba(255,255,255,0.05)', color: 'rgb(71,85,105)' }}>
                                        <span className='flex items-center gap-1'>
                                            <FontAwesomeIcon icon={faDownload} /> {fmt(p.downloads)}
                                        </span>
                                        {p.dateUpdated && (
                                            <span className='flex items-center gap-1'>
                                                <FontAwesomeIcon icon={faClock} />
                                                {new Date(p.dateUpdated).toLocaleDateString()}
                                            </span>
                                        )}
                                    </div>
                                </Card>
                            ))}
                        </div>

                        {plugins.length === 0 && (
                            <div className='text-center py-20 text-neutral-600'>
                                <FontAwesomeIcon icon={faSearch} className='text-5xl mb-4 opacity-30' />
                                <p className='text-sm'>No plugins found. Try different search terms or filters.</p>
                            </div>
                        )}

                        {plugins.length > 0 && (
                            <div className='flex justify-center items-center gap-3'>
                                <button disabled={page === 0} onClick={() => setPage(p => p - 1)}
                                        className='px-5 py-2 rounded-xl text-sm font-medium transition-all disabled:opacity-30'
                                        style={{ background: 'rgba(15,23,42,0.7)', border: '1px solid rgba(255,255,255,0.07)', color: 'rgb(148,163,184)' }}>
                                    ← Prev
                                </button>
                                <span className='text-neutral-600 text-sm px-2'>Page {page + 1}</span>
                                <button disabled={!hasMore} onClick={() => setPage(p => p + 1)}
                                        className='px-5 py-2 rounded-xl text-sm font-medium transition-all disabled:opacity-30'
                                        style={{ background: 'rgba(15,23,42,0.7)', border: '1px solid rgba(255,255,255,0.07)', color: 'rgb(148,163,184)' }}>
                                    Next →
                                </button>
                            </div>
                        )}
                    </>
                )}

                {/* ── Version modal ── */}
                {selected && (
                    <div className='fixed inset-0 flex items-center justify-center p-4 z-50 overflow-y-auto'
                         style={{ background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(8px)' }}>
                        <div className='max-w-2xl w-full rounded-2xl overflow-hidden flex flex-col max-h-[88vh]'
                             style={{ background: 'rgba(10,15,28,0.97)', border: '1px solid rgba(255,255,255,0.08)', boxShadow: '0 24px 64px rgba(0,0,0,0.5)' }}>

                            {/* Modal header */}
                            <div className='p-6 flex justify-between items-start gap-4 flex-shrink-0'
                                 style={{ borderBottom: '1px solid rgba(255,255,255,0.06)', background: 'rgba(15,23,42,0.5)' }}>
                                <div className='flex-1 min-w-0'>
                                    <div className='flex items-center gap-2 mb-1 flex-wrap'>
                                        <h2 className='text-xl font-bold text-white'>{selected.title}</h2>
                                        <PlatformBadge platform={selected.platform}>
                                            {selected.platform === 'modrinth' ? 'Modrinth' : selected.platform === 'spigotmc' ? 'SpigotMC' : 'Hangar'}
                                        </PlatformBadge>
                                        {selected.premium && (
                                            <span className='text-xs px-2 py-0.5 rounded font-bold uppercase'
                                                  style={{ background: 'rgba(234,179,8,0.18)', color: 'rgb(250,204,21)' }}>
                                                Premium
                                            </span>
                                        )}
                                    </div>
                                    <p className='text-neutral-500 text-sm'>by {selected.author}</p>
                                    {selected.description && (
                                        <p className='text-neutral-400 text-sm mt-2 line-clamp-2'>{selected.description}</p>
                                    )}

                                    {/* Warnings */}
                                    {selected.premium && (
                                        <div className='mt-3 flex items-start gap-2 text-sm rounded-xl p-3'
                                             style={{ background: 'rgba(234,179,8,0.08)', border: '1px solid rgba(234,179,8,0.2)', color: 'rgb(250,204,21)' }}>
                                            <FontAwesomeIcon icon={faExclamationTriangle} className='mt-0.5 flex-shrink-0' />
                                            <span>Premium resource — cannot be auto-downloaded. Purchase on SpigotMC first.</span>
                                        </div>
                                    )}
                                    {selected.external && !selected.premium && (
                                        <div className='mt-3 flex items-start gap-2 text-sm rounded-xl p-3'
                                             style={{ background: 'rgba(59,130,246,0.08)', border: '1px solid rgba(59,130,246,0.2)', color: 'rgb(147,197,253)' }}>
                                            <FontAwesomeIcon icon={faExternalLinkAlt} className='mt-0.5 flex-shrink-0' />
                                            <span>Externally hosted — direct install may not work. Use the SpigotMC link below if install fails.</span>
                                        </div>
                                    )}
                                    {selected.platform === 'hangar' && (
                                        <div className='mt-3 flex items-start gap-2 text-sm rounded-xl p-3'
                                             style={{ background: 'rgba(0,185,255,0.06)', border: '1px solid rgba(0,185,255,0.2)', color: 'rgb(56,211,255)' }}>
                                            <FontAwesomeIcon icon={faCheck} className='mt-0.5 flex-shrink-0' />
                                            <span>Hangar plugins are free and directly downloadable — no account required.</span>
                                        </div>
                                    )}
                                </div>
                                <button onClick={() => setSelected(null)}
                                        className='w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 transition-colors'
                                        style={{ background: 'rgba(30,41,59,0.8)', border: '1px solid rgba(255,255,255,0.06)' }}>
                                    <FontAwesomeIcon icon={faTimes} className='text-neutral-500' />
                                </button>
                            </div>

                            {/* Version filters (Modrinth + Hangar) */}
                            {(selected.platform === 'modrinth' || selected.platform === 'hangar') && (
                                <div className='px-6 py-4 flex-shrink-0 relative z-10'
                                     style={{ borderBottom: '1px solid rgba(255,255,255,0.05)', background: 'rgba(15,23,42,0.3)' }}>
                                    <div className='grid grid-cols-3 gap-3'>
                                        <div>
                                            <label className='block mb-1.5 text-xs text-neutral-600 font-medium uppercase tracking-wider'>MC Version</label>
                                            <Dropdown value={vFilter.gameVersion}
                                                options={[{ id: '', name: 'Any' }, ...allGameVersions.map(v => ({ id: v, name: v }))]}
                                                onChange={val => setVFilter(f => ({ ...f, gameVersion: val }))} />
                                        </div>
                                        <div>
                                            <label className='block mb-1.5 text-xs text-neutral-600 font-medium uppercase tracking-wider'>Loader</label>
                                            <Dropdown value={vFilter.loader}
                                                options={[{ id: '', name: 'Any' }, ...allLoaders.map(v => ({ id: v, name: v }))]}
                                                onChange={val => setVFilter(f => ({ ...f, loader: val }))} />
                                        </div>
                                        <div>
                                            <label className='block mb-1.5 text-xs text-neutral-600 font-medium uppercase tracking-wider'>Type</label>
                                            <Dropdown value={vFilter.type}
                                                options={[{ id: '', name: 'Any' }, { id: 'release', name: 'Release' }, { id: 'beta', name: 'Beta' }, { id: 'alpha', name: 'Alpha' }]}
                                                onChange={val => setVFilter(f => ({ ...f, type: val }))} />
                                        </div>
                                    </div>
                                </div>
                            )}

                            {/* Version list */}
                            <div className='flex-1 overflow-y-auto p-5 space-y-2.5'>
                                {loadingVer ? (
                                    <div className='flex justify-center py-12'>
                                        <FontAwesomeIcon icon={faSpinner} spin className='text-3xl'
                                            style={{ color: platformText(selected.platform) }} />
                                    </div>
                                ) : filteredVersions.length === 0 ? (
                                    <p className='text-center text-neutral-600 py-10 text-sm'>No versions found.</p>
                                ) : filteredVersions.map(v => {
                                    const status = installState[v.id] ?? 'idle';
                                    const errMsg = installErrors[v.id];
                                    return (
                                        <div key={v.id} className='rounded-xl p-4 flex flex-col gap-2'
                                             style={{ background: 'rgba(15,23,42,0.5)', border: '1px solid rgba(255,255,255,0.05)' }}>
                                            <div className='flex items-center justify-between gap-4'>
                                                <div className='flex-1 min-w-0'>
                                                    <div className='flex items-center gap-2 mb-1 flex-wrap'>
                                                        <FontAwesomeIcon icon={faTag} className='text-xs'
                                                            style={{ color: platformText(selected.platform) }} />
                                                        <span className='font-semibold text-sm text-white'>{v.name}</span>
                                                        <span className='text-[10px] px-1.5 py-0.5 rounded font-bold uppercase'
                                                              style={{
                                                                  background: v.type === 'release' ? 'rgba(34,197,94,0.15)' : 'rgba(245,158,11,0.15)',
                                                                  color: v.type === 'release' ? 'rgb(74,222,128)' : 'rgb(251,191,36)',
                                                              }}>
                                                            {v.type}
                                                        </span>
                                                        {v.hangarPlatforms && v.hangarPlatforms.map(plat => (
                                                            <span key={plat} className='text-[10px] px-1.5 py-0.5 rounded font-bold uppercase'
                                                                  style={{ background: 'rgba(0,185,255,0.12)', color: 'rgb(56,211,255)' }}>
                                                                {plat}
                                                            </span>
                                                        ))}
                                                    </div>
                                                    <div className='flex flex-wrap gap-3 text-xs' style={{ color: 'rgb(71,85,105)' }}>
                                                        {v.datePublished && (
                                                            <span><FontAwesomeIcon icon={faClock} className='mr-1' />{new Date(v.datePublished).toLocaleDateString()}</span>
                                                        )}
                                                        {v.downloads > 0 && (
                                                            <span><FontAwesomeIcon icon={faDownload} className='mr-1' />{fmt(v.downloads)}</span>
                                                        )}
                                                        {v.gameVersions.slice(0,3).map(gv => (
                                                            <span key={gv} className='px-1.5 py-0.5 rounded'
                                                                  style={{ background: 'rgba(51,65,85,0.5)', color: 'rgb(100,116,139)' }}>
                                                                {gv}
                                                            </span>
                                                        ))}
                                                    </div>
                                                </div>

                                                {selected.premium ? (
                                                    <a href={`https://www.spigotmc.org/resources/${selected.id}`}
                                                       target='_blank' rel='noreferrer'
                                                       className='px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all'
                                                       style={{ background: 'rgba(234,179,8,0.15)', color: 'rgb(250,204,21)', border: '1px solid rgba(234,179,8,0.3)' }}>
                                                        <FontAwesomeIcon icon={faExternalLinkAlt} /> Buy
                                                    </a>
                                                ) : (
                                                    <div className='flex items-center gap-2 flex-shrink-0'>
                                                        <InstallBtn
                                                            status={status}
                                                            platform={selected.platform}
                                                            disabled={status === 'loading' || status === 'done'}
                                                            onClick={() => install(selected, v)}
                                                        >
                                                            {status === 'loading' && <><FontAwesomeIcon icon={faSpinner} spin /> Installing...</>}
                                                            {status === 'done'    && <><FontAwesomeIcon icon={faCheck} /> Installed!</>}
                                                            {status === 'error'   && <><FontAwesomeIcon icon={faExclamationTriangle} /> Retry</>}
                                                            {status === 'idle'    && <><FontAwesomeIcon icon={faDownload} /> Install</>}
                                                        </InstallBtn>

                                                        {status === 'error' && selected.platform === 'spigotmc' && (
                                                            <a href={`https://www.spigotmc.org/resources/${selected.id}`}
                                                               target='_blank' rel='noreferrer'
                                                               className='px-3 py-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all'
                                                               style={{ background: 'rgba(234,88,12,0.12)', color: 'rgb(251,146,60)', border: '1px solid rgba(234,88,12,0.3)' }}
                                                               title='Open on SpigotMC'>
                                                                <FontAwesomeIcon icon={faExternalLinkAlt} />
                                                            </a>
                                                        )}
                                                        {status === 'error' && selected.platform === 'hangar' && (
                                                            <a href={`https://hangar.papermc.io/${selected.namespace?.owner ?? selected.author}/${selected.namespace?.slug ?? selected.id}`}
                                                               target='_blank' rel='noreferrer'
                                                               className='px-3 py-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all'
                                                               style={{ background: 'rgba(0,185,255,0.1)', color: 'rgb(56,211,255)', border: '1px solid rgba(0,185,255,0.3)' }}
                                                               title='Open on Hangar'>
                                                                <FontAwesomeIcon icon={faExternalLinkAlt} />
                                                            </a>
                                                        )}
                                                    </div>
                                                )}
                                            </div>

                                            {/* Error message row */}
                                            {status === 'error' && errMsg && (
                                                <div className='flex items-start gap-2 rounded-lg px-3 py-2 text-xs'
                                                     style={{ background: 'rgba(220,38,38,0.08)', border: '1px solid rgba(220,38,38,0.2)', color: 'rgb(252,165,165)' }}>
                                                    <FontAwesomeIcon icon={faExclamationTriangle} className='mt-0.5 flex-shrink-0' />
                                                    <span>{errMsg}</span>
                                                </div>
                                            )}
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};
