<div class="container" style="max-width: 480px; margin: 48px auto;">
    <div class="card" style="padding: 2rem; border-radius: 10px; box-shadow: 0 1px 4px #0002;">
        <h2 style="margin-bottom: 0.5rem;">Plugin Browser — Admin</h2>
        <p style="color: #6b7280; margin-bottom: 1.5rem; font-size: 0.9rem;">
            Browse and install plugins from Modrinth and SpigotMC directly into your Pterodactyl servers.
        </p>
        <div style="padding: 1rem; background: #f0fdf4; border: 1px solid #86efac; border-radius: 8px; margin-bottom: 1rem;">
            <strong style="color: #16a34a;">✓ Modrinth</strong>
            <p style="margin: 0.25rem 0 0; font-size: 0.85rem; color: #166534;">Fully supported — no API key required.</p>
        </div>
        <div style="padding: 1rem; background: #fff7ed; border: 1px solid #fdba74; border-radius: 8px;">
            <strong style="color: #ea580c;">✓ SpigotMC (Spiget API)</strong>
            <p style="margin: 0.25rem 0 0; font-size: 0.85rem; color: #9a3412;">
                Free plugins supported. Premium resources require manual download from SpigotMC.
            </p>
        </div>
    </div>
</div>
