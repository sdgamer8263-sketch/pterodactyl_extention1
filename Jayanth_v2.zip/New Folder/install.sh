#!/bin/bash
# ============================================================
#  Plugin Browser — Pterodactyl Blueprint Extension Installer
#  Usage: bash install.sh
# ============================================================

set -e

PANEL_DIR="/var/www/pterodactyl"
BLUEPRINT_FILE="pluginbrowser.blueprint"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

echo -e "\n${CYAN}${BOLD}══════════════════════════════════════════${NC}"
echo -e "${CYAN}${BOLD}  Plugin Browser — Blueprint Installer     ${NC}"
echo -e "${CYAN}${BOLD}══════════════════════════════════════════${NC}\n"

# ── 1. Check root ────────────────────────────────────────────
if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}[ERROR]${NC} Please run as root: sudo bash install.sh"
    exit 1
fi

# ── 2. Check blueprint CLI ───────────────────────────────────
if ! command -v blueprint &>/dev/null; then
    echo -e "${RED}[ERROR]${NC} Blueprint CLI not found. Install Blueprint framework first:"
    echo -e "  https://blueprint.zip/docs/getting-started/installation"
    exit 1
fi

# ── 3. Find .blueprint file ──────────────────────────────────
if [ ! -f "$BLUEPRINT_FILE" ]; then
    # Try to find it in current dir
    FOUND=$(find . -maxdepth 1 -name "*.blueprint" | head -1)
    if [ -z "$FOUND" ]; then
        echo -e "${RED}[ERROR]${NC} Cannot find pluginbrowser.blueprint in current directory."
        exit 1
    fi
    BLUEPRINT_FILE="$FOUND"
fi

echo -e "${GREEN}[✓]${NC} Found blueprint file: ${BOLD}$BLUEPRINT_FILE${NC}"

# ── 4. Copy to panel directory ───────────────────────────────
echo -e "${YELLOW}[→]${NC} Copying to $PANEL_DIR ..."
cp "$BLUEPRINT_FILE" "$PANEL_DIR/"

# ── 5. Run blueprint install ─────────────────────────────────
echo -e "${YELLOW}[→]${NC} Running blueprint -i ..."
cd "$PANEL_DIR"
blueprint -i "$(basename "$BLUEPRINT_FILE")"

# ── 6. Clear caches ──────────────────────────────────────────
echo -e "${YELLOW}[→]${NC} Clearing Laravel caches ..."
php artisan optimize:clear
php artisan view:clear

# ── 7. Done ──────────────────────────────────────────────────
echo -e "\n${GREEN}${BOLD}══════════════════════════════════════════${NC}"
echo -e "${GREEN}${BOLD}  ✓ Plugin Browser installed successfully! ${NC}"
echo -e "${GREEN}${BOLD}══════════════════════════════════════════${NC}"
echo -e "\n${CYAN}Reload your Pterodactyl panel to see the 'Plugins' tab on each server.${NC}\n"
