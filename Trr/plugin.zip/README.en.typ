#context {
  set page(width: 700pt) if target() != "html"
  [
    #import "@preview/colorful-boxes:1.3.1"
    #set text(font: "Inter")
    #show link: underline
    #show raw: set block(fill: luma(230), inset: 8pt, radius: 4pt)

    = Welcome

    Welcome and thanks for buying this product, Minecraft Plugin Manager for Pterodactyl!
    Contact information is available at the end of this document, section Troubleshooting. Please don't hesitate to reach out if you have any questions.
    If you are reading the PDF, you may have an easier time copying around the code
    samples from the Typst file that is available in the same directory as the PDF, under the name `README.en.typ`.

    = Wings modifications (optional)

    This is the same modification as ric-rac's Minecraft Modpack Installer & Mod Manager. You shouldn't do it twice.

    This allows to switch to auto-detect currently used server software to provide automatic filtering and installed plugins listing.

    You need to have the GoLang development tools before proceeding.
    On Debian-based operating systems you can install them using:
    ```bash
    ARCH=$([ "$(uname -m)" = "x86_64" ] && echo "amd64" || echo "arm64")
    wget "https://go.dev/dl/go1.23.3.linux-$ARCH.tar.gz"
    sudo rm -rf /usr/local/go && sudo tar -C /usr/local -xzf "go1.23.3.linux-$ARCH.tar.gz"
    echo 'export PATH=$PATH:/usr/local/go/bin' | sudo tee -a /etc/profile && . /etc/profile
    ```
    If you use the zsh shell, you may need to add the directory to the PATH in ~/.zshrc instead.

    Clone Pterodactyl Wings source code:
    ```bash
    git clone https://github.com/pterodactyl/wings.git
    cd wings
    ```

    Upload the `wings.patch` contained within this archive to the directory that was created

    Apply the changes, build the executable binaries:
    ```bash
    git apply wings.patch
    make build
    ```

    On each node, you want to stop Wings, replace current wings by the one you built
    and restart Wings:
    ```bash
    systemctl stop wings
    cp build/wings_linux_amd64 /usr/local/bin/wings
    systemctl start wings
    ```

    = Setup

    == Configure a CFCore API key

    This addon makes use of external HTTP APIs. CurseForge is the only API that *requires* authentification for the retrieval of information about their platforms' plugins.

    To access the CurseForge API, you first need to #link("https://console.curseforge.com/?#/signup", "create a CFCore account"). Then, copy your API key and add another line in your `.env` file like this:

    ```env
    CURSEFORGE_API_KEY=$2a$10$iZYWa6jrmyz7hN69sfmInes1FAqrn2ycR.ZdrKKrtOpz/Tn9ETMcK
    ```

    (This API key will not work, it is just an example!)

    == Install Node.js, npm and yarn

    On your system, you'll need to install a recent version of Node.js, npm and yarn if you don't have them installed yet.
    Please follow this link to install Node.js (npm is packed with it): https://nodejs.org/en/download/

    Then, install yarn globally with npm:

    ```bash
    npm install --global yarn
    ```

    == Install dependencies and build the panel assets

    Next, we'll download dependencies then build the panel assets to check that your configuration is operational.

    Navigate to where Pterodactyl is installed, e.g.

    ```bash
    cd /var/www/pterodactyl
    ```

    Then, execute the following command that will install the dependencies:

    ```bash
    yarn install
    ```

    If you're going to use a Node.js version greater than or equal to 17.x, you may encounter errors due to an incompatibility between the new OpenSSL and the version of Webpack used by Pterodactyl. As a workaround, set this environment variable before building assets:

    ```bash
    export NODE_OPTIONS=--openssl-legacy-provider
    ```

    Run the panel development build:

    ```bash
    yarn run build
    ```

    If that worked, we've confirmed that you can build your panel's assets for development!
    If that failed and your screen turned to red:
    + check if all the errors are only style errors (e.g. it asks to replace spaces by tabs) => you can ignore them!
    + otherwise, check the Troubleshooting section down below.

    == Upload the contents of the `upload` directory

    To proceed, please upload the contents of the `upload` directory inside the
    directory where Pterodactyl is installed with your favorite (S)FTP client.

    = Make the necessary modifications to existing panel files

    Some modifications just can't be made via a generic patch: you could have a theme installed or something that conflicts with this.

    Now we just need to do some modifications on Panel files. Fortunately, there are not much!
    Under each file name (relative to the directory your Panel is installed in), there will be a diff.
    You have to find the lines which are not prefixed by `+` (they give the line context) and add those that are prefixed by a `+`, relative to the existing contents.

    `+` means "add this line". You need to remove the plus characters after copying and pasting the code.

    == `config/services.php`

    In this file, *DON'T* replace `CURSEFORGE_API_KEY` by your API key.
    It should have been added in `.env` by now.

    ```diff
        'ses' => [
            'key' => env('AWS_ACCESS_KEY_ID'),
            'secret' => env('AWS_SECRET_ACCESS_KEY'),
            'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
        ],
    +
    +    'curseforge_api_key' => env('CURSEFORGE_API_KEY'),
    ];
    ```

    == `app/Repositories/Wings/DaemonFileRepository.php`

    ```diff
    use GuzzleHttp\Exception\TransferException;
    +use GuzzleHttp\Psr7\Query;
    use Pterodactyl\Exceptions\Http\Server\FileSizeTooLargeException;
    ```

    ```diff
            $length = (int) Arr::get($response->getHeader('Content-Length'), 0, 0);
            if ($notLargerThan && $length > $notLargerThan) {
                throw new FileSizeTooLargeException();
            }

            return $response->getBody()->__toString();
        }

    +    /**
    +     * Returns fingerprints of given files' content.
    +     *
    +     * @param  $path  string[]
    +     * @param  $algorithm string should be `sha512` or `curseforge`
    +     * @return array<string, string>
    +     *
    +     * @throws \GuzzleHttp\Exception\TransferException
    +     * @throws \Pterodactyl\Exceptions\Http\Connection\DaemonConnectionException
    +     */
    +    public function getFingerprints(array $paths, string $algorithm = 'sha512'): array
    +    {
    +        Assert::isInstanceOf($this->server, Server::class);
    +
    +        try {
    +            $response = $this->getHttpClient()->get(
    +                sprintf('/api/servers/%s/files/fingerprints', $this->server->uuid),
    +                [
    +                    'query' => Query::build(['files' => $paths, 'algorithm' => $algorithm]),
    +                ]
    +            );
    +        } catch (ClientException|TransferException $exception) {
    +            throw new DaemonConnectionException($exception);
    +        }
    +
    +        $response = $response->getBody()->__toString();
    +
    +        return json_decode($response, true)['fingerprints'];
    +    }
    ```

    Some of the following client-side routing related modifications are not needed for every theme or some other add-on might already be adding something similar.
    In case of doubt, contact us.

    == `app/Transformers/Api/Client/ServerTransformer.php`

    Your theme or another add-on may have already done this change so make sure this isn't the case. This modification should not be done with the Arix and Nova themes.

    ```diff
                'internal_id' => $server->id,
    +           'egg_id' => $server->egg_id,
                'uuid' => $server->uuid,
    ```
    == `resources/scripts/api/server/getServer.ts`

    Your theme or another add-on may have already done this change so make sure this isn't the case.
    This modification should not be done with the Arix and Nova themes.

    ```diff
    export interface Server {
        id: string;
        internalId: number | string;
    +   eggId: number;
        uuid: string;
    ```

    ```diff
        internalId: data.internal_id,
    +   eggId: data.egg_id,
        uuid: data.uuid,
    ```

    == `resources/scripts/routers/routes.ts`

    Your theme or another add-on may have already done the `ServerRouteDefinition` change so make sure this isn't the case.
    The middle modification should not be done with the Arix and Nova themes.

    ```diff
    import FileManagerContainer from '@/components/server/files/FileManagerContainer';
    +import MinecraftPluginContainer from '@/components/server/minecraft-plugins/MinecraftPluginContainer';
    +import MinecraftInstalledPluginsContainer from '@/components/server/minecraft-plugins/MinecraftInstalledPluginsContainer';
    import SettingsContainer from '@/components/server/settings/SettingsContainer';
    ```

    ```diff
    interface ServerRouteDefinition extends RouteDefinition {
        permission: string | string[] | null;
    +   eggIds?: number[];
    }
    ```

    ```diff
            {
                path: '/files',
                permission: 'file.*',
                name: 'Files',
                component: FileManagerContainer,
            },
    +        {
    +            path: '/minecraft-plugins',
    +            permission: 'file.*',
    +            name: 'Plugins',
    +            component: MinecraftPluginContainer,
    +            eggIds: [1, 2, 3, 4, 6],
    +        },
    +        {
    +            path: '/minecraft-plugins/installed',
    +            permission: 'file.*',
    +            name: undefined,
    +            component: MinecraftInstalledPluginsContainer,
    +            eggIds: [1, 2, 3, 4, 6],
    +        },
    ```

    #pagebreak()
    #colorful-boxes.colorbox(
      title: "A note about eggs",
      color: "red",
      radius: 2pt,
      width: auto,
    )[
      The file above contains the numeric identifiers for the eggs for which the new "Plugins" tab will be shown
      in the servers' dashboard.
      It is pre-filled with the default Pterodactyl eggs "Forge Minecraft" and "Vanilla Minecraft", please adjust as needed.
      Egg IDs can be found in your Pterodactyl Panel, in the admin side. Navigate to "Nests", select the appropriate nest and the egg IDs
      will be in the first column of the table.
      #grid(
        columns: (1fr, 1fr),
        column-gutter: 2pt,
        image("media/nests.png"), image("media/eggs.png"),
      )
    ]

    == `resources/scripts/routers/ServerRouter.tsx`

    This modification should not be done with the Arix and Nova themes.

    ```diff
        const serverId = ServerContext.useStoreState((state) => state.server.data?.internalId);
    +   const serverEggId = ServerContext.useStoreState((state) => state.server.data?.eggId);

    [...]

                                    {routes.server
                                        .filter((route) => !!route.name)
    +                                    .filter((route) =>
    +                                        route.eggIds && serverEggId ? route.eggIds.includes(serverEggId) : true
    +                                    )
                                        .map((route) =>
    ```

    == `routes/api-client.php`

    ```diff
        Route::group(['prefix' => '/settings'], function () {
            Route::post('/rename', [Client\Servers\SettingsController::class, 'rename']);
            Route::post('/reinstall', [Client\Servers\SettingsController::class, 'reinstall']);
            Route::put('/docker-image', [Client\Servers\SettingsController::class, 'dockerImage']);
        });

    +    Route::get('/minecraft-software', [Client\Servers\MinecraftSoftwareController::class, 'index']);
    +
    +    Route::group(['prefix' => '/minecraft-plugins'], function () {
    +        Route::get('/', [Client\Servers\MinecraftPluginController::class, 'index']);
    +        Route::get('/versions', [Client\Servers\MinecraftPluginController::class, 'versions']);
    +        Route::post('/install', [Client\Servers\MinecraftPluginController::class, 'installPlugin']);
    +        Route::get('/installed', [Client\Servers\MinecraftPluginController::class, 'getInstalledPluginsVersions']);
    +        Route::get('/is-linked', [Client\Servers\MinecraftPluginController::class, 'isLinked']);
    +        Route::post('/link', [Client\Servers\MinecraftPluginController::class, 'linkPolymart'])->name('minecraft-plugins.link');
    +        Route::post('/link-back', [Client\Servers\MinecraftPluginController::class, 'handleBackPolymart'])->name('minecraft-plugins.link-back')->withoutMiddleware([\Pterodactyl\Http\Middleware\VerifyCsrfToken::class, ServerSubject::class, 'auth', 'api', \Pterodactyl\Http\Middleware\Api\Client\RequireClientApiKey::class, AuthenticateServerAccess::class]);
    +        Route::post('/disconnect', [Client\Servers\MinecraftPluginController::class, 'disconnectPolymart']);
    +    });
    ```

    = Bring it live!

    All the following commands need to be executed in the directory where Pterodactyl is installed.

    Migrate the database for the new table for Polymart links to be created:

    ```bash
    php artisan migrate
    ```

    Build the production assets with yarn:

    ```bash
    yarn run build:production
    ```

    Cache new routes and configuration:
    ```bash
    php artisan optimize
    ```

    You're done! Enjoy!

    = Troubleshooting

    If you have any questions about this product or need help with its installation,
    You can contact us using the following services:
    - Discord: https://discord.gg/RJ2A8yYS2m
    - Email: #link("mailto:contact@ric-rac.org")[contact\@ric-rac.org]
    - X: #link("https://twitter.com/ricxracx")[\@ricxracx]
    - SMS: #link("tel:+33611194971")[+33 6 11 19 49 71]

    == CurseForge plugins won't load

    1. Check that you correctly edited `config/services.php` (it should not contain the API key).
    2. Check that the API key is present in `.env` under the correct variable name.
    3. Try running `php artisan config:clear`
    4. Try replacing

      ```php-src
      $this->userAgent = config('app.name') . '/' . config('app.version') . ' (' . url('/') . ')';
      ```

      by
      ```php-src
      $this->userAgent = 'Mozilla/5.0 (X11; Linux x86_64; rv:127.0) Gecko/20100101 Firefox/127.0';
      ```

      in `app/Services/Minecraft/Plugins/AbstractPluginService.php`
    5. Make sure that your firewall isn't blocking anything (look in logs at `storage/logs`).
  ]
}
