<?php

namespace Pterodactyl\Http\Controllers\Server;

use Illuminate\Http\Request;
use Pterodactyl\Http\Controllers\Controller;
use Illuminate\Support\Facades\Http;

class PluginManagerController extends Controller
{
    /**
     * Return the index view (handled by React in Pterodactyl)
     */
    public function index()
    {
        return view('templates/base.core');
    }

    /**
     * Search for plugins using the Spiget API (SpigotMC)
     */
    public function search(Request $request)
    {
        $query = $request->input('q', 'essentials');
        
        // Fetching free plugins from SpigotMC via Spiget API
        $response = Http::get("https://api.spiget.org/v2/search/resources/{$query}", [
            'field' => 'name',
            'size' => 10,
            'sort' => '-downloads'
        ]);

        if ($response->successful()) {
            return response()->json($response->json());
        }

        return response()->json(['error' => 'Unable to fetch plugins'], 500);
    }
}
