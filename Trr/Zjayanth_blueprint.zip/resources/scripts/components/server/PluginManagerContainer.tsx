import React, { useState, useEffect } from 'react';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import tw from 'twin.macro';
import { ServerContext } from '@/state/server';
import FlashMessageRender from '@/components/FlashMessageRender';

interface Plugin {
    id: number;
    name: string;
    tag: string;
    downloads: number;
}

const PluginManagerContainer = () => {
    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);
    const [plugins, setPlugins] = useState<Plugin[]>([]);
    const [search, setSearch] = useState('essentials');
    const [loading, setLoading] = useState(false);

    const fetchPlugins = async () => {
        setLoading(true);
        try {
            const res = await fetch(`/server/${uuid}/plugins/search?q=${search}`);
            const data = await res.json();
            if (Array.isArray(data)) {
                setPlugins(data);
            }
        } catch (error) {
            console.error('Error fetching plugins', error);
        }
        setLoading(false);
    };

    useEffect(() => {
        fetchPlugins();
    }, []);

    const glassStyle = {
        background: 'rgba(255, 255, 255, 0.05)',
        backdropFilter: 'blur(10px)',
        border: '1px solid rgba(255, 255, 255, 0.1)',
        borderRadius: '8px',
        padding: '16px',
        marginBottom: '10px'
    };

    return (
        <ServerContentBlock title={'Plugin Manager'}>
            <FlashMessageRender byKey={'server:plugins'} />
            
            <h1 css={tw`text-2xl font-bold mb-4`}>SpigotMC Plugin Manager</h1>
            
            <div css={tw`flex mb-6`}>
                <input 
                    type="text" 
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    placeholder="Search for plugins (e.g., Vault, WorldEdit)..."
                    css={tw`p-2 bg-gray-800 rounded text-white flex-1 mr-2 border border-gray-700`}
                />
                <button 
                    onClick={fetchPlugins}
                    css={tw`bg-blue-600 hover:bg-blue-500 text-white font-bold py-2 px-4 rounded`}
                >
                    Search
                </button>
            </div>

            {loading ? (
                <p css={tw`text-gray-400`}>Loading plugins...</p>
            ) : (
                <div css={tw`grid grid-cols-1 md:grid-cols-2 gap-4`}>
                    {plugins.map(plugin => (
                        <div key={plugin.id} style={glassStyle}>
                            <h3 css={tw`text-lg font-semibold text-gray-100`}>{plugin.name}</h3>
                            <p css={tw`text-sm text-gray-400 mt-1`}>{plugin.tag}</p>
                            <div css={tw`mt-4 flex justify-between items-center`}>
                                <span css={tw`text-xs text-gray-500`}>Downloads: {plugin.downloads}</span>
                                <button css={tw`bg-green-600 hover:bg-green-500 text-white text-sm py-1 px-3 rounded`}>
                                    Install
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </ServerContentBlock>
    );
};

export default PluginManagerContainer;
