<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Banned - {{ config('app.name', 'Pterodactyl') }}</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #0f172a 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .container {
            width: 100%;
            max-width: 500px;
        }

        .card {
            background: linear-gradient(180deg, rgba(30, 41, 59, 0.8) 0%, rgba(15, 23, 42, 0.9) 100%);
            border: 1px solid rgba(99, 102, 241, 0.2);
            border-radius: 16px;
            padding: 40px 30px;
            text-align: center;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5),
                        0 0 40px rgba(239, 68, 68, 0.1);
        }

        .icon-wrapper {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #dc2626 0%, #991b1b 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 24px;
            box-shadow: 0 0 30px rgba(220, 38, 38, 0.4);
        }

        .icon-wrapper svg {
            width: 40px;
            height: 40px;
            color: white;
        }

        .title {
            font-size: 1.75rem;
            font-weight: 800;
            color: #ef4444;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 12px;
            text-shadow: 0 0 20px rgba(239, 68, 68, 0.3);
        }

        .subtitle {
            color: #94a3b8;
            font-size: 0.95rem;
            line-height: 1.6;
            margin-bottom: 28px;
        }

        .info-box {
            background: rgba(15, 23, 42, 0.6);
            border: 1px solid rgba(71, 85, 105, 0.3);
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 20px;
        }

        .info-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 0;
            border-bottom: 1px solid rgba(71, 85, 105, 0.2);
        }

        .info-row:last-child {
            border-bottom: none;
        }

        .info-label {
            color: #64748b;
            font-size: 0.9rem;
        }

        .info-value {
            color: #f1f5f9;
            font-weight: 600;
            font-size: 0.9rem;
        }

        .reason-box {
            background: linear-gradient(135deg, rgba(127, 29, 29, 0.4) 0%, rgba(153, 27, 27, 0.3) 100%);
            border: 1px solid rgba(239, 68, 68, 0.3);
            border-radius: 12px;
            padding: 16px 20px;
            margin-bottom: 20px;
            text-align: left;
        }

        .reason-title {
            color: #fca5a5;
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 8px;
        }

        .reason-text {
            color: #fecaca;
            font-size: 0.95rem;
            line-height: 1.5;
        }

        .appeal-text {
            color: #64748b;
            font-size: 0.85rem;
            line-height: 1.6;
            margin-bottom: 24px;
        }

        .logout-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
            color: white;
            font-weight: 600;
            font-size: 0.95rem;
            padding: 12px 32px;
            border-radius: 8px;
            text-decoration: none;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(59, 130, 246, 0.3);
        }

        .logout-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(59, 130, 246, 0.4);
        }

        .logout-btn svg {
            width: 18px;
            height: 18px;
        }

        .footer {
            text-align: center;
            margin-top: 24px;
            color: #475569;
            font-size: 0.8rem;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="icon-wrapper">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
            </div>

            <h1 class="title">AKUN ANDA TELAH<br>DIBANNED</h1>

            <p class="subtitle">
                Akses ke akun Anda telah ditangguhkan oleh administrator.<br>
                Anda tidak dapat mengakses dashboard atau layanan apa pun.
            </p>

            <div class="info-box">
                <div class="info-row">
                    <span class="info-label">Username</span>
                    <span class="info-value">{{ Auth::user()->username }}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Email</span>
                    <span class="info-value">{{ Auth::user()->email }}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Tanggal Suspend</span>
                    <span class="info-value">{{ $suspendedAt ? $suspendedAt->format('d M Y, H:i') : '-' }}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Oleh Admin</span>
                    <span class="info-value">{{ $suspendedBy ? $suspendedBy->username : 'System' }}</span>
                </div>
            </div>

            @if($reason)
            <div class="reason-box">
                <div class="reason-title">Alasan Penangguhan</div>
                <div class="reason-text">{{ $reason }}</div>
            </div>
            @endif

            <p class="appeal-text">
                Jika Anda merasa ini adalah kesalahan atau ingin mengajukan banding, silakan
                hubungi administrator melalui saluran yang tersedia.
            </p>

            <form action="{{ route('auth.logout') }}" method="POST" style="display: inline;">
                @csrf
                <button type="submit" class="logout-btn">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path>
                    </svg>
                    Logout
                </button>
            </form>
        </div>

        <div class="footer">
            &copy; {{ date('Y') }} {{ config('app.name', 'Pterodactyl') }}. All rights reserved.
        </div>
    </div>
</body>
</html>
