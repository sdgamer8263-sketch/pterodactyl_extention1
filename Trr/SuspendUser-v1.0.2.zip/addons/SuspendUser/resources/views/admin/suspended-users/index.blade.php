@extends('layouts.admin')

@section('title')
    Banned Users
@endsection

@section('content-header')
    <h1>Banned Users<small>View and manage banned/suspended users.</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li class="active">Banned Users</li>
    </ol>
@endsection

@section('content')
<style>
    .stat-box {
        background: linear-gradient(135deg, #dc3545 0%, #c82333 100%);
        border-radius: 8px;
        padding: 20px;
        color: white;
        margin-bottom: 20px;
        box-shadow: 0 4px 15px rgba(220, 53, 69, 0.3);
    }
    .stat-box.warning {
        background: linear-gradient(135deg, #fd7e14 0%, #e8590c 100%);
        box-shadow: 0 4px 15px rgba(253, 126, 20, 0.3);
    }
    .stat-box.info {
        background: linear-gradient(135deg, #17a2b8 0%, #138496 100%);
        box-shadow: 0 4px 15px rgba(23, 162, 184, 0.3);
    }
    .stat-box .stat-icon {
        font-size: 40px;
        opacity: 0.8;
        float: right;
        margin-top: -5px;
    }
    .stat-box .stat-number {
        font-size: 32px;
        font-weight: 700;
        display: block;
        margin-bottom: 5px;
    }
    .stat-box .stat-label {
        font-size: 14px;
        text-transform: uppercase;
        letter-spacing: 1px;
        opacity: 0.9;
    }
    .banned-table th {
        background: #1a1a2e;
        color: #a0a0a0;
        font-weight: 600;
        text-transform: uppercase;
        font-size: 11px;
        letter-spacing: 0.5px;
        padding: 12px 15px !important;
        border-bottom: 2px solid #dc3545 !important;
    }
    .banned-table td {
        padding: 12px 15px !important;
        vertical-align: middle !important;
    }
    .banned-table tbody tr:hover {
        background: rgba(220, 53, 69, 0.05);
    }
    .banned-table tbody tr.selected {
        background: rgba(220, 53, 69, 0.15) !important;
    }
    .user-avatar {
        width: 32px;
        height: 32px;
        border-radius: 50%;
        margin-right: 10px;
        vertical-align: middle;
        border: 2px solid #3a3a5a;
    }
    .reason-badge {
        background: rgba(220, 53, 69, 0.2);
        color: #ff6b6b;
        padding: 4px 10px;
        border-radius: 4px;
        font-size: 12px;
        max-width: 200px;
        display: inline-block;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
    .btn-unban {
        background: linear-gradient(135deg, #28a745 0%, #218838 100%);
        border: none;
        color: white;
        padding: 5px 12px;
        border-radius: 4px;
        font-size: 12px;
        margin-right: 5px;
    }
    .btn-unban:hover {
        background: linear-gradient(135deg, #218838 0%, #1e7e34 100%);
        color: white;
    }
    .btn-view {
        background: linear-gradient(135deg, #007bff 0%, #0069d9 100%);
        border: none;
        color: white;
        padding: 5px 12px;
        border-radius: 4px;
        font-size: 12px;
    }
    .btn-view:hover {
        background: linear-gradient(135deg, #0069d9 0%, #0056b3 100%);
        color: white;
    }
    .empty-state {
        padding: 60px 20px;
        text-align: center;
    }
    .empty-state i {
        font-size: 60px;
        color: #28a745;
        margin-bottom: 20px;
    }
    .empty-state h4 {
        color: #fff;
        margin-bottom: 10px;
    }
    .box-header-custom {
        background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
        border-bottom: 2px solid #dc3545;
        padding: 15px 20px;
    }
    .box-header-custom .box-title {
        color: #fff;
        font-weight: 600;
    }
    .badge-count {
        background: #dc3545;
        color: white;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
    }
    .time-ago {
        color: #6c757d;
        font-size: 13px;
    }
    .admin-link {
        color: #17a2b8;
    }
    .admin-link:hover {
        color: #138496;
    }
    /* Checkbox styling */
    .user-checkbox {
        width: 18px;
        height: 18px;
        cursor: pointer;
        accent-color: #dc3545;
    }
    .select-all-checkbox {
        width: 18px;
        height: 18px;
        cursor: pointer;
        accent-color: #dc3545;
    }
    /* Bulk action bar */
    .bulk-action-bar {
        background: linear-gradient(135deg, #1a1a2e 0%, #2d2d44 100%);
        border-radius: 8px;
        padding: 15px 20px;
        margin-bottom: 20px;
        display: none;
        align-items: center;
        justify-content: space-between;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
        border: 1px solid #3a3a5a;
    }
    .bulk-action-bar.show {
        display: flex;
    }
    .bulk-action-bar .selected-count {
        color: #fff;
        font-weight: 600;
        font-size: 14px;
    }
    .bulk-action-bar .selected-count span {
        color: #dc3545;
        font-size: 18px;
    }
    .bulk-action-bar .bulk-actions {
        display: flex;
        gap: 10px;
    }
    .btn-bulk-unban {
        background: linear-gradient(135deg, #28a745 0%, #218838 100%);
        border: none;
        color: white;
        padding: 8px 20px;
        border-radius: 6px;
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s ease;
    }
    .btn-bulk-unban:hover {
        background: linear-gradient(135deg, #218838 0%, #1e7e34 100%);
        color: white;
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(40, 167, 69, 0.4);
    }
    .btn-bulk-delete {
        background: linear-gradient(135deg, #dc3545 0%, #c82333 100%);
        border: none;
        color: white;
        padding: 8px 20px;
        border-radius: 6px;
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s ease;
    }
    .btn-bulk-delete:hover {
        background: linear-gradient(135deg, #c82333 0%, #bd2130 100%);
        color: white;
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(220, 53, 69, 0.4);
    }
    .btn-clear-selection {
        background: transparent;
        border: 1px solid #6c757d;
        color: #6c757d;
        padding: 8px 15px;
        border-radius: 6px;
        font-size: 13px;
        cursor: pointer;
        transition: all 0.2s ease;
    }
    .btn-clear-selection:hover {
        background: rgba(108, 117, 125, 0.1);
        color: #adb5bd;
        border-color: #adb5bd;
    }
</style>

<div class="row">
    <div class="col-md-4">
        <div class="stat-box">
            <i class="fa fa-ban stat-icon"></i>
            <span class="stat-number">{{ $users->total() }}</span>
            <span class="stat-label">Total Banned</span>
        </div>
    </div>
    <div class="col-md-4">
        <div class="stat-box warning">
            <i class="fa fa-clock-o stat-icon"></i>
            <span class="stat-number">{{ $users->where('suspended_at', '>=', now()->startOfDay())->count() }}</span>
            <span class="stat-label">Banned Today</span>
        </div>
    </div>
    <div class="col-md-4">
        <div class="stat-box info">
            <i class="fa fa-calendar stat-icon"></i>
            <span class="stat-number">{{ $users->where('suspended_at', '>=', now()->startOfWeek())->count() }}</span>
            <span class="stat-label">This Week</span>
        </div>
    </div>
</div>

<!-- Bulk Action Bar -->
<div class="bulk-action-bar" id="bulkActionBar">
    <div class="selected-count">
        <i class="fa fa-check-square"></i> <span id="selectedCount">0</span> user(s) selected
    </div>
    <div class="bulk-actions">
        <button type="button" class="btn-clear-selection" id="clearSelection">
            <i class="fa fa-times"></i> Clear Selection
        </button>
        <button type="button" class="btn-bulk-unban" id="bulkUnbanBtn">
            <i class="fa fa-unlock"></i> Unban Selected
        </button>
        <button type="button" class="btn-bulk-delete" id="bulkDeleteBtn">
            <i class="fa fa-trash"></i> Delete Selected
        </button>
    </div>
</div>

<!-- Hidden forms for bulk actions -->
<form id="bulkUnbanForm" action="{{ route('admin.suspended-users.bulk-unsuspend') }}" method="POST" style="display: none;">
    @csrf
    <div id="bulkUnbanInputs"></div>
</form>

<form id="bulkDeleteForm" action="{{ route('admin.suspended-users.bulk-delete') }}" method="POST" style="display: none;">
    @csrf
    <div id="bulkDeleteInputs"></div>
</form>

<div class="row">
    <div class="col-xs-12">
        <div class="box box-danger">
            <div class="box-header box-header-custom">
                <h3 class="box-title"><i class="fa fa-ban"></i> Banned Users List</h3>
                <div class="box-tools pull-right">
                    <span class="badge-count">{{ $users->total() }} users</span>
                </div>
            </div>
            <div class="box-body table-responsive no-padding">
                <table class="table banned-table">
                    <thead>
                        <tr>
                            <th style="width: 3%">
                                <input type="checkbox" class="select-all-checkbox" id="selectAll" data-toggle="tooltip" title="Select All">
                            </th>
                            <th style="width: 5%">#</th>
                            <th style="width: 16%">Username</th>
                            <th style="width: 18%">Email</th>
                            <th style="width: 18%">Reason</th>
                            <th style="width: 12%">Banned By</th>
                            <th style="width: 12%">Time</th>
                            <th style="width: 16%" class="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($users as $user)
                        <tr data-user-id="{{ $user->id }}">
                            <td>
                                <input type="checkbox" class="user-checkbox" value="{{ $user->id }}" data-username="{{ $user->username }}">
                            </td>
                            <td><code>{{ $user->id }}</code></td>
                            <td>
                                <img src="https://www.gravatar.com/avatar/{{ md5(strtolower($user->email)) }}?s=64&d=identicon" class="user-avatar">
                                <a href="{{ route('admin.users.view', $user->id) }}"><strong>{{ $user->username }}</strong></a>
                            </td>
                            <td>
                                <span class="text-muted">{{ $user->email }}</span>
                            </td>
                            <td>
                                @if($user->suspension_reason)
                                    <span class="reason-badge" data-toggle="tooltip" title="{{ $user->suspension_reason }}">
                                        {{ Str::limit($user->suspension_reason, 25) }}
                                    </span>
                                @else
                                    <span class="text-muted">No reason provided</span>
                                @endif
                            </td>
                            <td>
                                @if($user->suspendedBy)
                                    <a href="{{ route('admin.users.view', $user->suspendedBy->id) }}" class="admin-link">
                                        <i class="fa fa-user-circle"></i> {{ $user->suspendedBy->username }}
                                    </a>
                                @else
                                    <span class="text-muted"><i class="fa fa-server"></i> System</span>
                                @endif
                            </td>
                            <td>
                                <span class="time-ago" data-toggle="tooltip" title="{{ $user->suspended_at->format('d M Y, H:i:s') }}">
                                    {{ $user->suspended_at->diffForHumans() }}
                                </span>
                            </td>
                            <td class="text-center">
                                <form action="{{ route('admin.users.unsuspend', $user->id) }}" method="POST" style="display: inline;" class="unban-form">
                                    @csrf
                                    <button type="submit" class="btn btn-unban" data-toggle="tooltip" title="Unban this user">
                                        <i class="fa fa-unlock"></i> Unban
                                    </button>
                                </form>
                                <a href="{{ route('admin.users.view', $user->id) }}" class="btn btn-view" data-toggle="tooltip" title="View details">
                                    <i class="fa fa-eye"></i> View
                                </a>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="8" class="empty-state">
                                <i class="fa fa-check-circle"></i>
                                <h4>No Banned Users</h4>
                                <p class="text-muted">All users are in good standing. No one has been banned.</p>
                            </td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            @if($users->hasPages())
            <div class="box-footer with-border">
                <div class="text-center">
                    {{ $users->links() }}
                </div>
            </div>
            @endif
        </div>
    </div>
</div>
@endsection

@section('footer-scripts')
    @parent
    <script>
        $(function () {
            $('[data-toggle="tooltip"]').tooltip();
            
            var selectedUsers = [];
            
            // Update bulk action bar visibility and count
            function updateBulkActionBar() {
                var count = selectedUsers.length;
                $('#selectedCount').text(count);
                
                if (count > 0) {
                    $('#bulkActionBar').addClass('show');
                } else {
                    $('#bulkActionBar').removeClass('show');
                }
            }
            
            // Update row selection state
            function updateRowSelection() {
                $('.user-checkbox').each(function() {
                    var userId = parseInt($(this).val());
                    var $row = $(this).closest('tr');
                    
                    if (selectedUsers.includes(userId)) {
                        $(this).prop('checked', true);
                        $row.addClass('selected');
                    } else {
                        $(this).prop('checked', false);
                        $row.removeClass('selected');
                    }
                });
                
                // Update select all checkbox
                var totalCheckboxes = $('.user-checkbox').length;
                var checkedCheckboxes = $('.user-checkbox:checked').length;
                
                if (totalCheckboxes > 0 && totalCheckboxes === checkedCheckboxes) {
                    $('#selectAll').prop('checked', true).prop('indeterminate', false);
                } else if (checkedCheckboxes > 0) {
                    $('#selectAll').prop('checked', false).prop('indeterminate', true);
                } else {
                    $('#selectAll').prop('checked', false).prop('indeterminate', false);
                }
            }
            
            // Handle individual checkbox click
            $('.user-checkbox').on('change', function() {
                var userId = parseInt($(this).val());
                
                if ($(this).is(':checked')) {
                    if (!selectedUsers.includes(userId)) {
                        selectedUsers.push(userId);
                    }
                } else {
                    selectedUsers = selectedUsers.filter(function(id) {
                        return id !== userId;
                    });
                }
                
                updateRowSelection();
                updateBulkActionBar();
            });
            
            // Handle select all checkbox
            $('#selectAll').on('change', function() {
                var isChecked = $(this).is(':checked');
                
                $('.user-checkbox').each(function() {
                    var userId = parseInt($(this).val());
                    
                    if (isChecked) {
                        if (!selectedUsers.includes(userId)) {
                            selectedUsers.push(userId);
                        }
                    } else {
                        selectedUsers = selectedUsers.filter(function(id) {
                            return id !== userId;
                        });
                    }
                });
                
                updateRowSelection();
                updateBulkActionBar();
            });
            
            // Clear selection
            $('#clearSelection').on('click', function() {
                selectedUsers = [];
                updateRowSelection();
                updateBulkActionBar();
            });
            
            // Bulk Unban
            $('#bulkUnbanBtn').on('click', function() {
                if (selectedUsers.length === 0) {
                    swal({
                        title: 'No Selection',
                        text: 'Please select at least one user to unban.',
                        type: 'warning'
                    });
                    return;
                }
                
                swal({
                    title: 'Unban ' + selectedUsers.length + ' User(s)?',
                    text: 'These users will be able to access their accounts again.',
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#28a745',
                    cancelButtonColor: '#6c757d',
                    confirmButtonText: 'Yes, unban them!',
                    cancelButtonText: 'Cancel'
                }, function() {
                    // Build form inputs
                    var $inputs = $('#bulkUnbanInputs');
                    $inputs.empty();
                    
                    selectedUsers.forEach(function(userId) {
                        $inputs.append('<input type="hidden" name="users[]" value="' + userId + '">');
                    });
                    
                    // Submit form
                    $('#bulkUnbanForm').submit();
                });
            });
            
            // Bulk Delete
            $('#bulkDeleteBtn').on('click', function() {
                if (selectedUsers.length === 0) {
                    swal({
                        title: 'No Selection',
                        text: 'Please select at least one user to delete.',
                        type: 'warning'
                    });
                    return;
                }
                
                swal({
                    title: 'Delete ' + selectedUsers.length + ' User(s)?',
                    text: 'This action is PERMANENT and cannot be undone! All user data will be lost. Users with servers attached cannot be deleted.',
                    type: 'error',
                    showCancelButton: true,
                    confirmButtonColor: '#dc3545',
                    cancelButtonColor: '#6c757d',
                    confirmButtonText: 'Yes, delete them!',
                    cancelButtonText: 'Cancel',
                    closeOnConfirm: false
                }, function() {
                    // Second confirmation for delete
                    swal({
                        title: 'Are you absolutely sure?',
                        text: 'Type "DELETE" to confirm this action.',
                        type: 'input',
                        showCancelButton: true,
                        confirmButtonColor: '#dc3545',
                        cancelButtonColor: '#6c757d',
                        confirmButtonText: 'Delete Users',
                        cancelButtonText: 'Cancel',
                        inputPlaceholder: 'Type DELETE to confirm'
                    }, function(inputValue) {
                        if (inputValue === false) return false;
                        
                        if (inputValue !== 'DELETE') {
                            swal({
                                title: 'Cancelled',
                                text: 'You must type DELETE to confirm.',
                                type: 'error'
                            });
                            return false;
                        }
                        
                        // Build form inputs
                        var $inputs = $('#bulkDeleteInputs');
                        $inputs.empty();
                        
                        selectedUsers.forEach(function(userId) {
                            $inputs.append('<input type="hidden" name="users[]" value="' + userId + '">');
                        });
                        
                        // Submit form
                        $('#bulkDeleteForm').submit();
                    });
                });
            });
            
            // Individual unban form confirmation
            $('.unban-form').on('submit', function(e) {
                e.preventDefault();
                var form = $(this);
                
                swal({
                    title: 'Unban User?',
                    text: 'This user will be able to access their account again.',
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#28a745',
                    cancelButtonColor: '#6c757d',
                    confirmButtonText: 'Yes, unban!',
                    cancelButtonText: 'Cancel'
                }, function() {
                    form.off('submit').submit();
                });
            });
        });
    </script>
@endsection
