#!/usr/bin/env php
<?php

define('RED', "\033[31m");
define('GREEN', "\033[32m");
define('YELLOW', "\033[33m");
define('BLUE', "\033[34m");
define('CYAN', "\033[36m");
define('RESET', "\033[0m");
define('BOLD', "\033[1m");

define('ADDON_DIR', __DIR__);
define('BASE_DIR', dirname(dirname(__DIR__)));

class SuspendUserInstaller
{
    private string $basePath;
    private string $addonPath;
    private array $installedFiles = [];
    private array $modifiedFiles = [];
    private bool $dryRun = false;

    public function __construct()
    {
        $this->basePath = BASE_DIR;
        $this->addonPath = ADDON_DIR;
    }

    private function log(string $message, string $color = RESET): void
    {
        echo $color . $message . RESET . PHP_EOL;
    }

    private function header(string $title): void
    {
        echo PHP_EOL;
        echo CYAN . BOLD . "╔══════════════════════════════════════════════════════════════╗" . RESET . PHP_EOL;
        echo CYAN . BOLD . "║" . str_pad(" " . $title, 63) . "║" . RESET . PHP_EOL;
        echo CYAN . BOLD . "╚══════════════════════════════════════════════════════════════╝" . RESET . PHP_EOL;
        echo PHP_EOL;
    }

    private function step(int $num, string $message): void
    {
        echo BLUE . "[Step $num] " . RESET . $message . PHP_EOL;
    }

    private function success(string $message): void
    {
        echo GREEN . "  ✓ " . RESET . $message . PHP_EOL;
    }

    private function error(string $message): void
    {
        echo RED . "  ✗ " . RESET . $message . PHP_EOL;
    }

    private function warning(string $message): void
    {
        echo YELLOW . "  ⚠ " . RESET . $message . PHP_EOL;
    }

    private function info(string $message): void
    {
        echo CYAN . "  ℹ " . RESET . $message . PHP_EOL;
    }

    private function checkPermissions(): bool
    {
        if (PHP_OS_FAMILY !== 'Windows' && posix_getuid() !== 0) {
            $webUser = $this->getWebServerUser();
            $this->warning("Not running as root. File permissions may need manual adjustment.");
            $this->info("Web server user detected: $webUser");
            return true;
        }
        return true;
    }

    private function getWebServerUser(): string
    {
        $users = ['www-data', 'nginx', 'apache', 'http'];
        foreach ($users as $user) {
            if (posix_getpwnam($user)) {
                return $user;
            }
        }
        return 'www-data';
    }

    private function validateInstallation(): bool
    {
        $requiredFiles = [
            'artisan',
            'composer.json',
            'app/Models/User.php',
            'routes/admin.php',
            'resources/views/layouts/admin.blade.php',
        ];

        foreach ($requiredFiles as $file) {
            if (!file_exists($this->basePath . '/' . $file)) {
                $this->error("Required file not found: $file");
                return false;
            }
        }

        $this->success("Pterodactyl installation validated");
        return true;
    }

    private function checkVersion(): ?string
    {
        $composerFile = $this->basePath . '/composer.json';
        if (!file_exists($composerFile)) {
            return null;
        }

        $composer = json_decode(file_get_contents($composerFile), true);
        if (isset($composer['version'])) {
            return $composer['version'];
        }

        $configFile = $this->basePath . '/config/app.php';
        if (file_exists($configFile)) {
            $content = file_get_contents($configFile);
            if (preg_match("/'version'\s*=>\s*'([^']+)'/", $content, $matches)) {
                return $matches[1];
            }
        }

        return 'Unknown';
    }

    private function copyFile(string $source, string $target): bool
    {
        $targetDir = dirname($target);
        
        if (!is_dir($targetDir)) {
            if (!$this->dryRun) {
                mkdir($targetDir, 0755, true);
            }
            $this->info("Created directory: " . str_replace($this->basePath, '', $targetDir));
        }

        if ($this->dryRun) {
            $this->info("[DRY RUN] Would copy: " . str_replace($this->basePath, '', $target));
            return true;
        }

        if (file_exists($target)) {
            $this->warning("Overwriting existing file: " . str_replace($this->basePath, '', $target));
        }

        if (copy($source, $target)) {
            $this->installedFiles[] = $target;
            $this->success("Copied: " . str_replace($this->basePath, '', $target));
            return true;
        }

        $this->error("Failed to copy: " . str_replace($this->basePath, '', $target));
        return false;
    }

    private function installMigration(): bool
    {
        $source = $this->addonPath . '/database/migrations/2025_01_23_000000_add_suspended_at_to_users_table.php';
        $target = $this->basePath . '/database/migrations/2025_01_23_000000_add_suspended_at_to_users_table.php';
        
        return $this->copyFile($source, $target);
    }

    private function installService(): bool
    {
        $source = $this->addonPath . '/app/Services/UserSuspensionService.php';
        $target = $this->basePath . '/app/Services/UserSuspensionService.php';
        
        $servicesDir = $this->basePath . '/app/Services';
        if (!is_dir($servicesDir)) {
            mkdir($servicesDir, 0755, true);
            $this->info("Created directory: app/Services");
        }

        return $this->copyFile($source, $target);
    }

    private function installMiddleware(): bool
    {
        $source = $this->addonPath . '/app/Http/Middleware/CheckUserSuspension.php';
        $target = $this->basePath . '/app/Http/Middleware/CheckUserSuspension.php';
        
        return $this->copyFile($source, $target);
    }

    private function installControllers(): bool
    {
        $controllers = [
            'app/Http/Controllers/Admin/SuspendedUsersController.php',
            'app/Http/Controllers/Base/SuspendedController.php',
        ];

        foreach ($controllers as $controller) {
            $source = $this->addonPath . '/' . $controller;
            $target = $this->basePath . '/' . $controller;
            
            if (!$this->copyFile($source, $target)) {
                return false;
            }
        }

        return true;
    }

    private function installViews(): bool
    {
        $views = [
            'resources/views/suspended.blade.php',
            'resources/views/admin/suspended-users/index.blade.php',
        ];

        foreach ($views as $view) {
            $source = $this->addonPath . '/' . $view;
            $target = $this->basePath . '/' . $view;
            
            if (!$this->copyFile($source, $target)) {
                return false;
            }
        }

        return true;
    }

    private function modifyUserModel(): bool
    {
        $modelPath = $this->basePath . '/app/Models/User.php';
        $content = file_get_contents($modelPath);

        if (strpos($content, 'suspended_at') !== false) {
            $this->warning("User model already contains suspend fields");
            return true;
        }

        if (!$this->dryRun) {
            copy($modelPath, $modelPath . '.backup');
            $this->info("Created backup: User.php.backup");
        }

        $fillablePattern = "/(protected\s+\\\$fillable\s*=\s*\[)([\s\S]*?)(\];)/";
        if (preg_match($fillablePattern, $content, $matches)) {
            $existingFillable = $matches[2];
            $newFillable = rtrim($existingFillable, " \n\r\t,") . ",\n        'suspended_at',\n        'suspended_by',\n        'suspension_reason',\n    ";
            $content = preg_replace($fillablePattern, '$1' . $newFillable . '$3', $content);
        }

        $castsPattern = "/(protected\s+\\\$casts\s*=\s*\[)([\s\S]*?)(\];)/";
        if (preg_match($castsPattern, $content, $matches)) {
            $existingCasts = $matches[2];
            $newCasts = rtrim($existingCasts, " \n\r\t,") . ",\n        'suspended_at' => 'datetime',\n    ";
            $content = preg_replace($castsPattern, '$1' . $newCasts . '$3', $content);
        }

        $relationshipMethod = <<<'PHP'

    public function suspendedBy(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(User::class, 'suspended_by');
    }

    public function isSuspended(): bool
    {
        return !is_null($this->suspended_at);
    }
PHP;

        $content = preg_replace('/}\s*$/', $relationshipMethod . "\n}\n", $content);

        if (!$this->dryRun) {
            file_put_contents($modelPath, $content);
            $this->modifiedFiles[] = $modelPath;
        }

        $this->success("Modified: app/Models/User.php");
        return true;
    }

    private function registerMiddleware(): bool
    {
        $kernelPath = $this->basePath . '/app/Http/Kernel.php';
        $content = file_get_contents($kernelPath);

        if (strpos($content, 'CheckUserSuspension') !== false) {
            $this->warning("Middleware already registered in Kernel.php");
            return true;
        }

        if (!$this->dryRun) {
            copy($kernelPath, $kernelPath . '.backup');
            $this->info("Created backup: Kernel.php.backup");
        }

        $useAdded = false;
        $usePatterns = [
            "/(use Pterodactyl\\\\Http\\\\Middleware\\\\RequireTwoFactorAuthentication;)/",
            "/(use Pterodactyl\\\\Http\\\\Middleware\\\\VerifyCsrfToken;)/",
            "/(use Pterodactyl\\\\Http\\\\Middleware\\\\LanguageMiddleware;)/",
            "/(use Illuminate\\\\Foundation\\\\Http\\\\Kernel as HttpKernel;)/",
        ];
        
        foreach ($usePatterns as $pattern) {
            if (preg_match($pattern, $content)) {
                $content = preg_replace($pattern, "$1\nuse Pterodactyl\\Http\\Middleware\\CheckUserSuspension;", $content, 1);
                $useAdded = true;
                break;
            }
        }

        if (!$useAdded) {
            $content = preg_replace(
                "/(namespace Pterodactyl\\\\Http;)/",
                "$1\n\nuse Pterodactyl\\Http\\Middleware\\CheckUserSuspension;",
                $content
            );
        }

        $middlewareAdded = false;
        
        $webPatterns = [
            "/(LanguageMiddleware::class,)(\s*\])/s",
            "/(SubstituteBindings::class,)(\s*LanguageMiddleware::class)/s",
            "/(VerifyCsrfToken::class,)/",
        ];
        
        foreach ($webPatterns as $i => $pattern) {
            if (preg_match($pattern, $content)) {
                if ($i === 0) {
                    $content = preg_replace($pattern, "$1\n            CheckUserSuspension::class,$2", $content, 1);
                } else if ($i === 1) {
                    $content = preg_replace($pattern, "$1\n            CheckUserSuspension::class,$2", $content, 1);
                } else {
                    $content = preg_replace($pattern, "$1\n            CheckUserSuspension::class,", $content, 1);
                }
                $middlewareAdded = true;
                break;
            }
        }

        if (!$middlewareAdded) {
            if (preg_match("/('web'\s*=>\s*\[)([^\]]+)(\])/s", $content, $matches)) {
                $webMiddleware = $matches[2];
                if (substr(trim($webMiddleware), -1) !== ',') {
                    $webMiddleware = rtrim($webMiddleware) . ",";
                }
                $newWebMiddleware = $webMiddleware . "\n            CheckUserSuspension::class,\n        ";
                $content = str_replace($matches[0], $matches[1] . $newWebMiddleware . $matches[3], $content);
                $middlewareAdded = true;
            }
        }

        if (!$middlewareAdded) {
            $this->error("Could not add middleware to web group. Please add manually.");
            $this->info("Add 'CheckUserSuspension::class,' to the 'web' middleware group in app/Http/Kernel.php");
            return false;
        }

        if (!$this->dryRun) {
            file_put_contents($kernelPath, $content);
            $this->modifiedFiles[] = $kernelPath;
        }

        $this->success("Registered middleware in Kernel.php");
        return true;
    }

    private function registerRoutes(): bool
    {
        $adminRoutesPath = $this->basePath . '/routes/admin.php';
        $content = file_get_contents($adminRoutesPath);

        if (strpos($content, 'suspended-users.php') !== false) {
            $this->warning("Routes already registered in admin.php");
            return true;
        }

        if (!$this->dryRun) {
            copy($adminRoutesPath, $adminRoutesPath . '.backup');
            $this->info("Created backup: admin.php.backup");
        }

        $routeInclude = <<<'PHP'

/*
|--------------------------------------------------------------------------
| User Suspension Addon Routes
|--------------------------------------------------------------------------
*/
require __DIR__ . '/suspended-users.php';
PHP;

        $content .= $routeInclude;

        if (!$this->dryRun) {
            file_put_contents($adminRoutesPath, $content);
            $this->modifiedFiles[] = $adminRoutesPath;
        }

        $source = $this->addonPath . '/routes/suspended-users.php';
        $target = $this->basePath . '/routes/suspended-users.php';
        $this->copyFile($source, $target);

        $this->success("Registered routes in admin.php");
        return true;
    }

    private function registerBaseRoute(): bool
    {
        $baseRoutesPath = $this->basePath . '/routes/base.php';
        $content = file_get_contents($baseRoutesPath);

        if (strpos($content, 'account.suspended') !== false) {
            $this->warning("Suspended route already registered in base.php");
            return true;
        }

        if (!$this->dryRun) {
            copy($baseRoutesPath, $baseRoutesPath . '.backup');
            $this->info("Created backup: base.php.backup");
        }

        $routeCode = <<<'PHP'

Route::get('/suspended', [Base\SuspendedController::class, 'index'])
    ->name('account.suspended');
PHP;

        $content = preg_replace(
            "/(Route::get\('\/account'[^;]+;)/",
            "$1\n" . $routeCode,
            $content,
            1
        );

        if (strpos($content, 'use Pterodactyl\Http\Controllers\Base\SuspendedController') === false) {
            $content = preg_replace(
                "/(use Pterodactyl\\\\Http\\\\Controllers\\\\Base;)/",
                "$1\nuse Pterodactyl\\Http\\Controllers\\Base\\SuspendedController;",
                $content
            );
        }

        if (!$this->dryRun) {
            file_put_contents($baseRoutesPath, $content);
            $this->modifiedFiles[] = $baseRoutesPath;
        }

        $this->success("Registered suspended route in base.php");
        return true;
    }

    private function addNavigationLink(): bool
    {
        $layoutPath = $this->basePath . '/resources/views/layouts/admin.blade.php';
        $content = file_get_contents($layoutPath);

        if (strpos($content, 'admin.suspended-users') !== false) {
            $this->warning("Navigation link already added to admin layout");
            return true;
        }

        if (!$this->dryRun) {
            copy($layoutPath, $layoutPath . '.backup');
            $this->info("Created backup: admin.blade.php.backup");
        }

        $navLink = <<<'HTML'
                        <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.suspended-users') ?: 'active' }}">
                            <a href="{{ route('admin.suspended-users') }}">
                                <i class="fa fa-ban text-danger"></i> <span>Banned Users</span>
                            </a>
                        </li>
HTML;

        $pattern = "/(<li class=\"{{\s*!\s*starts_with\(Route::currentRouteName\(\),\s*'admin\.users'\)[^}]*}}\">[\s\S]*?<\/li>)/";
        $content = preg_replace($pattern, "$1\n" . $navLink, $content, 1);

        if (!$this->dryRun) {
            file_put_contents($layoutPath, $content);
            $this->modifiedFiles[] = $layoutPath;
        }

        $this->success("Added navigation link to admin sidebar");
        return true;
    }

    private function modifyUserViewPage(): bool
    {
        $viewPath = $this->basePath . '/resources/views/admin/users/view.blade.php';
        $content = file_get_contents($viewPath);

        if (strpos($content, 'suspend-user-box') !== false) {
            $this->warning("User view page already modified");
            return true;
        }

        if (!$this->dryRun) {
            copy($viewPath, $viewPath . '.backup');
            $this->info("Created backup: view.blade.php.backup");
        }

        $suspensionBox = <<<'HTML'
    <div class="col-xs-12">
        <div class="box {{ $user->suspended_at ? 'box-success' : 'box-warning' }}" id="suspend-user-box">
            <div class="box-header with-border">
                <h3 class="box-title">{{ $user->suspended_at ? 'User Banned' : 'Ban User' }}</h3>
            </div>
            <div class="box-body">
                @if($user->suspended_at)
                    <div class="callout callout-danger">
                        <h4><i class="fa fa-ban"></i> This user is currently banned</h4>
                        <p>
                            <strong>Banned at:</strong> {{ $user->suspended_at->format('Y-m-d H:i:s') }}<br>
                            @if($user->suspension_reason)
                                <strong>Reason:</strong> {{ $user->suspension_reason }}
                            @endif
                        </p>
                    </div>
                    <p>Click the button below to restore access to this user's account.</p>
                @else
                    <p>Banning this user will immediately log them out and prevent them from accessing their account. Their servers will remain intact.</p>
                    <div class="form-group">
                        <label for="suspension_reason">Reason (Optional)</label>
                        <input type="text" class="form-control" id="suspension_reason" name="reason" placeholder="Enter reason for ban...">
                    </div>
                @endif
            </div>
            <div class="box-footer">
                @if($user->suspended_at)
                    <form action="{{ route('admin.users.unsuspend', $user->id) }}" method="POST" id="unsuspend-form">
                        @csrf
                        <button type="submit" class="btn btn-success">
                            <i class="fa fa-unlock"></i> Unban User
                        </button>
                    </form>
                @else
                    <form action="{{ route('admin.users.suspend', $user->id) }}" method="POST" id="suspend-form">
                        @csrf
                        <input type="hidden" name="reason" id="suspension_reason_hidden">
                        <button type="submit" class="btn btn-danger" {{ $user->root_admin ? 'disabled title="Cannot ban root admin"' : '' }}>
                            <i class="fa fa-ban"></i> Ban User
                        </button>
                        @if($user->root_admin)
                            <p class="text-muted small" style="margin-top: 10px;">Root administrators cannot be banned.</p>
                        @endif
                    </form>
                @endif
            </div>
        </div>
    </div>
HTML;

        $pattern = '/(<div class="col-xs-12">\s*<div class="box box-danger">\s*<div class="box-header with-border">\s*<h3 class="box-title">Delete User<\/h3>)/';
        $content = preg_replace($pattern, $suspensionBox . "\n$1", $content, 1);

        $javascript = <<<'HTML'

@section('footer-scripts')
    @parent
    <script>
        $(document).ready(function() {
            $('#suspend-form').on('submit', function(e) {
                e.preventDefault();
                var reason = $('#suspension_reason').val();
                $('#suspension_reason_hidden').val(reason);
                
                swal({
                    title: 'Ban User?',
                    text: 'This will immediately log the user out and prevent access to their account.',
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d9534f',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, ban!'
                }, function() {
                    $('#suspend-form').off('submit').submit();
                });
            });

            $('#unsuspend-form').on('submit', function(e) {
                e.preventDefault();
                var form = $(this);
                
                swal({
                    title: 'Unban User?',
                    text: 'This will restore access to the user\'s account.',
                    type: 'info',
                    showCancelButton: true,
                    confirmButtonColor: '#00a65a',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, unban!'
                }, function() {
                    form.off('submit').submit();
                });
            });
        });
    </script>
@endsection
HTML;

        if (strpos($content, '@section(\'footer-scripts\')') === false) {
            $content .= $javascript;
        }

        if (!$this->dryRun) {
            file_put_contents($viewPath, $content);
            $this->modifiedFiles[] = $viewPath;
        }

        $this->success("Modified user view page");
        return true;
    }

    private function runMigrations(): bool
    {
        if ($this->dryRun) {
            $this->info("[DRY RUN] Would run: php artisan migrate");
            return true;
        }

        $this->info("Running database migrations...");
        
        $command = "cd " . escapeshellarg($this->basePath) . " && php artisan migrate --force 2>&1";
        $output = shell_exec($command);
        
        if (strpos($output, 'error') !== false || strpos($output, 'Error') !== false) {
            $this->warning("Migration had issues, attempting to fix manually...");
            $this->fixDatabaseColumns();
        }

        $this->success("Database migrations completed");
        return true;
    }

    private function fixDatabaseColumns(): void
    {
        $columns = [
            'suspended_at' => "ALTER TABLE users ADD COLUMN suspended_at TIMESTAMP NULL DEFAULT NULL AFTER updated_at",
            'suspended_by' => "ALTER TABLE users ADD COLUMN suspended_by BIGINT UNSIGNED NULL DEFAULT NULL AFTER suspended_at",
            'suspension_reason' => "ALTER TABLE users ADD COLUMN suspension_reason TEXT NULL DEFAULT NULL AFTER suspended_by",
        ];

        foreach ($columns as $column => $sql) {
            $checkCommand = "cd " . escapeshellarg($this->basePath) . " && php artisan tinker --execute=\"echo Schema::hasColumn('users', '$column') ? 'exists' : 'missing';\" 2>&1";
            $result = trim(shell_exec($checkCommand));
            
            if (strpos($result, 'missing') !== false) {
                $this->info("Adding missing column: $column");
                $addCommand = "cd " . escapeshellarg($this->basePath) . " && php artisan tinker --execute=\"DB::statement(\\\"$sql\\\"); echo 'done';\" 2>&1";
                shell_exec($addCommand);
            }
        }
    }

    private function clearCaches(): bool
    {
        if ($this->dryRun) {
            $this->info("[DRY RUN] Would clear caches");
            return true;
        }

        $this->info("Clearing caches...");
        
        $commands = [
            'config:clear',
            'cache:clear',
            'view:clear',
            'route:clear',
        ];

        foreach ($commands as $cmd) {
            $command = "cd " . escapeshellarg($this->basePath) . " && php artisan $cmd 2>&1";
            shell_exec($command);
        }

        $this->success("Caches cleared");
        return true;
    }

    private function setPermissions(): bool
    {
        if ($this->dryRun) {
            $this->info("[DRY RUN] Would set file permissions");
            return true;
        }

        $webUser = $this->getWebServerUser();
        
        foreach ($this->installedFiles as $file) {
            if (file_exists($file)) {
                @chown($file, $webUser);
                @chgrp($file, $webUser);
                @chmod($file, 0644);
            }
        }

        foreach ($this->modifiedFiles as $file) {
            if (file_exists($file)) {
                @chown($file, $webUser);
                @chgrp($file, $webUser);
                @chmod($file, 0644);
            }
        }

        $this->success("File permissions set (owner: $webUser)");
        return true;
    }

    public function install(bool $dryRun = false): bool
    {
        $this->dryRun = $dryRun;

        $this->header("Pterodactyl User Suspension Addon Installer");

        if ($dryRun) {
            $this->warning("Running in DRY RUN mode - no changes will be made");
            echo PHP_EOL;
        }

        $this->step(1, "Checking permissions...");
        if (!$this->checkPermissions()) {
            return false;
        }

        $this->step(2, "Validating Pterodactyl installation...");
        if (!$this->validateInstallation()) {
            $this->error("This does not appear to be a valid Pterodactyl installation.");
            return false;
        }

        $version = $this->checkVersion();
        $this->info("Pterodactyl version: $version");

        $this->step(3, "Installing database migration...");
        if (!$this->installMigration()) {
            return false;
        }

        $this->step(4, "Installing service...");
        if (!$this->installService()) {
            return false;
        }

        $this->step(5, "Installing middleware...");
        if (!$this->installMiddleware()) {
            return false;
        }

        $this->step(6, "Installing controllers...");
        if (!$this->installControllers()) {
            return false;
        }

        $this->step(7, "Installing views...");
        if (!$this->installViews()) {
            return false;
        }

        $this->step(8, "Modifying User model...");
        if (!$this->modifyUserModel()) {
            return false;
        }

        $this->step(9, "Registering middleware...");
        if (!$this->registerMiddleware()) {
            return false;
        }

        $this->step(10, "Registering routes...");
        if (!$this->registerRoutes()) {
            return false;
        }

        $this->step(11, "Registering base route...");
        if (!$this->registerBaseRoute()) {
            return false;
        }

        $this->step(12, "Adding navigation link...");
        if (!$this->addNavigationLink()) {
            return false;
        }

        $this->step(13, "Modifying user view page...");
        if (!$this->modifyUserViewPage()) {
            return false;
        }

        $this->step(14, "Running database migrations...");
        if (!$this->runMigrations()) {
            return false;
        }

        $this->step(15, "Clearing caches...");
        if (!$this->clearCaches()) {
            return false;
        }

        $this->step(16, "Setting file permissions...");
        if (!$this->setPermissions()) {
            return false;
        }

        echo PHP_EOL;
        $this->header("Installation Complete!");
        $this->log("The User Suspension addon has been successfully installed!", GREEN);
        echo PHP_EOL;
        $this->info("New features available:");
        $this->log("  • Suspend/Unsuspend users from Admin > Users > [User]", CYAN);
        $this->log("  • View all banned users at Admin > Banned Users", CYAN);
        $this->log("  • Suspended users see a custom 'Account Banned' page", CYAN);
        echo PHP_EOL;

        return true;
    }

    public function status(): void
    {
        $this->header("Installation Status Check");

        $checks = [
            'Migration file' => file_exists($this->basePath . '/database/migrations/2025_01_23_000000_add_suspended_at_to_users_table.php'),
            'Service file' => file_exists($this->basePath . '/app/Services/UserSuspensionService.php'),
            'Middleware file' => file_exists($this->basePath . '/app/Http/Middleware/CheckUserSuspension.php'),
            'Admin Controller' => file_exists($this->basePath . '/app/Http/Controllers/Admin/SuspendedUsersController.php'),
            'Base Controller' => file_exists($this->basePath . '/app/Http/Controllers/Base/SuspendedController.php'),
            'Suspended View' => file_exists($this->basePath . '/resources/views/suspended.blade.php'),
            'Admin View' => file_exists($this->basePath . '/resources/views/admin/suspended-users/index.blade.php'),
            'Routes file' => file_exists($this->basePath . '/routes/suspended-users.php'),
        ];

        $allPassed = true;
        foreach ($checks as $name => $status) {
            if ($status) {
                $this->success("$name: Installed");
            } else {
                $this->error("$name: Not installed");
                $allPassed = false;
            }
        }

        echo PHP_EOL;
        if ($allPassed) {
            $this->log("All addon files are installed.", GREEN);
        } else {
            $this->log("Some addon files are missing. Run 'php installer.php install' to install.", YELLOW);
        }
    }

    public function help(): void
    {
        $this->header("User Suspension Addon - Help");
        
        echo "Usage: php installer.php [command] [options]" . PHP_EOL;
        echo PHP_EOL;
        echo "Commands:" . PHP_EOL;
        echo "  install      Install the addon" . PHP_EOL;
        echo "  uninstall    Uninstall the addon (see uninstaller.php)" . PHP_EOL;
        echo "  status       Check installation status" . PHP_EOL;
        echo "  help         Show this help message" . PHP_EOL;
        echo PHP_EOL;
        echo "Options:" . PHP_EOL;
        echo "  --dry-run    Show what would be done without making changes" . PHP_EOL;
        echo PHP_EOL;
    }
}

if (php_sapi_name() !== 'cli') {
    die('This script can only be run from the command line.');
}

$installer = new SuspendUserInstaller();

$command = $argv[1] ?? 'help';
$dryRun = in_array('--dry-run', $argv);

switch ($command) {
    case 'install':
        $success = $installer->install($dryRun);
        exit($success ? 0 : 1);
        break;
    case 'status':
        $installer->status();
        break;
    case 'help':
    default:
        $installer->help();
        break;
}
