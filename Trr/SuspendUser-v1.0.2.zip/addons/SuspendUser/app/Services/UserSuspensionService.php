<?php

namespace Pterodactyl\Services;

use Pterodactyl\Models\User;
use Illuminate\Support\Facades\Auth;

class UserSuspensionService
{
    public function suspend(User $user, string $reason = null): bool
    {
        if ($user->isSuspended()) {
            return false;
        }

        $user->update([
            'suspended_at' => now(),
            'suspended_by' => Auth::id(),
            'suspension_reason' => $reason,
        ]);

        return true;
    }

    public function unsuspend(User $user): bool
    {
        if (!$user->isSuspended()) {
            return false;
        }

        $user->update([
            'suspended_at' => null,
            'suspended_by' => null,
            'suspension_reason' => null,
        ]);

        return true;
    }

    public function getSuspendedUsers()
    {
        return User::whereNotNull('suspended_at')->get();
    }
}
