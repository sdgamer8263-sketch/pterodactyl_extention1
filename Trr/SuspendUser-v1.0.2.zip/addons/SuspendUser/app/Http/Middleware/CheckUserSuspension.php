<?php

namespace Pterodactyl\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CheckUserSuspension
{
    protected array $excludedRoutes = [
        'account.suspended',
        'auth.logout',
        'auth.login',
        'auth.login.checkpoint',
        'auth.password',
        'auth.password.reset',
        'auth.password.reset.update',
    ];

    public function handle(Request $request, Closure $next)
    {
        if (Auth::check()) {
            $user = Auth::user();

            if ($user->isSuspended()) {
                $currentRoute = $request->route()?->getName();

                if (!in_array($currentRoute, $this->excludedRoutes)) {
                    if ($request->expectsJson()) {
                        return response()->json([
                            'error' => 'Your account has been suspended.',
                            'reason' => $user->suspension_reason,
                        ], 403);
                    }

                    return redirect()->route('account.suspended');
                }
            }
        }

        return $next($request);
    }
}
