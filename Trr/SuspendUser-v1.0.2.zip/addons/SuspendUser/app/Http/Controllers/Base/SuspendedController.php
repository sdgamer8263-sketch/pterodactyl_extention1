<?php

namespace Pterodactyl\Http\Controllers\Base;

use Illuminate\Support\Facades\Auth;
use Pterodactyl\Http\Controllers\Controller;

class SuspendedController extends Controller
{
    public function index()
    {
        $user = Auth::user();

        if (!$user || !$user->isSuspended()) {
            return redirect()->route('index');
        }

        return view('suspended', [
            'reason' => $user->suspension_reason,
            'suspendedAt' => $user->suspended_at,
            'suspendedBy' => $user->suspendedBy,
        ]);
    }
}
