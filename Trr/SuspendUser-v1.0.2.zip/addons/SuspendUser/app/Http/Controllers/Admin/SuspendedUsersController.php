<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Pterodactyl\Models\User;
use Pterodactyl\Services\UserSuspensionService;
use Pterodactyl\Http\Controllers\Controller;
use Prologue\Alerts\AlertsMessageBag;
use Illuminate\Support\Facades\DB;

class SuspendedUsersController extends Controller
{
    protected UserSuspensionService $suspensionService;
    protected AlertsMessageBag $alert;

    public function __construct(UserSuspensionService $suspensionService, AlertsMessageBag $alert)
    {
        $this->suspensionService = $suspensionService;
        $this->alert = $alert;
    }

    public function index()
    {
        $suspendedUsers = User::whereNotNull('suspended_at')
            ->with('suspendedBy')
            ->orderBy('suspended_at', 'desc')
            ->paginate(25);

        return view('admin.suspended-users.index', [
            'users' => $suspendedUsers,
        ]);
    }

    public function suspend(Request $request, User $user)
    {
        $request->validate([
            'reason' => 'nullable|string|max:1000',
        ]);

        if ($user->root_admin) {
            $this->alert->danger('Cannot suspend a root administrator.')->flash();
            return redirect()->back();
        }

        if ($this->suspensionService->suspend($user, $request->input('reason'))) {
            $this->alert->success('User has been suspended successfully.')->flash();
            return redirect()->route('admin.users.view', $user->id);
        }

        $this->alert->warning('User is already suspended.')->flash();
        return redirect()->route('admin.users.view', $user->id);
    }

    public function unsuspend(User $user)
    {
        if ($this->suspensionService->unsuspend($user)) {
            $this->alert->success('User has been unsuspended successfully.')->flash();
            return redirect()->route('admin.users.view', $user->id);
        }

        $this->alert->warning('User is not suspended.')->flash();
        return redirect()->route('admin.users.view', $user->id);
    }

    /**
     * Bulk unsuspend multiple users
     */
    public function bulkUnsuspend(Request $request)
    {
        $request->validate([
            'users' => 'required|array|min:1',
            'users.*' => 'integer|exists:users,id',
        ]);

        $userIds = $request->input('users');
        $unsuspendedCount = 0;
        $skippedCount = 0;

        foreach ($userIds as $userId) {
            $user = User::find($userId);
            if ($user && $user->isSuspended()) {
                $this->suspensionService->unsuspend($user);
                $unsuspendedCount++;
            } else {
                $skippedCount++;
            }
        }

        if ($unsuspendedCount > 0) {
            $this->alert->success("Successfully unbanned {$unsuspendedCount} user(s)." . ($skippedCount > 0 ? " {$skippedCount} user(s) were skipped." : ''))->flash();
        } else {
            $this->alert->warning('No users were unbanned.')->flash();
        }

        return redirect()->route('admin.suspended-users');
    }

    /**
     * Bulk delete multiple users
     */
    public function bulkDelete(Request $request)
    {
        $request->validate([
            'users' => 'required|array|min:1',
            'users.*' => 'integer|exists:users,id',
        ]);

        $userIds = $request->input('users');
        $deletedCount = 0;
        $skippedCount = 0;
        $errors = [];

        foreach ($userIds as $userId) {
            $user = User::find($userId);
            if (!$user) {
                $skippedCount++;
                continue;
            }

            // Don't delete root admins
            if ($user->root_admin) {
                $errors[] = "Cannot delete root administrator: {$user->username}";
                $skippedCount++;
                continue;
            }

            // Check if user has servers
            if ($user->servers()->count() > 0) {
                $errors[] = "User {$user->username} has servers attached. Please delete or transfer their servers first.";
                $skippedCount++;
                continue;
            }

            try {
                DB::transaction(function () use ($user) {
                    // Delete user's API keys
                    $user->apiKeys()->delete();
                    
                    // Delete user's SSH keys
                    $user->sshKeys()->delete();
                    
                    // Delete user's recovery tokens
                    $user->recoveryTokens()->delete();
                    
                    // Delete the user
                    $user->delete();
                });
                $deletedCount++;
            } catch (\Exception $e) {
                $errors[] = "Failed to delete user {$user->username}: " . $e->getMessage();
                $skippedCount++;
            }
        }

        if ($deletedCount > 0) {
            $message = "Successfully deleted {$deletedCount} user(s).";
            if ($skippedCount > 0) {
                $message .= " {$skippedCount} user(s) were skipped.";
            }
            $this->alert->success($message)->flash();
        } else {
            $this->alert->danger('No users were deleted. ' . implode(' ', $errors))->flash();
        }

        return redirect()->route('admin.suspended-users');
    }
}
