# Pterodactyl User Suspension Addon

<p align="center">
  <img src="screenshots/suspended-page.png" alt="Suspended Page Preview" width="600">
</p>

## 📋 Deskripsi

**User Suspension Addon** adalah addon gratis dan open-source untuk Pterodactyl Panel yang memungkinkan administrator untuk melakukan suspend (ban) dan unsuspend (unban) user secara langsung dari Admin Panel.

Ketika user di-suspend, mereka tidak akan dapat mengakses dashboard dan akan melihat halaman khusus yang menampilkan pesan bahwa akun mereka telah dibanned.

---

## 🖼️ Pratinjau Screenshot

### Halaman User yang Dibanned
User yang dibanned akan melihat halaman khusus dengan desain modern yang menampilkan:
- Informasi akun (username, email)
- Tanggal suspend
- Admin yang melakukan suspend
- Alasan penangguhan

<p align="center">
  <img src="screenshots/suspended-page.png" alt="Halaman User Suspended" width="700">
</p>

### Manajemen User Banned
Halaman admin untuk mengelola semua user yang dibanned dengan fitur:
- Total statistik user banned
- Tabel daftar user dengan info lengkap
- Checkbox selection untuk memilih user
- Select All untuk pilih semua user
- Bulk Action Bar dengan tombol Unban & Delete
- Tombol Unban individual

<p align="center">
  <img src="screenshots/banned-users-list.png" alt="Manajemen User Banned" width="700">
</p>

### Detail User - Status Suspend
Di halaman detail user, admin dapat melihat status suspend dan melakukan unsuspend:

<p align="center">
  <img src="screenshots/user-suspended-detail.png" alt="User Suspended Detail" width="700">
</p>

---

## ✨ Fitur

- ✅ **Suspend User** - Ban user langsung dari halaman User Management
- ✅ **Unsuspend User** - Buka suspend user kapan saja
- ✅ **Halaman Banned** - User yang di-suspend melihat halaman khusus dengan desain modern
- ✅ **Manajemen User Banned** - Halaman khusus di Admin Panel untuk mengelola semua user yang di-suspend
- ✅ **Checkbox Selection** - Pilih user satu per satu dengan checkbox
- ✅ **Select All** - Pilih semua user sekaligus dengan satu klik
- ✅ **Bulk Unsuspend** - Unban beberapa user sekaligus
- ✅ **Bulk Delete** - Hapus permanen beberapa user sekaligus (dengan double confirmation)
- ✅ **Bulk Action Bar** - Panel aksi yang muncul otomatis saat ada user dipilih
- ✅ **Alasan Suspend** - Tampilkan alasan penangguhan ke user
- ✅ **Info Admin** - Tampilkan admin mana yang melakukan suspend
- ✅ **Redirect Otomatis** - Otomatis redirect user sesuai status suspension
- ✅ **Invalidasi Session** - Logout otomatis semua session user yang di-suspend
- ✅ **Proteksi Root Admin** - Root admin tidak bisa di-suspend/dihapus
- ✅ **Proteksi User dengan Server** - User dengan server attached tidak bisa dihapus

---

## 📁 Struktur Addon

```
addons/SuspendUser/
├── README.md                           # Dokumentasi addon
├── installer.php                       # Script installer otomatis
├── LICENSE                             # Lisensi MIT
├── install.sh                          # Script installer interaktif
├── installer.php                       # Script installer PHP
├── uninstaller.php                     # Script uninstaller
├── screenshots/                        # Folder pratinjau screenshot
│   ├── suspended-page.png
│   ├── banned-users-list.png
│   └── user-suspended-detail.png
├── app/
│   ├── Http/
│   │   ├── Controllers/
│   │   │   ├── Admin/
│   │   │   │   └── SuspendedUsersController.php # Controller untuk kelola user suspended
│   │   │   └── Base/
│   │   │       └── SuspendedController.php      # Controller untuk halaman suspended
│   │   └── Middleware/
│   │       └── CheckUserSuspension.php          # Middleware untuk cek status suspend
│   └── Services/
│       └── UserSuspensionService.php            # Service untuk menangani suspend/unsuspend
├── database/
│   └── migrations/
│       └── 2025_01_23_000000_add_suspended_at_to_users_table.php
├── resources/
│   └── views/
│       ├── suspended.blade.php                  # Halaman untuk user yang di-suspend
│       └── admin/
│           └── suspended-users/
│               └── index.blade.php              # Halaman kelola user banned
└── routes/
    └── suspended-users.php                      # Rute untuk addon
```

---

## 🔧 Persyaratan Sistem

- Pterodactyl Panel v1.11.x - v1.12.x atau lebih baru
- PHP 8.1 atau lebih tinggi
- MySQL 8.0 atau MariaDB 10.5+

---

## 📥 Cara Install

### Metode 1: Interactive Installer (Direkomendasikan)

1. Upload folder `SuspendUser` ke direktori `/var/www/pterodactyl/addons/`

2. Jalankan interactive installer:
```bash
cd /var/www/pterodactyl/addons/SuspendUser
chmod +x install.sh
sudo ./install.sh
```

3. Pilih opsi `[1] Install Addon` dari menu

4. Addon siap digunakan!

### Metode 2: PHP Installer

```bash
cd /var/www/pterodactyl
sudo php addons/SuspendUser/installer.php install
```

### Metode 3: Manual Installation

Jika installer otomatis tidak bekerja, ikuti langkah berikut:

**Step 1: Copy file-file addon**
```bash
cd /var/www/pterodactyl

# Copy migration
cp addons/SuspendUser/database/migrations/2025_01_23_000000_add_suspended_at_to_users_table.php database/migrations/

# Copy service
cp addons/SuspendUser/app/Services/UserSuspensionService.php app/Services/

# Copy middleware
cp addons/SuspendUser/app/Http/Middleware/CheckUserSuspension.php app/Http/Middleware/

# Copy controllers
cp addons/SuspendUser/app/Http/Controllers/Admin/SuspendedUsersController.php app/Http/Controllers/Admin/
cp addons/SuspendUser/app/Http/Controllers/Base/SuspendedController.php app/Http/Controllers/Base/

# Copy views
cp addons/SuspendUser/resources/views/suspended.blade.php resources/views/
mkdir -p resources/views/admin/suspended-users
cp addons/SuspendUser/resources/views/admin/suspended-users/index.blade.php resources/views/admin/suspended-users/

# Copy routes
cp addons/SuspendUser/routes/suspended-users.php routes/
```

**Step 2: Edit app/Models/User.php**

Tambahkan ke array `$fillable`:
```php
'suspended_at',
'suspended_by',
'suspension_reason',
```

Tambahkan ke array `$casts`:
```php
'suspended_at' => 'datetime',
```

Tambahkan method di akhir class:
```php
public function suspendedBy(): \Illuminate\Database\Eloquent\Relations\BelongsTo
{
    return $this->belongsTo(User::class, 'suspended_by');
}

public function isSuspended(): bool
{
    return !is_null($this->suspended_at);
}
```

**Step 3: Edit app/Http/Kernel.php**

Tambahkan use statement di bagian atas:
```php
use Pterodactyl\Http\Middleware\CheckUserSuspension;
```

Tambahkan ke middleware group `'web'`:
```php
'web' => [
    EncryptCookies::class,
    AddQueuedCookiesToResponse::class,
    StartSession::class,
    ShareErrorsFromSession::class,
    VerifyCsrfToken::class,
    SubstituteBindings::class,
    LanguageMiddleware::class,
    CheckUserSuspension::class,  // <-- Tambahkan ini
],
```

**Step 4: Edit routes/admin.php**

Tambahkan di akhir file:
```php
require __DIR__ . '/suspended-users.php';
```

**Step 5: Edit routes/base.php**

Tambahkan use statement:
```php
use Pterodactyl\Http\Controllers\Base\SuspendedController;
```

Tambahkan route (setelah route `/account`):
```php
Route::get('/suspended', [SuspendedController::class, 'index'])
    ->name('account.suspended');
```

**Step 6: Jalankan migration dan clear cache**
```bash
php artisan migrate
php artisan config:clear
php artisan cache:clear
php artisan view:clear
php artisan route:clear
```

---

## 🗑️ Cara Uninstall

### Menggunakan Interactive Installer
```bash
cd /var/www/pterodactyl/addons/SuspendUser
sudo ./install.sh
# Pilih opsi [2] Uninstall Addon
```

### Menggunakan PHP Uninstaller
```bash
cd /var/www/pterodactyl
sudo php addons/SuspendUser/uninstaller.php uninstall
```

**PERINGATAN:** Uninstall akan menghapus kolom suspend dari tabel users. Pastikan backup database sebelum uninstall.

---

## 📖 Cara Penggunaan

### Suspend User

1. Login ke Admin Panel
2. Buka **Users** dari menu sidebar
3. Klik user yang ingin di-suspend
4. Scroll ke bawah ke section "Suspend User"
5. Isi alasan (opsional) dan klik tombol **Suspend User**

### Unsuspend User

**Dari halaman user:**
1. Buka halaman user yang di-suspend
2. Klik tombol **Unsuspend User** (berwarna hijau)

**Dari halaman Banned Users:**
1. Klik **Banned Users** di menu sidebar
2. Klik tombol **Unban** di sebelah user

**Bulk Unsuspend:**
1. Buka halaman **Banned Users**
2. Centang user yang ingin di-unsuspend (atau klik Select All)
3. Klik tombol **Unban Selected** di Bulk Action Bar
4. Konfirmasi aksi

### Delete User (Hapus Permanen)

**Bulk Delete:**
1. Buka halaman **Banned Users**
2. Centang user yang ingin dihapus (atau klik Select All)
3. Klik tombol **Delete Selected** di Bulk Action Bar
4. Konfirmasi pertama akan muncul
5. Ketik "DELETE" untuk konfirmasi akhir

**Catatan Delete:**
- Root Admin tidak bisa dihapus
- User yang memiliki server tidak bisa dihapus (hapus/transfer server terlebih dahulu)
- Data yang dihapus: user account, API keys, SSH keys, recovery tokens

---

## ⚙️ Fitur Redirect Otomatis

Addon ini memiliki sistem redirect otomatis:

| Kondisi | Dialihkan ke |
|---------|-------------|
| User suspended mengakses dashboard | → `/suspended` |
| User tidak suspended mengakses `/suspended` | → `/` (dashboard) |
| User logout | → Halaman login |

---

## ⚠️ Catatan Keamanan

1. **Hanya Admin** yang dapat mengakses fitur suspend/unsuspend/delete
2. **Root Admin tidak dapat di-suspend atau dihapus** untuk mencegah lockout
3. **User dengan server tidak dapat dihapus** - harus hapus/transfer server terlebih dahulu
4. **Delete memerlukan double confirmation** - harus ketik "DELETE" untuk mengkonfirmasi
5. Suspend user akan otomatis **logout semua session** user tersebut
6. Server yang dimiliki user **tidak terpengaruh** oleh suspend user

---

## 🔄 Kompatibilitas

| Versi Pterodactyl | Versi Addon | Status |
|-------------------|-------------|--------|
| 1.12.x            | 1.0.x       | ✅ Didukung Penuh |
| 1.11.x            | 1.0.x       | ✅ Didukung |
| 1.10.x            | 1.0.x       | ⚠️ Belum Diuji |
| < 1.10.x          | -           | ❌ Tidak Didukung |

---

## 🐛 Pemecahan Masalah

### Error: "Class not found"
```bash
composer dump-autoload
```

### Error: "Column already exists" saat install
Kolom sudah ada dari instalasi sebelumnya. Jalankan:
```bash
php artisan migrate:fresh --seed
```
Atau abaikan error tersebut.

### User masih bisa login setelah suspend
```bash
php artisan cache:clear
```

### Halaman Banned Users tidak muncul di sidebar
```bash
php artisan view:clear
```

### Error 500 di halaman /suspended
Pastikan user sudah login dan cek error log di `storage/logs/laravel-*.log`

---

## 📧 Bantuan & Dukungan

Untuk bantuan dan pertanyaan, hubungi:
- **GitHub:** [ClouviaID/SuspendUser](https://github.com/ClouviaID/SuspendUser)
- **Email:** s.rainstoreid@gmail.com
- **Grup WhatsApp:** [Gabung Grup](https://chat.whatsapp.com/I9TD1kQM9kKAeFVzzChysJ?mode=gi_t)

---

## 📝 Riwayat Perubahan

### Versi 1.0.0 (2026-01-23)
- 🎉 Rilis pertama
- ✅ Fitur suspend/unsuspend user
- ✅ Halaman manajemen user yang dibanned
- ✅ Halaman khusus untuk user yang di-suspend dengan desain modern
- ✅ Dukungan alasan penangguhan
- ✅ Tampilan info admin yang melakukan suspend
- ✅ Checkbox selection untuk memilih user
- ✅ Select All untuk pilih semua user sekaligus
- ✅ Bulk Action Bar dengan counter user terpilih
- ✅ Fitur bulk unsuspend (unban banyak user sekaligus)
- ✅ Fitur bulk delete (hapus permanen banyak user sekaligus)
- ✅ Double confirmation untuk delete (ketik "DELETE")
- ✅ Proteksi root admin (tidak bisa suspend/delete)
- ✅ Proteksi user dengan server (tidak bisa delete)
- ✅ Sistem redirect otomatis
- ✅ Invalidasi session saat suspend
- ✅ Script installer interaktif bash (install.sh)

---

## 📄 Lisensi

Proyek ini dilisensikan di bawah Lisensi MIT - lihat file [LICENSE](LICENSE) untuk detail.

---

<p align="center">
  <b>© 2026 ClouviaID. Hak cipta dilindungi.</b><br>
  <sub>Dibuat dengan ❤️ untuk komunitas Pterodactyl</sub>
</p>
