<?php

use Illuminate\Support\Facades\Route;
use Pterodactyl\Http\Controllers\Admin\SuspendedUsersController;

/*
|--------------------------------------------------------------------------
| Suspended Users Management Routes
|--------------------------------------------------------------------------
*/
Route::group(['prefix' => 'suspended-users'], function () {
    Route::get('/', [SuspendedUsersController::class, 'index'])->name('admin.suspended-users');
    Route::post('/bulk-unsuspend', [SuspendedUsersController::class, 'bulkUnsuspend'])->name('admin.suspended-users.bulk-unsuspend');
    Route::post('/bulk-delete', [SuspendedUsersController::class, 'bulkDelete'])->name('admin.suspended-users.bulk-delete');
});

/*
|--------------------------------------------------------------------------
| User Suspend/Unsuspend Actions (within users group)
|--------------------------------------------------------------------------
*/
Route::group(['prefix' => 'users'], function () {
    Route::post('/view/{user:id}/suspend', [SuspendedUsersController::class, 'suspend'])->name('admin.users.suspend');
    Route::post('/view/{user:id}/unsuspend', [SuspendedUsersController::class, 'unsuspend'])->name('admin.users.unsuspend');
});
