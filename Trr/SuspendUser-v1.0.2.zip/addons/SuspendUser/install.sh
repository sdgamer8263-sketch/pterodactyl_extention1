#!/bin/bash

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
WHITE='\033[1;37m'
NC='\033[0m'
BOLD='\033[1m'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PTERODACTYL_DIR="$(dirname "$(dirname "$SCRIPT_DIR")")"

print_banner() {
    clear
    echo -e "${CYAN}${BOLD}"
    echo "╔══════════════════════════════════════════════════════════════════╗"
    echo "║                                                                  ║"
    echo "║     ██████╗██╗      ██████╗ ██╗   ██╗██╗   ██╗██╗ █████╗        ║"
    echo "║    ██╔════╝██║     ██╔═══██╗██║   ██║██║   ██║██║██╔══██╗       ║"
    echo "║    ██║     ██║     ██║   ██║██║   ██║██║   ██║██║███████║       ║"
    echo "║    ██║     ██║     ██║   ██║██║   ██║╚██╗ ██╔╝██║██╔══██║       ║"
    echo "║    ╚██████╗███████╗╚██████╔╝╚██████╔╝ ╚████╔╝ ██║██║  ██║       ║"
    echo "║     ╚═════╝╚══════╝ ╚═════╝  ╚═════╝   ╚═══╝  ╚═╝╚═╝  ╚═╝       ║"
    echo "║                                                                  ║"
    echo "║            User Suspension Addon for Pterodactyl                 ║"
    echo "║                      Version 1.0.1                               ║"
    echo "║                                                                  ║"
    echo "╚══════════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
    echo ""
}

print_menu() {
    echo -e "${WHITE}${BOLD}Select an option:${NC}"
    echo ""
    echo -e "  ${GREEN}[1]${NC} Install Addon"
    echo -e "  ${RED}[2]${NC} Uninstall Addon"
    echo -e "  ${BLUE}[3]${NC} Check Installation Status"
    echo -e "  ${YELLOW}[4]${NC} Reinstall Addon (Uninstall + Install)"
    echo -e "  ${CYAN}[5]${NC} Clear All Caches"
    echo -e "  ${MAGENTA}[6]${NC} View README"
    echo -e "  ${WHITE}[7]${NC} Help"
    echo -e "  ${RED}[0]${NC} Exit"
    echo ""
}

check_root() {
    if [[ $EUID -ne 0 ]]; then
        echo -e "${RED}This script must be run as root${NC}"
        echo -e "${YELLOW}Try: sudo ./install.sh${NC}"
        exit 1
    fi
}

check_pterodactyl() {
    if [[ ! -f "$PTERODACTYL_DIR/artisan" ]]; then
        echo -e "${RED}Pterodactyl installation not found at: $PTERODACTYL_DIR${NC}"
        echo -e "${YELLOW}Make sure this addon is placed in the 'addons' folder of your Pterodactyl installation.${NC}"
        exit 1
    fi
}

press_enter() {
    echo ""
    echo -e "${CYAN}Press Enter to continue...${NC}"
    read
}

install_addon() {
    echo ""
    echo -e "${GREEN}${BOLD}Installing Addon...${NC}"
    echo ""
    
    cd "$PTERODACTYL_DIR"
    php "$SCRIPT_DIR/installer.php" install
    
    if [[ $? -eq 0 ]]; then
        echo ""
        echo -e "${GREEN}${BOLD}Installation completed successfully!${NC}"
    else
        echo ""
        echo -e "${RED}${BOLD}Installation failed. Check the errors above.${NC}"
    fi
    
    press_enter
}

uninstall_addon() {
    echo ""
    echo -e "${RED}${BOLD}Uninstalling Addon...${NC}"
    echo ""
    
    echo -e "${YELLOW}WARNING: This will remove all addon files and database columns!${NC}"
    echo -e "${YELLOW}Make sure you have a backup before proceeding.${NC}"
    echo ""
    read -p "Are you sure you want to uninstall? (yes/no): " confirm
    
    if [[ "$confirm" == "yes" ]]; then
        cd "$PTERODACTYL_DIR"
        echo "yes" | php "$SCRIPT_DIR/uninstaller.php" uninstall
        
        if [[ $? -eq 0 ]]; then
            echo ""
            echo -e "${GREEN}${BOLD}Uninstallation completed successfully!${NC}"
        else
            echo ""
            echo -e "${RED}${BOLD}Uninstallation failed. Check the errors above.${NC}"
        fi
    else
        echo ""
        echo -e "${CYAN}Uninstallation cancelled.${NC}"
    fi
    
    press_enter
}

check_status() {
    echo ""
    echo -e "${BLUE}${BOLD}Checking Installation Status...${NC}"
    echo ""
    
    cd "$PTERODACTYL_DIR"
    php "$SCRIPT_DIR/installer.php" status
    
    press_enter
}

reinstall_addon() {
    echo ""
    echo -e "${YELLOW}${BOLD}Reinstalling Addon...${NC}"
    echo ""
    
    echo -e "${YELLOW}This will uninstall and then reinstall the addon.${NC}"
    read -p "Are you sure? (yes/no): " confirm
    
    if [[ "$confirm" == "yes" ]]; then
        echo ""
        echo -e "${RED}Step 1: Uninstalling...${NC}"
        cd "$PTERODACTYL_DIR"
        echo "yes" | php "$SCRIPT_DIR/uninstaller.php" uninstall
        
        echo ""
        echo -e "${GREEN}Step 2: Installing...${NC}"
        php "$SCRIPT_DIR/installer.php" install
        
        echo ""
        echo -e "${GREEN}${BOLD}Reinstallation completed!${NC}"
    else
        echo ""
        echo -e "${CYAN}Reinstallation cancelled.${NC}"
    fi
    
    press_enter
}

clear_caches() {
    echo ""
    echo -e "${CYAN}${BOLD}Clearing All Caches...${NC}"
    echo ""
    
    cd "$PTERODACTYL_DIR"
    
    echo -e "${BLUE}Clearing config cache...${NC}"
    php artisan config:clear
    
    echo -e "${BLUE}Clearing route cache...${NC}"
    php artisan route:clear
    
    echo -e "${BLUE}Clearing view cache...${NC}"
    php artisan view:clear
    
    echo -e "${BLUE}Clearing application cache...${NC}"
    php artisan cache:clear
    
    echo -e "${BLUE}Optimizing...${NC}"
    php artisan optimize:clear
    
    echo ""
    echo -e "${GREEN}${BOLD}All caches cleared successfully!${NC}"
    
    press_enter
}

view_readme() {
    echo ""
    if [[ -f "$SCRIPT_DIR/README.md" ]]; then
        if command -v less &> /dev/null; then
            less "$SCRIPT_DIR/README.md"
        elif command -v more &> /dev/null; then
            more "$SCRIPT_DIR/README.md"
        else
            cat "$SCRIPT_DIR/README.md"
            press_enter
        fi
    else
        echo -e "${RED}README.md not found${NC}"
        press_enter
    fi
}

show_help() {
    echo ""
    echo -e "${WHITE}${BOLD}HELP${NC}"
    echo ""
    echo -e "${GREEN}[1] Install Addon${NC}"
    echo "    Installs the User Suspension addon to your Pterodactyl panel."
    echo "    This will copy all necessary files and run database migrations."
    echo ""
    echo -e "${RED}[2] Uninstall Addon${NC}"
    echo "    Completely removes the addon from your Pterodactyl panel."
    echo "    WARNING: This will remove the suspended_at column from users table!"
    echo ""
    echo -e "${BLUE}[3] Check Status${NC}"
    echo "    Shows the current installation status of the addon."
    echo "    Lists all installed files and checks for any issues."
    echo ""
    echo -e "${YELLOW}[4] Reinstall Addon${NC}"
    echo "    Performs a complete uninstall followed by a fresh install."
    echo "    Useful for fixing issues or updating the addon."
    echo ""
    echo -e "${CYAN}[5] Clear Caches${NC}"
    echo "    Clears all Laravel caches (config, route, view, application)."
    echo "    Run this after any changes to see immediate effects."
    echo ""
    echo -e "${MAGENTA}[6] View README${NC}"
    echo "    Opens the README.md file with documentation."
    echo ""
    echo -e "${WHITE}${BOLD}Support:${NC}"
    echo "  Email: s.rainstoreid@gmail.com"
    echo "  GitHub: https://github.com/ClouviaID/SuspendUser"
    echo ""
    
    press_enter
}

check_root
check_pterodactyl

while true; do
    print_banner
    print_menu
    
    read -p "Enter your choice [0-7]: " choice
    
    case $choice in
        1)
            install_addon
            ;;
        2)
            uninstall_addon
            ;;
        3)
            check_status
            ;;
        4)
            reinstall_addon
            ;;
        5)
            clear_caches
            ;;
        6)
            view_readme
            ;;
        7)
            show_help
            ;;
        0)
            echo ""
            echo -e "${CYAN}Thank you for using ClouviaID User Suspension Addon!${NC}"
            echo -e "${GREEN}Goodbye!${NC}"
            echo ""
            exit 0
            ;;
        *)
            echo -e "${RED}Invalid option. Please try again.${NC}"
            sleep 1
            ;;
    esac
done
