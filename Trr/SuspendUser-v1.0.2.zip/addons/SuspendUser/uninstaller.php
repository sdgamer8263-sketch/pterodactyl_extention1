#!/usr/bin/env php
<?php

define('RED', "\033[31m");
define('GREEN', "\033[32m");
define('YELLOW', "\033[33m");
define('BLUE', "\033[34m");
define('CYAN', "\033[36m");
define('RESET', "\033[0m");
define('BOLD', "\033[1m");

define('ADDON_DIR', __DIR__);
define('BASE_DIR', dirname(dirname(__DIR__)));

class SuspendUserUninstaller
{
    private string $basePath;
    private string $addonPath;
    private bool $dryRun = false;

    public function __construct()
    {
        $this->basePath = BASE_DIR;
        $this->addonPath = ADDON_DIR;
    }

    private function log(string $message, string $color = RESET): void
    {
        echo $color . $message . RESET . PHP_EOL;
    }

    private function header(string $title): void
    {
        echo PHP_EOL;
        echo RED . BOLD . "╔══════════════════════════════════════════════════════════════╗" . RESET . PHP_EOL;
        echo RED . BOLD . "║" . str_pad(" " . $title, 63) . "║" . RESET . PHP_EOL;
        echo RED . BOLD . "╚══════════════════════════════════════════════════════════════╝" . RESET . PHP_EOL;
        echo PHP_EOL;
    }

    private function step(int $num, string $message): void
    {
        echo BLUE . "[Step $num] " . RESET . $message . PHP_EOL;
    }

    private function success(string $message): void
    {
        echo GREEN . "  ✓ " . RESET . $message . PHP_EOL;
    }

    private function error(string $message): void
    {
        echo RED . "  ✗ " . RESET . $message . PHP_EOL;
    }

    private function warning(string $message): void
    {
        echo YELLOW . "  ⚠ " . RESET . $message . PHP_EOL;
    }

    private function info(string $message): void
    {
        echo CYAN . "  ℹ " . RESET . $message . PHP_EOL;
    }

    private function validatePterodactyl(): bool
    {
        $requiredFiles = [
            'artisan',
            'composer.json',
            'app/Models/User.php',
        ];

        foreach ($requiredFiles as $file) {
            if (!file_exists($this->basePath . '/' . $file)) {
                $this->error("Required file not found: $file");
                $this->error("Base path: " . $this->basePath);
                return false;
            }
        }

        $this->success("Pterodactyl installation validated at: " . $this->basePath);
        return true;
    }

    private function removeFiles(): bool
    {
        $files = [
            'database/migrations/2025_01_23_000000_add_suspended_at_to_users_table.php',
            'app/Services/UserSuspensionService.php',
            'app/Http/Middleware/CheckUserSuspension.php',
            'app/Http/Controllers/Admin/SuspendedUsersController.php',
            'app/Http/Controllers/Base/SuspendedController.php',
            'resources/views/suspended.blade.php',
            'resources/views/admin/suspended-users/index.blade.php',
            'routes/suspended-users.php',
        ];

        foreach ($files as $file) {
            $fullPath = $this->basePath . '/' . $file;
            if (file_exists($fullPath)) {
                if (!$this->dryRun) {
                    unlink($fullPath);
                }
                $this->success("Removed: $file");
            } else {
                $this->info("Already removed: $file");
            }
        }

        $dirs = [
            'resources/views/admin/suspended-users',
        ];

        foreach ($dirs as $dir) {
            $fullPath = $this->basePath . '/' . $dir;
            if (is_dir($fullPath) && count(scandir($fullPath)) == 2) {
                if (!$this->dryRun) {
                    rmdir($fullPath);
                }
                $this->success("Removed empty directory: $dir");
            }
        }

        return true;
    }

    private function restoreUserModel(): bool
    {
        $modelPath = $this->basePath . '/app/Models/User.php';
        $backupPath = $modelPath . '.backup';

        if (file_exists($backupPath)) {
            if (!$this->dryRun) {
                copy($backupPath, $modelPath);
                unlink($backupPath);
            }
            $this->success("Restored User.php from backup");
            return true;
        }

        if (!file_exists($modelPath)) {
            $this->warning("User.php not found at: $modelPath");
            return true;
        }

        $content = file_get_contents($modelPath);
        
        $content = preg_replace("/,?\s*'suspended_at',?\s*/", '', $content);
        $content = preg_replace("/,?\s*'suspended_by',?\s*/", '', $content);
        $content = preg_replace("/,?\s*'suspension_reason',?\s*/", '', $content);

        $content = preg_replace("/,?\s*'suspended_at'\s*=>\s*'datetime',?\s*/", '', $content);

        $content = preg_replace("/\s*public function suspendedBy\(\)[^}]+\{[^}]+\}\s*/s", '', $content);
        $content = preg_replace("/\s*public function isSuspended\(\)[^}]+\{[^}]+\}\s*/s", '', $content);

        if (!$this->dryRun) {
            file_put_contents($modelPath, $content);
        }

        $this->success("Cleaned up User.php");
        return true;
    }

    private function restoreKernel(): bool
    {
        $kernelPath = $this->basePath . '/app/Http/Kernel.php';
        $backupPath = $kernelPath . '.backup';

        if (file_exists($backupPath)) {
            if (!$this->dryRun) {
                copy($backupPath, $kernelPath);
                unlink($backupPath);
            }
            $this->success("Restored Kernel.php from backup");
            return true;
        }

        if (!file_exists($kernelPath)) {
            $this->warning("Kernel.php not found at: $kernelPath");
            return true;
        }

        $content = file_get_contents($kernelPath);
        
        $content = preg_replace("/use Pterodactyl\\\\Http\\\\Middleware\\\\CheckUserSuspension;\n?/", '', $content);
        
        $content = preg_replace("/\s*CheckUserSuspension::class,?\n?/", '', $content);

        if (!$this->dryRun) {
            file_put_contents($kernelPath, $content);
        }

        $this->success("Cleaned up Kernel.php");
        return true;
    }

    private function restoreAdminRoutes(): bool
    {
        $routesPath = $this->basePath . '/routes/admin.php';
        $backupPath = $routesPath . '.backup';

        if (file_exists($backupPath)) {
            if (!$this->dryRun) {
                copy($backupPath, $routesPath);
                unlink($backupPath);
            }
            $this->success("Restored admin.php from backup");
            return true;
        }

        if (!file_exists($routesPath)) {
            $this->warning("admin.php not found at: $routesPath");
            return true;
        }

        $content = file_get_contents($routesPath);
        
        $content = preg_replace("/\n*\/\*[\s\S]*?User Suspension Addon Routes[\s\S]*?\*\/\s*\n?/", '', $content);
        $content = preg_replace("/require __DIR__ \. '\/suspended-users\.php';\s*\n?/", '', $content);

        if (!$this->dryRun) {
            file_put_contents($routesPath, $content);
        }

        $this->success("Cleaned up admin.php");
        return true;
    }

    private function restoreBaseRoutes(): bool
    {
        $routesPath = $this->basePath . '/routes/base.php';
        $backupPath = $routesPath . '.backup';

        if (file_exists($backupPath)) {
            if (!$this->dryRun) {
                copy($backupPath, $routesPath);
                unlink($backupPath);
            }
            $this->success("Restored base.php from backup");
            return true;
        }

        if (!file_exists($routesPath)) {
            $this->warning("base.php not found at: $routesPath");
            return true;
        }

        $content = file_get_contents($routesPath);
        
        $content = preg_replace("/use Pterodactyl\\\\Http\\\\Controllers\\\\Base\\\\SuspendedController;\n?/", '', $content);
        
        $content = preg_replace("/\n*Route::get\('\/suspended'[\s\S]*?->name\('account\.suspended'\);\s*\n?/", '', $content);

        if (!$this->dryRun) {
            file_put_contents($routesPath, $content);
        }

        $this->success("Cleaned up base.php");
        return true;
    }

    private function restoreAdminLayout(): bool
    {
        $layoutPath = $this->basePath . '/resources/views/layouts/admin.blade.php';
        $backupPath = $layoutPath . '.backup';

        if (file_exists($backupPath)) {
            if (!$this->dryRun) {
                copy($backupPath, $layoutPath);
                unlink($backupPath);
            }
            $this->success("Restored admin.blade.php from backup");
            return true;
        }

        if (!file_exists($layoutPath)) {
            $this->warning("admin.blade.php not found at: $layoutPath");
            return true;
        }

        $content = file_get_contents($layoutPath);
        
        $content = preg_replace("/\s*<li class=\"{{\s*!\s*starts_with\(Route::currentRouteName\(\),\s*'admin\.suspended-users'\)[^}]*}}\">\s*<a href=\"{{\s*route\('admin\.suspended-users'\)\s*}}\">\s*<i class=\"fa fa-ban text-danger\"><\/i>\s*<span>Banned Users<\/span>\s*<\/a>\s*<\/li>\n?/", '', $content);

        if (!$this->dryRun) {
            file_put_contents($layoutPath, $content);
        }

        $this->success("Cleaned up admin.blade.php");
        return true;
    }

    private function restoreUserView(): bool
    {
        $viewPath = $this->basePath . '/resources/views/admin/users/view.blade.php';
        $backupPath = $viewPath . '.backup';

        if (file_exists($backupPath)) {
            if (!$this->dryRun) {
                copy($backupPath, $viewPath);
                unlink($backupPath);
            }
            $this->success("Restored view.blade.php from backup");
            return true;
        }

        if (!file_exists($viewPath)) {
            $this->warning("view.blade.php not found at: $viewPath");
            return true;
        }

        $content = file_get_contents($viewPath);
        
        $content = preg_replace("/\s*<div class=\"col-xs-12\">\s*<div class=\"box[^\"]*\" id=\"suspend-user-box\">[\s\S]*?<\/div>\s*<\/div>\s*<\/div>\n?/", '', $content);
        
        $content = preg_replace("/\n*@section\('footer-scripts'\)\s*@parent\s*<script>[\s\S]*?suspend-form[\s\S]*?<\/script>\s*@endsection\s*$/", '', $content);

        if (!$this->dryRun) {
            file_put_contents($viewPath, $content);
        }

        $this->success("Cleaned up view.blade.php");
        return true;
    }

    private function rollbackMigration(): bool
    {
        if ($this->dryRun) {
            $this->info("[DRY RUN] Would rollback migration");
            return true;
        }

        $this->info("Rolling back database migration...");
        
        $command = "cd " . escapeshellarg($this->basePath) . " && php artisan migrate:rollback --path=database/migrations/2025_01_23_000000_add_suspended_at_to_users_table.php --force 2>&1";
        $output = shell_exec($command);
        
        if (strpos($output, 'error') !== false || strpos($output, 'Error') !== false) {
            $this->warning("Migration rollback may have issues: $output");
            $this->info("Attempting manual column removal...");
            
            $manualCommand = "cd " . escapeshellarg($this->basePath) . " && php artisan tinker --execute=\"Schema::table('users', function(\$table) { \$table->dropForeign(['suspended_by']); \$table->dropIndex(['suspended_at']); \$table->dropColumn(['suspended_at', 'suspended_by', 'suspension_reason']); });\" 2>&1";
            shell_exec($manualCommand);
        }

        $this->success("Database migration rolled back");
        return true;
    }

    private function clearCaches(): bool
    {
        if ($this->dryRun) {
            $this->info("[DRY RUN] Would clear caches");
            return true;
        }

        $this->info("Clearing caches...");
        
        $commands = [
            'config:clear',
            'cache:clear',
            'view:clear',
            'route:clear',
        ];

        foreach ($commands as $cmd) {
            $command = "cd " . escapeshellarg($this->basePath) . " && php artisan $cmd 2>&1";
            shell_exec($command);
        }

        $this->success("Caches cleared");
        return true;
    }

    public function uninstall(bool $dryRun = false): bool
    {
        $this->dryRun = $dryRun;

        $this->header("Pterodactyl User Suspension Addon Uninstaller");

        if ($dryRun) {
            $this->warning("Running in DRY RUN mode - no changes will be made");
            echo PHP_EOL;
        }

        // Validate Pterodactyl installation
        if (!$this->validatePterodactyl()) {
            $this->error("Could not find Pterodactyl installation.");
            $this->error("Please run this script from the addons/SuspendUser directory.");
            return false;
        }

        $this->warning("WARNING: This will remove all addon files and database columns!");
        $this->warning("Make sure you have a backup of your database before proceeding.");
        echo PHP_EOL;

        if (!$dryRun) {
            echo "Are you sure you want to uninstall the User Suspension addon? (yes/no): ";
            $handle = fopen("php://stdin", "r");
            $line = fgets($handle);
            fclose($handle);
            
            if (trim(strtolower($line)) !== 'yes') {
                $this->info("Uninstall cancelled.");
                return false;
            }
            echo PHP_EOL;
        }

        $this->step(1, "Rolling back database migration...");
        if (!$this->rollbackMigration()) {
            $this->warning("Could not rollback migration - continuing anyway");
        }

        $this->step(2, "Restoring modified files...");
        $this->restoreUserModel();
        $this->restoreKernel();
        $this->restoreAdminRoutes();
        $this->restoreBaseRoutes();
        $this->restoreAdminLayout();
        $this->restoreUserView();

        $this->step(3, "Removing addon files...");
        if (!$this->removeFiles()) {
            return false;
        }

        $this->step(4, "Clearing caches...");
        if (!$this->clearCaches()) {
            return false;
        }

        echo PHP_EOL;
        $this->header("Uninstall Complete!");
        $this->log("The User Suspension addon has been successfully removed.", GREEN);
        echo PHP_EOL;
        $this->info("Backup files (.backup) have been used and removed.");
        $this->info("If you experience any issues, restore from your own backups.");
        echo PHP_EOL;

        return true;
    }

    public function help(): void
    {
        $this->header("User Suspension Addon - Uninstaller Help");
        
        echo "Usage: php uninstaller.php [command] [options]" . PHP_EOL;
        echo PHP_EOL;
        echo "Commands:" . PHP_EOL;
        echo "  uninstall    Uninstall the addon" . PHP_EOL;
        echo "  help         Show this help message" . PHP_EOL;
        echo PHP_EOL;
        echo "Options:" . PHP_EOL;
        echo "  --dry-run    Show what would be done without making changes" . PHP_EOL;
        echo PHP_EOL;
        echo RED . "WARNING: Uninstalling will remove the suspended_at column from the" . RESET . PHP_EOL;
        echo RED . "users table. Make sure to backup your database first!" . RESET . PHP_EOL;
        echo PHP_EOL;
    }
}

if (php_sapi_name() !== 'cli') {
    die('This script can only be run from the command line.');
}

$uninstaller = new SuspendUserUninstaller();

$command = $argv[1] ?? 'help';
$dryRun = in_array('--dry-run', $argv);

switch ($command) {
    case 'uninstall':
        $success = $uninstaller->uninstall($dryRun);
        exit($success ? 0 : 1);
        break;
    case 'help':
    default:
        $uninstaller->help();
        break;
}
