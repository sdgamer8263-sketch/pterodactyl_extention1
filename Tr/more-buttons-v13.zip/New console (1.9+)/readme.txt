Upload the resources file then


Please add these lines to resources/scripts/components/server/console/ServerConsoleContainer.tsx under import PowerControls from '@/components/server/console/PowerControls';,

import MoreButtons from '@/components/server/console/MoreButtons';
import style from './style.module.css';


Please add these lines to resources/scripts/components/server/console/ServerConsole.tsx above <div className={'col-span-4 sm:col-span-2 lg:col-span-1 self-end'}>,

<div className={'col-span-4 sm:col-span-3 lg:col-span-3 self-end'}>
    <MoreButtons className={style.buttons_layout} />
</div>


In MoreButtons (resources/scripts/components/server/console/MoreButtons.tsx) Replace 'PMA URL' with your PhpMyAdmin path

Please add these lines to resources/scripts/components/server/console/style.module.css at the top

.buttons_layout {
    @apply grid grid-cols-2 sm:grid-cols-3 w-full gap-4 mb-4;

& button {
      @apply w-full first:col-span-1 sm:first:col-span-1;
  }

@screen md {
    @apply flex flex-1 justify-end mb-0;

& button {
      @apply w-auto;
  }
}
}


Open your SSH and build the panel (cd /var/www/pterodactyl && yarn && yarn build:production)



To add your own button go to resources/scripts/components/server/console/MoreButtons.tsx and add a Button component or copy one of my buttons and edit them.