Upload the resources file then


Please add this line to resources/scripts/components/server/ServerConsole.tsx under import PowerControls from '@/components/server/PowerControls';,

import MoreButtons from '@/components/server/MoreButtons';



Please add this line to resources/scripts/components/server/ServerConsole.tsx under <PowerControls/>,

<MoreButtons/>



Open your SSH and build panel (cd /var/www/pterodactyl && yarn && yarn build:production)