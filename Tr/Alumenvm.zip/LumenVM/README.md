 _                                _   ____  ___
| |                              | | | |  \/  |
| |    _   _ _ __ ___   ___ _ __ | | | | .  . |
| |   | | | | '_ ` _ \ / _ \ '_ \| | | | |\/| |
| |___| |_| | | | | | |  __/ | | \ \_/ / |  | |
\_____/\__,_|_| |_| |_|\___|_| |_|\___/\_|  |_|

Welcome to LumenVM
Bring virtual machines to Pterodactyl without modifying the panel!
Thanks for purchasing LumenVM.
You are NOT allowed to redistribute or post this resource on leaking websites, as it
really hurts me, the developer of LumenVM.

* Installation Guide

1. Navigate to yourpanelurl.com/admin/nests and create a new nest named 'LumenVM' or your preferred name.

2. Upload LumenVM.json to the nest. To use LumenVM, a license is required, available at https://lumenvm.cloud/discord.


3. Enjoy the advanced features of LumenVM for managing virtual machines on Pterodactyl!

* Optional: Enable KVM *

Refer to KVM.md for instructions on enabling KVM support for improved performance.

* Support *

For assistance or questions, join our Discord community at https://lumenvm.cloud/discord.
You can also reach me directly on Discord: @david1117.

* IPv4 Command *

To assign an IPv4 address (not included in the purchase), you need to run this command:

```docker pull ghcr.io/david1117dev/lumenvm:network && docker run -it --privileged --net=host -v /etc/pterodactyl:/etc/pterodactyl/ -v /var/run/docker.sock:/var/run/docker.sock ghcr.io/david1117dev/lumenvm:network```

Consider reaching us on our Discord for help.