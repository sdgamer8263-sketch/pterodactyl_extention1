First, we can install the addon for you for free. Just create a ticket in our [Discord](https://discord.gg/RJ2A8yYS2m) and we will install it for you.

# Uploading the addon

1. Upload the "panel_upload" folder to your pterodactyl installation directory.

# Edit Server Controller

1. Open the file `app/Http/Controllers/Api/Client/Servers/ServerController.php`
2. Find this code:
```php
                'user_permissions' => $this->permissionsService->handle($server, $request->user()),
```

3. Add this code below:
```php
                'egg_id' => $server->egg_id,
```

# Edit Assets Composer 

1. Open the file `app/Http/ViewComposers/AssetComposer.php`
2. Uder all `use` statements add this code:
```php
use Pterodactyl\Models\PocketAddonsConfig;
```

3. Find this code:
```php
        $view->with('asset', $this->assetHashService);
```

4. Add this code before
```php
        $pe_egg_id = (int) PocketAddonsConfig::first()->pe_eggs;
```

5. Find this code:
```php
            'recaptcha' => [
                'enabled' => config('recaptcha.enabled', false),
                'siteKey' => config('recaptcha.website_key') ?? '',
            ],
```

6. Add this code below:
```php
            'pocketmine_egg' => $pe_egg_id,
```

# Edit Server getter file

1. Open the file `resources/scripts/api/server/getServer.ts`
2. Find this code:
```js
export default (uuid: string): Promise<[Server, string[]]> => {
```

3. Replace it with this code:
```js
export default (uuid: string): Promise<[Server, string[], number]> => {
```

4. Find this code:
```js
                    data.meta?.is_server_owner ? ['*'] : data.meta?.user_permissions || [],
```

5. Add this code below:
```js
                    data.meta?.egg_id || 0,
```

# Edit Server Router file

1. Open the file `resources/scripts/routers/ServerRouter.tsx`
2. Under all `import` statements add this code:
```js
import { ApplicationStore } from '@/state';
```

3. Find this code:
```js
    const getServer = ServerContext.useStoreActions((actions) => actions.server.getServer);
    const clearServerState = ServerContext.useStoreActions((actions) => actions.clearServerState)
```

4. Add this code below:
```js
    const eggId = ServerContext.useStoreState((state) => state.server.eggId);
    const pocketmineEggid = useStoreState((state: ApplicationStore) => state.settings.data!.pocketmine_egg);
```

5. Find this code:
```js
                                        route.permission ? (
                                            <Can key={route.path} action={route.permission} matchAny>
                                                <NavLink to={to(route.path, true)} exact={route.exact}>
                                                    {route.name}
                                                </NavLink>
                                            </Can>
                                        ) : (
                                            <NavLink key={route.path} to={to(route.path, true)} exact={route.exact}>
                                                {route.name}
                                            </NavLink>
                                        )
```

6. Replace it with this code:
```js
                                        route.peEggId && pocketmineEggid !== eggId ? null : (
                                            route.permission ? (
                                                <Can key={route.path} action={route.permission} matchAny>
                                                    <NavLink to={to(route.path, true)} exact={route.exact}>
                                                        {route.name}
                                                    </NavLink>
                                                </Can>
                                            ) : (
                                                <NavLink key={route.path} to={to(route.path, true)} exact={route.exact}>
                                                    {route.name}
                                                </NavLink>
                                            )
                                        )
```

7. Find this code:
```js
                                    {routes.server.map(({ path, permission, component: Component }) => (
                                        <PermissionRoute key={path} permission={permission} path={to(path)} exact>
                                            <Spinner.Suspense>
                                                <Component />
                                            </Spinner.Suspense>
                                        </PermissionRoute>
                                    ))}
```

8. Replace it with this code:
```js
                                    {routes.server.map(({ path, permission, component: Component, peEggId }) => (
                                        peEggId && pocketmineEggid !== eggId ? null : (
                                            <PermissionRoute key={path} permission={permission} path={to(path)} exact>
                                                <Spinner.Suspense>
                                                    <Component />
                                                </Spinner.Suspense>
                                            </PermissionRoute>
                                        )
                                    ))}
```

# Edit routes file

1. Open the file `resources/scripts/routers/routes.ts`
2. Under all `import` statements add this code:
```js
import PocketAddonsContainer from '@/components/server/pocketaddons/PocketAddonsContainer';
```

3. Find the code:
```js
    permission: string | string[] | null;
```

4. Add this code below:
```js
    peEggId?: boolean;
```

5. Find this code:
```js
        {
            path: '/statistics',
            permission: null,
            name: 'Statistics',
            component: StatisticsContainer,
        },
```

6. Add this code below:
```js
        {
            path: '/pocketaddons',
            permission: null,
            name: 'PocketAddons',
            peEggId: true,
            component: PocketAddonsContainer,
        },
```

# Edit server state file

1. Open the file `resources/scripts/state/server/index.ts`
2. Under all `import` statements add this code:
```js
import pocketaddons, { PocketAddonsStore } from '@/state/server/pocketaddons';
```

3. Find this code:
```js
    permissions: string[];
```

4. Add this code below:
```js
    eggId?: number;
```

5. Find this code:
```js
    setPermissions: Action<ServerDataStore, string[]>;
```

6. Add this code below:
```js
    setEggId: Action<ServerDataStore, number>;
```

7. Find this code:
```js
        const [server, permissions] = await getServer(payload);
```

8. Replace it with this code:
```js
        const [server, permissions, eggId] = await getServer(payload);
```

9. Find the code:
```js
        actions.setPermissions(permissions);
```

10. Add this code below:
```js
        actions.setEggId(eggId);
```

11. Find this code:
```js
    setPermissions: action((state, payload) => {
        if (!isEqual(payload, state.permissions)) {
            state.permissions = payload;
        }
    }),
```

12. Add this code below:
```js
    setEggId: action((state, payload) => {
        if (!isEqual(payload, state.eggId)) {
            state.eggId = payload;
        }
    }),
```

13. Find this code:
```js
    status: ServerStatusStore;
```

14. Add this code below:
```js
    pocketaddons: PocketAddonsStore;
```

15. Find this code:
```js
        schedules,
```

16. Add this code below:
```js
        pocketaddons,
```

17. Find this code:
```js
            state.schedules.data = [];
```

18. Add this code below:
```js
            state.server.eggId = undefined;
            state.pocketaddons.data = [];
```

# Edit Settings State

1. Open the file `resources/scripts/state/settings.ts`
2. Find this code:
```js
        enabled: boolean;
        siteKey: string;
    };
```

3. Add this code below:
```js
    pocketmine_egg: number;
```

# Edit admin layout file

1. Open the file `resources/views/layouts/admin.blade.php`
2. Find this code:
```html
                        <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.nests') ?: 'active' }}">
                            <a href="{{ route('admin.nests') }}">
                                <i class="fa fa-th-large"></i> <span>Nests</span>
                            </a>
                        </li>
```

3. Add this code below:
```html
                        <li class="header">POCKET ADDONS</li>
                        <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.pocketaddons') ?: 'active' }}">
                            <a href="{{ route('admin.pocketaddons') }}">
                                <i class="fa fa-cubes"></i> <span>PocketAddons</span>
                            </a>
                        </li>
```

# Edit admin routes file

1. Open the file `routes/admin.php`

2. Under all `use` statements add this code:
```php
use Pterodactyl\Http\Controllers\Admin\PocketAddons\PocketAddonsController;
```

3. Add this code at the end of the file:
```php
/**
 * --------------------------------------------------------------------------
 * Pocket addons Controller Routes
 * --------------------------------------------------------------------------
 *
 * Endpoint: /admin/pocketaddons
 */
Route::group(['prefix' => 'pocketaddons'], function () {
    Route::get('/', [PocketAddonsController::class, 'index'])->name('admin.pocketaddons');
    Route::patch('/', [PocketAddonsController::class, 'update']);
});
```

# Edit Client API routes file

1. Open the file `routes/api-client.php`
2. Under all `use` statements add this code:
```php
use Pterodactyl\Http\Controllers\Api\Client\Servers\PocketAddons\getPocketAddons;
use Pterodactyl\Http\Controllers\Api\Client\Servers\PocketAddons\InstallAddon;
```

3. Find this code:
```php
    Route::post('/command', [Client\Servers\CommandController::class, 'index']);
    Route::post('/power', [Client\Servers\PowerController::class, 'index']);
```

4. Add this code below:
```php
    Route::get('/pocketaddons', [getPocketAddons::class, 'get']);
    Route::post('/pocketaddons/install', [InstallAddon::class, 'install']);
```

# Commands

1. run theses commands:
```bash
php artisan migrate --seed --force
php artisan db:seed pocketAddonsConfig
php artisan view:clear
php artisan cache:clear
```

2. build the panel: refer to the [pterodactyl docs](https://pterodactyl.io/community/customization/panel.html#building-assets)

3. run theses commands:
```bash
chown -R www-data:www-data /var/www/pterodactyl/*
chmod -R 755 storage/* bootstrap/cache
php artisan queue:restart
```

# You are done!

# Credits
Made by [MyPlugins](https://discord.gg/RJ2A8yYS2m) for [Pocket Addons](https://pocketaddons.com)