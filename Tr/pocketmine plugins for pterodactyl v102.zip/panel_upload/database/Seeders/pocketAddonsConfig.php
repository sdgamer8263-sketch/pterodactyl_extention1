<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Pterodactyl\Models\PocketAddonsConfig as ModelsPocketAddonsConfig;

class pocketAddonsConfig extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        ModelsPocketAddonsConfig::create([
            'pe_eggs' => 0,
            'vabe_eggs' => 0,
        ]);
    }
}