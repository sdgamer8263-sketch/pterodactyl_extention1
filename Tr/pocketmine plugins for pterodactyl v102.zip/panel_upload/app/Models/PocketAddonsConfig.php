<?php

namespace Pterodactyl\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id
 * @property string $pe_eggs
 * @property string $vabe_eggs
 */

class PocketAddonsConfig extends Model
{
    use HasFactory;

    /**
     * @var string
     */
    protected $table = 'pocket_addons_config';
}