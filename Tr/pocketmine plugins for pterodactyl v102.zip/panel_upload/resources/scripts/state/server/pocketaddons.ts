import { PocketAddons } from '@/api/server/pocketaddons/getPocketAddons';
import { action, Action } from 'easy-peasy';

export interface PocketAddonsStore {
    data: PocketAddons[];
    setAddons: Action<PocketAddonsStore, PocketAddons[]>;
}

const pocketaddons: PocketAddonsStore = {
    data: [],

    setAddons: action((state, payload) => {
        state.data = payload;
    }),
};

export default pocketaddons;