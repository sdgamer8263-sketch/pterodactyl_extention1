import React, { useEffect, useState } from 'react';
import { ServerContext } from '@/state/server';
import { httpErrorToHuman } from '@/api/http';
import FlashMessageRender from '@/components/FlashMessageRender';
import Spinner from '@/components/elements/Spinner';
import useFlash from '@/plugins/useFlash';
import tw from 'twin.macro';
import Fade from '@/components/elements/Fade';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import { useDeepMemoize } from '@/plugins/useDeepMemoize';
import getPocketAddons from '@/api/server/pocketaddons/getPocketAddons';
import PocketAddonsGrid from './PocketAddonsGrid';

export default () => {

    const { addError, clearFlashes } = useFlash();
    const [loading, setLoading] = useState(true);

    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);

    const pocketaddons = useDeepMemoize(ServerContext.useStoreState((state) => state.pocketaddons.data));
    const setAddons = ServerContext.useStoreActions((state) => state.pocketaddons.setAddons);

    useEffect(() => {
        setLoading(!pocketaddons.length);

        getPocketAddons(uuid)
            .then((pocketaddons) => setAddons([...new Map(pocketaddons.map(item => [item.ressource_id, item])).values()]))
            .catch((error) => {
                console.error(error);
                addError({ key: 'pocketaddons', message: httpErrorToHuman(error) });
            })
            .then(() => setLoading(false));
    }, []);

    return (
        <ServerContentBlock title={'Pocket Addons'}>
            <FlashMessageRender byKey={'pocketaddons'} css={tw`mb-4`} />
            {!pocketaddons.length && loading ? (
                <Spinner size={'large'} centered />
            ) : (
                <Fade timeout={150}>
                    <>
                        {pocketaddons.length > 0 ? (
                            <div css={tw`grid gap-4 md:grid-cols-2 xl:grid-cols-3`}>
                                {pocketaddons.map((pocketaddon, index) => (
                                    <PocketAddonsGrid
                                        key={pocketaddon.ressource_id}
                                        pocketaddons={pocketaddon}
                                        className={index > 0 ? 'mt-1' : undefined}
                                    />
                                ))}
                            </div>
                        ) : (
                            <p css={tw`text-center text-sm text-neutral-300`}>
                                It looks like you have no pocketaddons.
                            </p>
                        )}
                    </>
                </Fade>
            )}
        </ServerContentBlock>
    );
};