import React, { useEffect } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArchive, faAt, faClock, faEye } from '@fortawesome/free-solid-svg-icons';
import { format, formatDistanceToNow } from 'date-fns';
import tw from 'twin.macro';
import GreyRowBox from '@/components/elements/GreyRowBox';
import { PocketAddons, installPocketAddons } from '@/api/server/pocketaddons/getPocketAddons';
import { ServerContext } from '@/state/server';

interface Props {
    pocketaddons: PocketAddons;
    className?: string;
}

export default ({ pocketaddons, className }: Props) => {

    const server = ServerContext.useStoreState(state => state.server.data?.uuid) as string;

    function installAddon() {
        installPocketAddons(server, pocketaddons.ressource_id)
            .then(() => {
                console.log("install success");
            })
            .catch((error) => {
                console.error(error);
            });
    }

    return (
        // card with img on top and text on bottom
        <GreyRowBox css={tw`flex items-center`} className={className}>
            <div css={tw`flex flex-col w-full`}>
                <div css={tw`w-full bg-neutral-600 rounded-t-lg overflow-hidden h-48`}>
                    <img
                        src={`https://pocketaddons.com/${pocketaddons.ressource_thumbnail}`}
                        css={tw`w-full h-full object-cover`}
                    />
                </div>
                <div css={tw`p-4`}>
                    <p css={tw`text-sm`}>
                        <FontAwesomeIcon icon={faArchive} fixedWidth />
                        <span css={tw`ml-2`}>{pocketaddons.ressource_name}</span>
                    </p>
                    <p css={tw`text-xs text-neutral-300 mt-1`}>
                        <FontAwesomeIcon icon={faAt} fixedWidth />
                        <span css={tw`ml-2`}>
                            {pocketaddons.author_name}
                        </span>
                    </p>
                    <p css={tw`text-xs text-neutral-300 mt-1`}>
                        <FontAwesomeIcon icon={faClock} fixedWidth />
                        <span css={tw`ml-2`}>
                            {formatDistanceToNow(new Date(pocketaddons.version_update), { addSuffix: true })}
                        </span>
                    </p>
                </div>
                <div css={tw`flex items-center justify-between px-4 py-2 bg-neutral-700 rounded-b-lg`}>
                    <button onClick={() => installAddon()} css={tw`bg-blue-500 text-white px-4 py-2 mt-2 rounded-md w-9/12`}>
                        Install
                    </button>
                    <a href={`https://pocketaddons.com/ressource/${pocketaddons.ressource_slug}`} target="_blank" css={tw`bg-blue-500 text-white px-4 py-2 mt-2 rounded-md w-2/12`}>
                        <FontAwesomeIcon icon={faEye} />
                    </a>
                </div>
            </div>
        </GreyRowBox>

    );
};