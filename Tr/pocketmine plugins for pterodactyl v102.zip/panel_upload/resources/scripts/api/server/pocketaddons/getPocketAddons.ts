import http from '@/api/http';

export interface PocketAddons {
    ressource_id: string;
    ressource_name: string;
    ressource_slug: string;
    ressource_description: string;
    ressource_tags: string;
    ressource_thumbnail: string;
    version_name: string;
    version_file: string;
    version_update: string;
    author_name: string;
    category_name: string;
}

export const rawDataToPocketAddons = (data: any): PocketAddons => {
    return {
        ressource_id: data.ressource_id,
        ressource_name: data.ressource_name,
        ressource_slug: data.ressource_slug,
        ressource_description: data.ressource_description,
        ressource_tags: data.ressource_tags,
        ressource_thumbnail: data.ressource_thumbnail,
        version_name: data.version_name,
        version_file: data.version_file,
        version_update: data.version_update.replace(/(\d{2})-(\d{2})-(\d{4})/, '$3-$2-$1'),
        author_name: data.author_name,
        category_name: data.category_name,
    };
};

export default (uuid: string): Promise<PocketAddons[]> => {
    return new Promise((resolve, reject) => {
        http.get(`/api/client/servers/${uuid}/pocketaddons`)
            .then((response) =>
                resolve((response.data.data || []).map((item: any) => rawDataToPocketAddons(item)))
            )
            .catch(reject);
    });
};

export const installPocketAddons = (uuid: string, ressource_id: string): Promise<void> => {
    return new Promise((resolve, reject) => {
        http.post(`/api/client/servers/${uuid}/pocketaddons/install`, 
        {
            ressource_id: ressource_id,
        }
        )
            .then(() => resolve())
            .catch(reject);
    });
}