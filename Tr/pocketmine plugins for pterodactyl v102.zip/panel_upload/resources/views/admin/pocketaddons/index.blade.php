@extends('layouts.admin')

@section('title')
PocketAddons
@endsection

@section('content-header')
    <h1>PocketAddons<small>This part allows you to configure this addon.</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li class="active">PocketAddons</li>
    </ol>
@endsection

@section('content')
    <div class="row">
        <div class="col-xs-12">
            <div class="box box-success">
                <div class="box-header with-border">
                    <h3 class="box-title">PocketAddons</h3>
                </div>
                <div class="box-body">
                    <p>PocketAddons was made with <i class="fa fa-heart" style="color: #FB0000"></i> by MyPlugins for <a href="https://pocketaddons.com/">https://pocketaddons.com/</a></p>
                    <p>You can get support on this <a href="https://discord.gg/RJ2A8yYS2m" target="_blank">Discord</a>.</p>
                </div>
            </div>
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">Settings</h3>
                </div>
                <div class="box-body">
                    <div class="box-body table-responsive no-padding">
                        <form method="post">
                            @method('PATCH')
                            <div class="form-group col-xs-12">
                                <label class="control-label">EGGS Pocketmine</label>
                                <div>
                                    <input type="text" class="form-control" name="pe_eggs" value="{{ $config->pe_eggs }}" min="1" step="1">
                                    <p class="text-muted"><small>Enter the ID of the Pocketmine egg.</small></p>
                                </div>
                            </div>
                            <div class="form-group col-xs-12">
                                <div>
                                    {!! csrf_field() !!}
                                    <button type="submit" class="btn btn-sm btn-primary pull-right">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        </div>
    </div>
@endsection