<?php

namespace Pterodactyl\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\File;
use Symfony\Component\Console\Formatter\OutputFormatterStyle;
use Symfony\Component\Process\Process;
use Throwable;

class Arix extends Command
{
    protected $signature = 'arix {action?}';
    protected $description = 'Arix Theme maintenance commands.';

    public function handle(): int
    {
        $action = $this->argument('action');

        $title = new OutputFormatterStyle('#fff', null, ['bold']);
        $this->output->getFormatter()->setStyle('title', $title);

        if ($action === null) {
            $this->line(<<<'TEXT'
<title>
░█████╗░██████╗░██╗██╗░░██╗
██╔══██╗██╔══██╗██║╚██╗██╔╝
███████║██████╔╝██║░╚███╔╝░
██╔══██║██╔══██╗██║░██╔██╗░
██║░░██║██║░░██║██║██╔╝╚██╗
╚═╝░░╚═╝╚═╝░░╚═╝╚═╝╚═╝░░╚═╝

> php artisan arix install
> php artisan arix update
> php artisan arix uninstall
</title>
TEXT);

            return self::SUCCESS;
        }

        try {
            return match ($action) {
                'install' => $this->install(),
                'update' => $this->update(),
                'uninstall' => $this->uninstall(),
                default => $this->invalidAction(),
            };
        } catch (Throwable $e) {
            $this->error($e->getMessage());
            return self::FAILURE;
        }
    }

    private function invalidAction(): int
    {
        $this->error('Invalid action. Supported actions: install, update, uninstall');
        return self::INVALID;
    }

    public function install(): int
    {
        $this->info('Configuring environment...');
        $this->installOrUpdate(false);
        $this->info('Arix Theme installation completed.');

        return self::SUCCESS;
    }

    public function update(): int
    {
        $this->warn('Updating only from the local, already-reviewed arix directory.');
        $this->installOrUpdate(true);
        $this->info('Arix Theme update completed.');

        return self::SUCCESS;
    }

    private function installOrUpdate(bool $isUpdate): void
    {
        if (!$this->confirm('Are all the required dependencies installed from the readme file?', true)) {
            return;
        }

        $versions = File::directories(base_path('arix'));
        if (empty($versions)) {
            throw new \RuntimeException('No versions found in the local /arix directory.');
        }

        $versionPath = $this->choice('Select a local version:', $versions);
        $version = basename($versionPath);
        $source = realpath(base_path('arix/' . $version));
        $arixRoot = realpath(base_path('arix'));

        if (
            $source === false ||
            $arixRoot === false ||
            !str_starts_with($source . DIRECTORY_SEPARATOR, $arixRoot . DIRECTORY_SEPARATOR)
        ) {
            throw new \RuntimeException('Invalid local Arix version path.');
        }

        $this->info("Copying reviewed local files for Arix {$version}...");
        if (!File::copyDirectory($source, base_path())) {
            throw new \RuntimeException('Could not copy local Arix files.');
        }

        $directoryPath = app_path('Http/Controllers/Admin/Arix');
        File::makeDirectory($directoryPath, 0755, true, true);

        $controllers = [
            'ArixController',
            'ArixAdvancedController',
            'ArixAnnouncementController',
            'ArixColorsController',
            'ArixComponentsController',
            'ArixDashboardController',
            'ArixLayoutController',
            'ArixLinkController',
            'ArixMailController',
            'ArixMetaController',
            'ArixPresetController',
            'ArixSocialController',
            'ArixStylingController',
        ];

        foreach ($controllers as $controller) {
            $this->copyController($controller, $version);
        }

        $this->runArtisan(['migrate', '--force']);
        $this->runProcess([
            'yarn',
            'add',
            'react-email-editor',
            'react-colorful',
            'recharts@^2.15.4',
            'ua-parser-js',
            'cronstrue',
            'react-day-picker',
            'jszip',
            'react-turnstile',
            '@dnd-kit/core',
            '@dnd-kit/sortable',
            '@dnd-kit/utilities',
            '@types/md5',
            'md5',
            'react-icons@5.4.0',
            'markdown-to-jsx@7.7.10',
            'i18next-browser-languagedetector@7.2.1',
        ]);
        $this->runArtisan(['language:compile']);
        $this->runProcess(['yarn', 'build:production']);
        $this->runArtisan(['optimize:clear']);
        $this->runArtisan(['optimize']);
        $this->runArtisan(['queue:restart']);

        $this->info($isUpdate ? 'Local Arix update completed.' : 'Local Arix installation completed.');
    }

    private function copyController(string $filename, string $version): void
    {
        $source = base_path("arix/{$version}/app/Http/Controllers/Admin/Arix/{$filename}.php");
        $destination = app_path("Http/Controllers/Admin/Arix/{$filename}.php");

        if (!File::exists($source)) {
            throw new \RuntimeException("Missing local controller: {$filename}.php");
        }

        File::copy($source, $destination);
        $this->line("Copied {$filename}.php");
    }

    private function runArtisan(array $arguments): void
    {
        $this->runProcess(array_merge([PHP_BINARY, 'artisan'], $arguments));
    }

    private function runProcess(array $command): void
    {
        $process = new Process($command, base_path());
        $process->setTimeout(1800);
        $process->run(function (string $type, string $buffer): void {
            $this->output->write($buffer);
        });

        if (!$process->isSuccessful()) {
            throw new \RuntimeException(
                'Command failed: ' . implode(' ', $command) . PHP_EOL . $process->getErrorOutput()
            );
        }
    }

    private function uninstall(): int
    {
        $this->warn('Safe uninstall does not download or overwrite Pterodactyl from the internet.');
        $this->warn('Restore the panel from a trusted backup or official, verified release.');

        $this->runArtisan(['view:clear']);
        $this->runArtisan(['config:clear']);
        $this->runArtisan(['queue:restart']);

        $this->info('Caches cleared. No remote archive was downloaded or executed.');
        return self::SUCCESS;
    }
}