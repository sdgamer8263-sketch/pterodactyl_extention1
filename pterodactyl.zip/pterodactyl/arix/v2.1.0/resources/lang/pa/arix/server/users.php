<?php

return [
    'title' => 'ਯੂਜ਼ਰ',
    'manage-subusers' => 'ਸਬ ਯੂਜ਼ਰ ਪ੍ਰਬੰਧਿਤ ਕਰੋ',
    'new-user' => 'ਨਵਾਂ ਯੂਜ਼ਰ',

    'no-users' => 'ਇਸ ਦਾ ਸ਼ਾਇਦ ਤੁਹਾਨੂੰ ਕੋਈ ਸਬ ਯੂਜ਼ਰ ਨਹੀਂ ਹੈ।',

    'name' => 'ਨਾਮ',
    'email' => 'ਈਮੇਲ',
    '2FA-enabled' => '2FA ਸਮਰੂਪਤ',
    'creation-date' => 'ਨਿਰਮਾਣ ਮਿਤੀ',
    'modify-permissions' => 'ਅਨੁਮਤੀਆਂ ਸੋਧੋ',

    'user-email' => 'ਯੂਜ਼ਰ ਈਮੇਲ',
    'user-email-description' => 'ਇਸ ਸਰਵਰ ਲਈ ਸਬ ਯੂਜ਼ਰ ਦੇ ਤੌਰ ਤੇ ਸੱਦਾ ਭੇਜਣ ਲਈ ਯੂਜ਼ਰ ਦੀ ਈਮੇਲ ਐਡਰੈੱਸ ਦਾਖਲ ਕਰੋ।',

    'select-all-permissions' => 'ਸਾਰੀਆਂ ਇਜਾਜ਼ਤਾਂ ਚੁਣੋ',
    'modify-permissions-for' => 'ਅਨੁਮਤੀਆਂ ਸੋਧੋ',
    'view-permissions-for' => 'ਅਨੁਮਤੀਆਂ ਵੇਖੋ',
    'create-new-subuser' => 'ਨਵਾਂ ਸਬ ਯੂਜ਼ਰ ਬਣਾਓ',
    'must-not-exceed' => 'ਈਮੇਲ ਐਡਰੈੱਸ 191 ਅੱਖਰ ਤੋਂ ਵੱਧ ਨਹੀਂ ਹੋਣੇ ਚਾਹੀਦੇ।',
    'valid-email' => 'ਇੱਕ ਵੈਧ ਈਮੇਲ ਐਡਰੈੱਸ ਦਿਓ।',
    'save' => 'ਸੰਭਾਲੋ',
    'invite-user' => 'ਯੂਜ਼ਰ ਨੂੰ ਆਮੰਤਰਿਤ ਕਰੋ',

    'only-permissions-you-assigned' => 'ਸਿਰਫ ਅਨੁਮਤੀਆਂ ਜੋ ਤੁਹਾਡੇ ਖਾਤੇ ਨੂੰ ਹਾਲੇ ਸੌਂਪੀ ਗਈਆਂ ਹਨ ਨੂੰ ਬਣਾਉਣ ਜਾਂ ਸੋਧਣ ਦੇ ਸਮੇਂ ਚੁਣੀਆਂ ਜਾ ਸਕਦੀਆਂ ਹਨ।',

    'delete-this-subuser' => 'ਇਸ ਸਬ ਯੂਜ਼ਰ ਨੂੰ ਮਿਟਾਓ?',
    'yes-remove' => 'ਹਾਂ, ਸਬ ਯੂਜ਼ਰ ਨੂੰ ਹਟਾਓ',
    'are-you-sure-to-remove' => 'ਕੀ ਤੁਸੀਂ ਇਸ ਸਬ ਯੂਜ਼ਰ ਨੂੰ ਹਟਾਉਣਾ ਚਾਹੁੰਦੇ ਹੋ? ਉਹ ਤੁਹਾਨੂੰ ਇਸ ਸਰਵਰ ਵਿੱਚ ਸਭ ਐਕਸੈਸ ਤੁਰੰਤ ਮਾਫ ਕਰ ਦਿੰਦਾ ਹੈ।'
];
