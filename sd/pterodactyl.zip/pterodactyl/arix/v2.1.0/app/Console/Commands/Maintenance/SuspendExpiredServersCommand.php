<?php

namespace Pterodactyl\Console\Commands\Maintenance;

use Illuminate\Console\Command;
use Pterodactyl\Models\Server;
use Pterodactyl\Services\Servers\SuspensionService;

class SuspendExpiredServersCommand extends Command
{
    protected $signature = 'ska:suspend-expired';

    protected $description = 'SKA Theme: automatically suspends any server whose expiry date/time has passed.';

    public function __construct(private SuspensionService $suspensionService)
    {
        parent::__construct();
    }

    public function handle(): void
    {
        $servers = Server::query()
            ->whereNotNull('expires_at')
            ->where('expires_at', '<=', now())
            ->where('expiry_suspended', false)
            ->where('status', '!=', Server::STATUS_SUSPENDED)
            ->get();

        foreach ($servers as $server) {
            try {
                $this->suspensionService->toggle($server, SuspensionService::ACTION_SUSPEND);
                $server->forceFill(['expiry_suspended' => true])->saveQuietly();

                $this->info("Suspended expired server #{$server->id} ({$server->name}).");
            } catch (\Throwable $exception) {
                $this->error("Failed to suspend expired server #{$server->id}: {$exception->getMessage()}");
            }
        }

        if ($servers->isEmpty()) {
            $this->info('No expired servers found.');
        }
    }
}
