<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Models\User;
use Pterodactyl\Http\Controllers\Controller;

class UserManagementController extends Controller
{
    public function __construct(private AlertsMessageBag $alert)
    {
    }

    public function index(Request $request): View
    {
        $search = trim((string) $request->query('query', ''));

        $users = User::query()
            ->when($search !== '', function ($query) use ($search) {
                $query->where(function ($query) use ($search) {
                    $query->where('username', 'like', "%{$search}%")
                        ->orWhere('email', 'like', "%{$search}%")
                        ->orWhere('name_first', 'like', "%{$search}%")
                        ->orWhere('name_last', 'like', "%{$search}%");
                });
            })
            ->orderByDesc('banned_at')
            ->orderBy('username')
            ->paginate(25)
            ->appends(['query' => $search]);

        return view('admin.users.management', [
            'users' => $users,
            'search' => $search,
        ]);
    }

    public function ban(Request $request, User $user): RedirectResponse
    {
        $request->validate([
            'ban_reason' => 'nullable|string|max:191',
        ]);

        if ($user->root_admin) {
            $this->alert->danger('You cannot ban another administrator account.')->flash();

            return redirect()->route('admin.users.management');
        }

        $user->forceFill([
            'banned_at' => now(),
            'ban_reason' => $request->input('ban_reason') ?: 'Banned by an administrator.',
        ])->save();

        $this->alert->success("User \"{$user->username}\" has been banned and can no longer log in.")->flash();

        return redirect()->route('admin.users.management');
    }

    public function unban(User $user): RedirectResponse
    {
        $user->forceFill([
            'banned_at' => null,
            'ban_reason' => null,
        ])->save();

        $this->alert->success("User \"{$user->username}\" has been unbanned.")->flash();

        return redirect()->route('admin.users.management');
    }
}
