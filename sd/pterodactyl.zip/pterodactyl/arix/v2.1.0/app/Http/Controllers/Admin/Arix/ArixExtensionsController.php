<?php

namespace Pterodactyl\Http\Controllers\Admin\Arix;

use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Http\Requests\Admin\Arix\ArixExtensionsRequest;
use Pterodactyl\Contracts\Repository\SettingsRepositoryInterface;

class ArixExtensionsController extends Controller
{
    /**
     * The full list of extension keys grouped by the server type they apply to.
     * Used both to validate incoming payloads and to seed sane defaults.
     */
    public const EXTENSIONS = [
        'universal' => ['player_manager', 'subdomain_manager', 'world_manager', 'world_installer'],
        'bedrock' => ['version_changer', 'addon_installer', 'custom_addon_upload'],
        'paper' => ['plugin_management', 'server_properties_manager', 'resource_pack_installer'],
        'fabric' => ['mod_installer', 'modpack_installer', 'server_properties_manager'],
    ];

    public function __construct(
        private AlertsMessageBag $alert,
        private SettingsRepositoryInterface $settings
    ) {
    }

    public static function allKeys(): array
    {
        return array_values(array_unique(array_merge(...array_values(self::EXTENSIONS))));
    }

    public function index(): \Illuminate\Http\JsonResponse
    {
        return response()->json($this->responseData());
    }

    private function responseData(): array
    {
        $stored = json_decode((string) $this->settings->get('settings::arix:extensions', '{}'), true);
        if (!is_array($stored)) {
            $stored = [];
        }

        $extensions = [];
        foreach (self::allKeys() as $key) {
            // Everything is enabled by default until an admin explicitly turns it off.
            $extensions[$key] = array_key_exists($key, $stored) ? (bool) $stored[$key] : true;
        }

        return [
            'groups' => self::EXTENSIONS,
            'extensions' => $extensions,
        ];
    }

    public function store(ArixExtensionsRequest $request): \Illuminate\Http\JsonResponse
    {
        $payload = $request->validated();
        $extensions = is_array($payload['extensions'] ?? null) ? $payload['extensions'] : [];

        $sanitized = [];
        foreach (self::allKeys() as $key) {
            $sanitized[$key] = array_key_exists($key, $extensions) ? (bool) $extensions[$key] : true;
        }

        $this->settings->set('settings::arix:extensions', json_encode($sanitized));

        $this->alert->success('Extension settings have been updated successfully.')->flash();

        return response()->json($this->responseData());
    }

    /**
     * Helper for other parts of the application (e.g. server-side extension
     * gating) to check whether a given extension is currently enabled.
     */
    public static function isEnabled(string $key): bool
    {
        $settings = app(SettingsRepositoryInterface::class);
        $stored = json_decode((string) $settings->get('settings::arix:extensions', '{}'), true);
        if (!is_array($stored) || !array_key_exists($key, $stored)) {
            return true;
        }

        return (bool) $stored[$key];
    }
}
