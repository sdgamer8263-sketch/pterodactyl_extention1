<?php

namespace Pterodactyl\Http\Controllers\Api\Client\Servers;

use Pterodactyl\Models\Server;
use Pterodactyl\Http\Controllers\Api\Client\ClientApiController;
use Pterodactyl\Http\Requests\Api\Client\Servers\GetServerRequest;

class SkaPlayerCountController extends ClientApiController
{
    /**
     * SKA Theme: Player Manager / Player Count extension.
     *
     * Queries the server's primary allocation directly using the Minecraft
     * Server List Ping protocol (Java edition) or the RakNet unconnected
     * ping packet (Bedrock edition, UDP). No third-party service is used;
     * this talks straight to the game server's public port.
     */
    public function __invoke(GetServerRequest $request, Server $server): array
    {
        $allocation = $server->allocation;

        if (!$allocation) {
            return $this->response(null, null, 'No allocation assigned to this server.');
        }

        $ip = $allocation->ip === '0.0.0.0' ? $server->node->fqdn : $allocation->ip;
        $port = (int) $allocation->port;

        $isBedrock = str_contains(strtolower($server->egg->name ?? ''), 'bedrock')
            || str_contains(strtolower($server->image ?? ''), 'bedrock');

        try {
            $result = $isBedrock
                ? $this->pingBedrock($ip, $port)
                : $this->pingJava($ip, $port);
        } catch (\Throwable $exception) {
            return $this->response(null, null, 'Unable to reach the server: ' . $exception->getMessage());
        }

        return $this->response($result['online'], $result['max'], null, $result['motd'] ?? null);
    }

    private function response(?int $online, ?int $max, ?string $error, ?string $motd = null): array
    {
        return [
            'object' => 'ska_player_count',
            'data' => [
                'online' => $online,
                'max' => $max,
                'motd' => $motd,
                'error' => $error,
            ],
        ];
    }

    /**
     * Minecraft Java Edition Server List Ping (protocol documented publicly
     * at wiki.vg/Server_List_Ping). Pure TCP, no external dependency.
     */
    private function pingJava(string $ip, int $port): array
    {
        $socket = @fsockopen($ip, $port, $errno, $errstr, 3);
        if (!$socket) {
            throw new \RuntimeException($errstr ?: 'connection failed');
        }
        stream_set_timeout($socket, 3);

        $handshake = $this->packVarInt(0)
            . $this->packVarInt(-1)
            . $this->packString($ip)
            . pack('n', $port)
            . $this->packVarInt(1);
        fwrite($socket, $this->packVarInt(strlen($handshake)) . $handshake);

        $request = $this->packVarInt(0);
        fwrite($socket, $this->packVarInt(strlen($request)) . $request);

        $this->readVarInt($socket);
        $this->readVarInt($socket);
        $length = $this->readVarInt($socket);
        $json = '';
        while (strlen($json) < $length) {
            $chunk = fread($socket, $length - strlen($json));
            if ($chunk === false || $chunk === '') {
                break;
            }
            $json .= $chunk;
        }
        fclose($socket);

        $data = json_decode($json, true);
        if (!is_array($data)) {
            throw new \RuntimeException('invalid response from server');
        }

        return [
            'online' => (int) ($data['players']['online'] ?? 0),
            'max' => (int) ($data['players']['max'] ?? 0),
            'motd' => is_array($data['description'] ?? null) ? ($data['description']['text'] ?? null) : ($data['description'] ?? null),
        ];
    }

    /**
     * Minecraft Bedrock Edition uses RakNet's "Unconnected Ping" packet
     * (UDP) which returns a semicolon-delimited status string.
     */
    private function pingBedrock(string $ip, int $port): array
    {
        $socket = @stream_socket_client("udp://{$ip}:{$port}", $errno, $errstr, 3);
        if (!$socket) {
            throw new \RuntimeException($errstr ?: 'connection failed');
        }
        stream_set_timeout($socket, 3);

        $magic = hex2bin('00ffff00fefefefefdfdfdfd12345678');
        $packet = "\x01" . pack('J', time()) . $magic . str_repeat("\x00", 8);
        fwrite($socket, $packet);

        $response = fread($socket, 2048);
        fclose($socket);

        if ($response === false || strlen($response) < 35) {
            throw new \RuntimeException('no response from server');
        }

        // Skip the 1-byte ID, 8-byte time, 8-byte server GUID, 16-byte magic, then a 2-byte length prefix.
        $payload = substr($response, 35);
        $parts = explode(';', $payload);

        return [
            'online' => isset($parts[4]) ? (int) $parts[4] : 0,
            'max' => isset($parts[5]) ? (int) $parts[5] : 0,
            'motd' => $parts[1] ?? null,
        ];
    }

    private function packVarInt(int $value): string
    {
        $out = '';
        $value &= 0xFFFFFFFF;
        do {
            $byte = $value & 0x7F;
            $value >>= 7;
            if ($value !== 0) {
                $byte |= 0x80;
            }
            $out .= chr($byte);
        } while ($value !== 0);

        return $out;
    }

    private function packString(string $value): string
    {
        return $this->packVarInt(strlen($value)) . $value;
    }

    /**
     * @param resource $socket
     */
    private function readVarInt($socket): int
    {
        $result = 0;
        for ($i = 0; $i < 5; ++$i) {
            $byte = fread($socket, 1);
            if ($byte === false || $byte === '') {
                throw new \RuntimeException('unexpected end of stream');
            }
            $byteValue = ord($byte);
            $result |= ($byteValue & 0x7F) << (7 * $i);
            if (($byteValue & 0x80) === 0) {
                break;
            }
        }

        return $result;
    }
}
