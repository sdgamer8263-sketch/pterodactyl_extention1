<?php

namespace Pterodactyl\Http\Controllers\Admin\Arix;

use Illuminate\Support\Str;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Http\Requests\Admin\Arix\ArixResourceRequest;

class ArixResourceController extends Controller
{
    private const UPLOAD_DIRECTORY = 'arix/uploads';

    public function __construct(private AlertsMessageBag $alert)
    {
    }

    private function uploadPath(): string
    {
        return public_path(self::UPLOAD_DIRECTORY);
    }

    private function toResource(string $filename): array
    {
        $path = $this->uploadPath() . DIRECTORY_SEPARATOR . $filename;

        return [
            'name' => $filename,
            'url' => rtrim(config('app.url'), '/') . '/' . self::UPLOAD_DIRECTORY . '/' . $filename,
            'size' => file_exists($path) ? filesize($path) : 0,
            'uploadedAt' => file_exists($path) ? date('c', filemtime($path)) : null,
        ];
    }

    public function index(): \Illuminate\Http\JsonResponse
    {
        if (!is_dir($this->uploadPath())) {
            @mkdir($this->uploadPath(), 0755, true);
        }

        $files = array_values(array_filter(scandir($this->uploadPath()) ?: [], function ($file) {
            return !in_array($file, ['.', '..'], true) && is_file($this->uploadPath() . DIRECTORY_SEPARATOR . $file);
        }));

        $resources = array_map(fn ($file) => $this->toResource($file), $files);

        usort($resources, fn ($a, $b) => strcmp($b['uploadedAt'] ?? '', $a['uploadedAt'] ?? ''));

        return response()->json(['data' => $resources]);
    }

    public function store(ArixResourceRequest $request): \Illuminate\Http\JsonResponse
    {
        if (!is_dir($this->uploadPath())) {
            @mkdir($this->uploadPath(), 0755, true);
        }

        $file = $request->file('file');
        $extension = strtolower($file->getClientOriginalExtension()) ?: 'png';
        $filename = Str::uuid()->toString() . '.' . $extension;

        $file->move($this->uploadPath(), $filename);

        $this->alert->success('Image uploaded successfully.')->flash();

        return response()->json(['data' => $this->toResource($filename)]);
    }

    public function destroy(string $filename): \Illuminate\Http\JsonResponse
    {
        $filename = basename($filename);
        $path = $this->uploadPath() . DIRECTORY_SEPARATOR . $filename;

        if (is_file($path)) {
            @unlink($path);
        }

        $this->alert->success('Image deleted successfully.')->flash();

        return response()->json(['success' => true]);
    }
}
