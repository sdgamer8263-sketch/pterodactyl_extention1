<?php

namespace Pterodactyl\Http\Requests\Admin\Arix;

class ArixExtensionsRequest extends \Pterodactyl\Http\Requests\Admin\AdminFormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\Rule|array|string>
     */
    public function rules(): array
    {
        return [
            'extensions' => ['present', 'array'],
            'extensions.*' => ['boolean'],
        ];
    }
}
