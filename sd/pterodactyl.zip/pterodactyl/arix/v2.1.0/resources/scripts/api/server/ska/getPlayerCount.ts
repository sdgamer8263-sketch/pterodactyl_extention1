import http from '@/api/http';
import { ServerContext } from '@/state/server';
import { useEffect, useState } from 'react';

export interface SkaPlayerCount {
    online: number | null;
    max: number | null;
    motd: string | null;
    error: string | null;
}

export const getPlayerCount = async (uuid: string): Promise<SkaPlayerCount> => {
    const { data } = await http.get(`/api/client/servers/${uuid}/ska/player-count`);

    return {
        online: data?.data?.online ?? null,
        max: data?.data?.max ?? null,
        motd: data?.data?.motd ?? null,
        error: data?.data?.error ?? null,
    };
};

export const useSkaPlayerCount = (pollMs = 30000): SkaPlayerCount & { loading: boolean } => {
    const uuid = ServerContext.useStoreState((state) => state.server.data!.id);
    const status = ServerContext.useStoreState((state) => state.status.value);
    const [state, setState] = useState<SkaPlayerCount & { loading: boolean }>({
        online: null,
        max: null,
        motd: null,
        error: null,
        loading: true,
    });

    useEffect(() => {
        let cancelled = false;

        const load = () => {
            if (status !== 'running') {
                return;
            }

            getPlayerCount(uuid)
                .then((data) => {
                    if (!cancelled) setState({ ...data, loading: false });
                })
                .catch((error) => {
                    if (!cancelled) {
                        setState({
                            online: null,
                            max: null,
                            motd: null,
                            error: error?.message ?? 'Failed to load player count.',
                            loading: false,
                        });
                    }
                });
        };

        load();
        const interval = setInterval(load, pollMs);

        return () => {
            cancelled = true;
            clearInterval(interval);
        };
    }, [uuid, status, pollMs]);

    return state;
};
