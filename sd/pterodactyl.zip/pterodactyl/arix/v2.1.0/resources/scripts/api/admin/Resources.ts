import http from '@/api/http';

export interface ResourceFile {
    name: string;
    url: string;
    size: number;
    uploadedAt: string | null;
}

export default function getResources(): Promise<ResourceFile[]> {
    return new Promise((resolve, reject) => {
        http.get('/admin/arix/api/resources')
            .then((response) => resolve(response.data.data))
            .catch(reject);
    });
}

export function uploadResource(file: File): Promise<ResourceFile> {
    return new Promise((resolve, reject) => {
        const formData = new FormData();
        formData.append('file', file);

        http.post('/admin/arix/api/resources', formData, {
            headers: { 'Content-Type': 'multipart/form-data' },
        })
            .then((response) => resolve(response.data.data))
            .catch(reject);
    });
}

export function deleteResource(name: string): Promise<void> {
    return new Promise((resolve, reject) => {
        http.delete(`/admin/arix/api/resources/${encodeURIComponent(name)}`)
            .then(() => resolve())
            .catch(reject);
    });
}
