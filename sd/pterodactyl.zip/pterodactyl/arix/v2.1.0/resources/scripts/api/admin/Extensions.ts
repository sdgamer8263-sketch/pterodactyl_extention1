import http from '@/api/http';

export interface ExtensionsSettings {
    groups: Record<string, string[]>;
    extensions: Record<string, boolean>;
}

export default function getExtensions(): Promise<ExtensionsSettings> {
    return new Promise((resolve, reject) => {
        http.get('/admin/arix/api/extensions')
            .then((response) => resolve(response.data))
            .catch(reject);
    });
}

export function updateExtensions(extensions: Record<string, boolean>): Promise<ExtensionsSettings> {
    return new Promise((resolve, reject) => {
        http.post('/admin/arix/api/extensions', { extensions })
            .then((response) => resolve(response.data))
            .catch(reject);
    });
}
