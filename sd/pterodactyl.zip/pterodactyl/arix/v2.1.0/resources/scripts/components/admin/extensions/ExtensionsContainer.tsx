import React, { useEffect, useState } from 'react';
import Spinner from '@/components/elements/Spinner';
import FlashMessageRender from '@/components/FlashMessageRender';
import useFlash from '@/plugins/useFlash';
import { httpErrorToHuman } from '@/api/http';
import getExtensions, { updateExtensions } from '@/api/admin/Extensions';
import { Button } from '@/components/elements/button/index';
import BorderedBox from '../elements/BorderedBox';
import Switch from '@/components/elements/Switch';

const GROUP_LABELS: Record<string, string> = {
    universal: 'Universal',
    bedrock: 'Bedrock',
    paper: 'PaperMC',
    fabric: 'Fabric',
};

const EXTENSION_LABELS: Record<string, { label: string; description: string }> = {
    player_manager: { label: 'Player Manager', description: 'Manage OP/whitelist/ban lists directly from the panel.' },
    subdomain_manager: { label: 'Subdomain Manager', description: 'Let users attach a subdomain to their server.' },
    world_manager: { label: 'World Manager', description: 'Upload, download, and switch between server worlds.' },
    world_installer: { label: 'World Installer', description: 'Install pre-made worlds from a curated catalog.' },
    version_changer: { label: 'Version Changer', description: 'Switch a Bedrock server between available versions.' },
    addon_installer: { label: 'Addon Installer', description: 'Install Bedrock addons with automatic extraction.' },
    custom_addon_upload: { label: 'Custom Addon Upload', description: 'Allow users to upload their own .mcaddon/.mcpack files.' },
    plugin_management: { label: 'Plugin Management', description: 'Install, update, and remove PaperMC plugins.' },
    server_properties_manager: { label: 'Server Properties Manager', description: 'Edit server.properties from a friendly UI.' },
    resource_pack_installer: { label: 'Resource Pack Installer', description: 'Install resource packs on PaperMC servers.' },
    mod_installer: { label: 'Mod Installer', description: 'Install individual Fabric mods.' },
    modpack_installer: { label: 'Modpack Installer', description: 'Install a full Fabric modpack.' },
};

export default () => {
    const [loading, setLoading] = useState(true);
    const [submitting, setSubmitting] = useState(false);
    const [groups, setGroups] = useState<Record<string, string[]>>({});
    const [extensions, setExtensions] = useState<Record<string, boolean>>({});
    const { clearFlashes, addFlash } = useFlash();

    useEffect(() => {
        clearFlashes();
        getExtensions()
            .then((data) => {
                setGroups(data.groups);
                setExtensions(data.extensions);
            })
            .catch((error) => addFlash({ type: 'error', message: httpErrorToHuman(error) }))
            .finally(() => setLoading(false));
    }, []);

    const toggle = (key: string) => {
        setExtensions((current) => ({ ...current, [key]: !current[key] }));
    };

    const save = () => {
        setSubmitting(true);
        clearFlashes();
        updateExtensions(extensions)
            .then((data) => {
                setExtensions(data.extensions);
                addFlash({ type: 'success', message: 'Extension settings updated successfully.' });
            })
            .catch((error) => addFlash({ type: 'error', message: httpErrorToHuman(error) }))
            .finally(() => setSubmitting(false));
    };

    return (
        <div className='p-4'>
            <FlashMessageRender />
            {loading ? (
                <Spinner size='large' centered />
            ) : (
                <div className='boxBorder bg-gray-700 rounded-box max-w-3xl mx-auto flex flex-col gap-y-4'>
                    <div className='flex items-center justify-between px-6 pt-5'>
                        <div>
                            <p className='text-lg font-medium text-gray-100'>Extensions</p>
                            <p className='text-sm text-gray-300'>
                                Toggle which extra modules are available to users, grouped by server type.
                            </p>
                        </div>
                        <Button disabled={submitting} onClick={save} className='relative'>
                            Save Changes
                            {submitting && (
                                <div className='absolute right-4'>
                                    <Spinner size='small' />
                                </div>
                            )}
                        </Button>
                    </div>
                    {Object.entries(groups).map(([group, keys]) => (
                        <BorderedBox key={group} title={GROUP_LABELS[group] ?? group}>
                            {keys.map((key) => (
                                <Switch
                                    key={key}
                                    name={`extensions.${key}`}
                                    label={EXTENSION_LABELS[key]?.label ?? key}
                                    description={EXTENSION_LABELS[key]?.description}
                                    checked={!!extensions[key]}
                                    onChange={() => toggle(key)}
                                />
                            ))}
                        </BorderedBox>
                    ))}
                </div>
            )}
        </div>
    );
};
