import React, { useEffect, useRef, useState } from 'react';
import Spinner from '@/components/elements/Spinner';
import FlashMessageRender from '@/components/FlashMessageRender';
import useFlash from '@/plugins/useFlash';
import { httpErrorToHuman } from '@/api/http';
import getResources, { deleteResource, ResourceFile, uploadResource } from '@/api/admin/Resources';
import { Button } from '@/components/elements/button/index';
import { LuCopy, LuTrash2, LuUpload } from 'react-icons/lu';

export default () => {
    const [loading, setLoading] = useState(true);
    const [uploading, setUploading] = useState(false);
    const [resources, setResources] = useState<ResourceFile[]>([]);
    const [copied, setCopied] = useState<string | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const { clearFlashes, addFlash } = useFlash();

    const load = () => {
        setLoading(true);
        getResources()
            .then((data) => setResources(data))
            .catch((error) => addFlash({ type: 'error', message: httpErrorToHuman(error) }))
            .finally(() => setLoading(false));
    };

    useEffect(() => {
        clearFlashes();
        load();
    }, []);

    const onFileSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        setUploading(true);
        clearFlashes();
        uploadResource(file)
            .then(() => {
                addFlash({ type: 'success', message: 'Image uploaded successfully.' });
                load();
            })
            .catch((error) => addFlash({ type: 'error', message: httpErrorToHuman(error) }))
            .finally(() => {
                setUploading(false);
                if (fileInputRef.current) fileInputRef.current.value = '';
            });
    };

    const onDelete = (name: string) => {
        clearFlashes();
        deleteResource(name)
            .then(() => {
                addFlash({ type: 'success', message: 'Image deleted successfully.' });
                setResources((current) => current.filter((resource) => resource.name !== name));
            })
            .catch((error) => addFlash({ type: 'error', message: httpErrorToHuman(error) }));
    };

    const onCopy = (url: string) => {
        navigator.clipboard
            .writeText(url)
            .then(() => {
                setCopied(url);
                setTimeout(() => setCopied(null), 2000);
            })
            .catch(() => addFlash({ type: 'error', message: 'Failed to copy link to clipboard.' }));
    };

    return (
        <div className='p-4'>
            <FlashMessageRender />
            <div className='boxBorder bg-gray-700 rounded-box max-w-4xl mx-auto flex flex-col gap-y-4'>
                <div className='flex items-center justify-between px-6 pt-5'>
                    <div>
                        <p className='text-lg font-medium text-gray-100'>Resource Manager</p>
                        <p className='text-sm text-gray-300'>
                            Upload images and copy their public links for use across the theme.
                        </p>
                    </div>
                    <Button disabled={uploading} onClick={() => fileInputRef.current?.click()} className='relative'>
                        <div className='flex items-center gap-x-2'>
                            <LuUpload />
                            Upload Image
                        </div>
                        {uploading && (
                            <div className='absolute right-4'>
                                <Spinner size='small' />
                            </div>
                        )}
                    </Button>
                    <input
                        ref={fileInputRef}
                        type='file'
                        accept='image/png,image/jpeg,image/gif,image/webp,image/svg+xml'
                        className='hidden'
                        onChange={onFileSelected}
                    />
                </div>
                <div className='px-6 pb-6'>
                    {loading ? (
                        <Spinner size='large' centered />
                    ) : resources.length === 0 ? (
                        <p className='text-sm text-gray-400 py-6 text-center'>
                            No images uploaded yet. Upload an image to get started.
                        </p>
                    ) : (
                        <div className='grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4'>
                            {resources.map((resource) => (
                                <div
                                    key={resource.name}
                                    className='bg-gray-800 border border-gray-600 rounded-component overflow-hidden flex flex-col'
                                >
                                    <div className='h-28 bg-gray-900 flex items-center justify-center overflow-hidden'>
                                        <img
                                            src={resource.url}
                                            alt={resource.name}
                                            className='max-h-full max-w-full object-contain'
                                        />
                                    </div>
                                    <div className='p-3 flex flex-col gap-y-2'>
                                        <p className='text-xs text-gray-300 truncate' title={resource.name}>
                                            {resource.name}
                                        </p>
                                        <div className='flex gap-x-2'>
                                            <button
                                                type='button'
                                                onClick={() => onCopy(resource.url)}
                                                className='flex-1 flex items-center justify-center gap-x-1 text-xs bg-gray-700 hover:bg-gray-600 text-gray-100 rounded-component py-1.5 duration-150'
                                            >
                                                <LuCopy className='w-3.5' />
                                                {copied === resource.url ? 'Copied!' : 'Copy Link'}
                                            </button>
                                            <button
                                                type='button'
                                                onClick={() => onDelete(resource.name)}
                                                className='flex items-center justify-center text-xs bg-red-500/20 hover:bg-red-500/40 text-red-300 rounded-component py-1.5 px-2 duration-150'
                                            >
                                                <LuTrash2 className='w-3.5' />
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};
