import React, { useEffect, useState } from 'react';
import { ServerContext } from '@/state/server';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import FlashMessageRender from '@/components/FlashMessageRender';
import useFlash from '@/plugins/useFlash';
import Select from '@/components/elements/Select';
import Input from '@/components/elements/Input';
import Spinner from '@/components/elements/Spinner';
import Label from '@/components/elements/Label';
import GreyRowBox from '@/components/elements/GreyRowBox';
import Pagination from '@/components/elements/Pagination';
import TitledGreyBox from '@/components/elements/TitledGreyBox';
import { PaginatedResult } from '@/api/http';
import {
    getMinecraftForks,
    getVersions,
    getCurrentVersion,
    ForkInfo,
    VersionInfo,
} from '@/api/server/minecraft/versions';
import VersionModal from '@/components/server/minecraft/versions/VersionModal';
interface VersionItem extends VersionInfo {
    id: string;
}
export default () => {
    const { clearFlashes, clearAndAddHttpError } = useFlash();
    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);
    const [forks, setForks] = useState<Record<string, ForkInfo>>({});
    const [provider, setProvider] = useState('sponge');
    const [pageSize, setPageSize] = useState(20);
    const [search, setSearch] = useState('');
    const [filterType, setFilterType] = useState('all');
    const [page, setPage] = useState(1);
    const [versions, setVersions] = useState<PaginatedResult<VersionItem> | null>(null);
    const [currentVersion, setCurrentVersion] = useState<{ type: string; version: string; build: string } | null>(null);
    const [loading, setLoading] = useState(false);
    const [loadingForks, setLoadingForks] = useState(true);
    const [selectedVersion, setSelectedVersion] = useState<string | null>(null);
    const loadForksAndCurrent = () => {
        setLoadingForks(true);
        Promise.all([getMinecraftForks(uuid), getCurrentVersion(uuid)])
            .then(([forksData, currentData]) => {
                setForks(forksData.forks);
                if (currentData.current) {
                    setCurrentVersion(currentData.current);
                    if (currentData.current.type) {
                        const type = currentData.current.type;
                        if (forksData.forks[type]) setProvider(type);
                        else if (forksData.forks[type.toLowerCase()]) setProvider(type.toLowerCase());
                        else if (forksData.forks[type.toUpperCase()]) setProvider(type.toUpperCase());
                    }
                }
            })
            .catch((error) => console.error(error))
            .finally(() => setLoadingForks(false));
    };
    const searchVersions = () => {
        setLoading(true);
        clearFlashes('versions');
        getVersions(uuid, provider)
            .then((data) => {
                let allVersions: VersionItem[] = Object.entries(data.versions).map(([id, info]) => ({
                    id,
                    ...info,
                }));
                if (search) {
                    allVersions = allVersions.filter((v) => v.id.toLowerCase().includes(search.toLowerCase()));
                }
                if (filterType !== 'all') {
                    allVersions = allVersions.filter((v) => {
                        if (filterType === 'release') return v.type === 'RELEASE';
                        if (filterType === 'snapshot') return v.type === 'SNAPSHOT';
                        return true;
                    });
                }
                allVersions.sort((a, b) => {
                    const aMatch = a.id.match(/(\d+)(?:\.(\d+))?(?:\.(\d+))?/);
                    const bMatch = b.id.match(/(\d+)(?:\.(\d+))?(?:\.(\d+))?/);
                    if (!aMatch || !bMatch) return 0;
                    const aMajor = parseInt(aMatch[1], 10);
                    const bMajor = parseInt(bMatch[1], 10);
                    if (aMajor !== bMajor) return bMajor - aMajor;
                    const aMinor = aMatch[2] ? parseInt(aMatch[2], 10) : 0;
                    const bMinor = bMatch[2] ? parseInt(bMatch[2], 10) : 0;
                    if (aMinor !== bMinor) return bMinor - aMinor;
                    const aPatch = aMatch[3] ? parseInt(aMatch[3], 10) : 0;
                    const bPatch = bMatch[3] ? parseInt(bMatch[3], 10) : 0;
                    return bPatch - aPatch;
                });
                const total = allVersions.length;
                const totalPages = Math.ceil(total / pageSize);
                const offset = (page - 1) * pageSize;
                const pagedItems = allVersions.slice(offset, offset + pageSize);
                setVersions({
                    items: pagedItems,
                    pagination: {
                        total: total,
                        count: pagedItems.length,
                        perPage: pageSize,
                        currentPage: page,
                        totalPages: totalPages,
                    },
                });
            })
            .catch((error) => {
                clearAndAddHttpError({ key: 'versions', error });
            })
            .finally(() => setLoading(false));
    };
    const loadCurrent = () => {
        getCurrentVersion(uuid)
            .then((data) => {
                if (data.current) setCurrentVersion(data.current);
            })
            .catch(console.error);
    };
    useEffect(() => {
        loadForksAndCurrent();
    }, []);
    useEffect(() => {
        setPage(1);
    }, [provider, pageSize, search, filterType]);
    useEffect(() => {
        const delayDebounceFn = setTimeout(() => {
            searchVersions();
        }, 500);
        return () => clearTimeout(delayDebounceFn);
    }, [page, provider, pageSize, search, filterType]);
    return (
        <ServerContentBlock title={'Minecraft Version Changer'}>
            <FlashMessageRender byKey={'versions'} className={'mb-4'} />
            <div className={'flex flex-col md:flex-row gap-4 items-start'}>
                {/* Sidebar */}
                <div className={'w-full md:w-1/4 md:sticky md:top-4'}>
                    <TitledGreyBox title={'Filters'}>
                        <div className={'mb-4 relative'}>
                            <Label>Fork</Label>
                            {loadingForks ? (
                                <Spinner size='small' />
                            ) : (
                                <div className={'relative'}>
                                    <Select
                                        value={provider}
                                        onChange={(e) => setProvider(e.target.value)}
                                    >
                                        {Object.entries(forks).map(([key, fork]) => (
                                            <option key={key} value={key}>{fork.name}</option>
                                        ))}
                                    </Select>
                                </div>
                            )}
                        </div>
                        <div className={'mb-4'}>
                            <Label>Version Type</Label>
                            <Select value={filterType} onChange={(e) => setFilterType(e.target.value)}>
                                <option value='all'>All Versions</option>
                                <option value='release'>Stable</option>
                                <option value='snapshot'>Snapshot</option>
                            </Select>
                        </div>
                        <div className={'mb-4'}>
                            <Label>Page Size</Label>
                            <Select value={pageSize} onChange={(e) => setPageSize(Number(e.target.value))}>
                                <option value='10'>10</option>
                                <option value='20'>20</option>
                                <option value='50'>50</option>
                            </Select>
                        </div>
                        <div className={'mb-4'}>
                            <Label>Search</Label>
                            <Input
                                type={'text'}
                                value={search}
                                onChange={(e) => setSearch(e.target.value)}
                                placeholder={'Search versions...'}
                            />
                        </div>
                        <div>
                            <Label>Current Version</Label>
                            {!currentVersion ? (
                                <p className={'text-sm text-neutral-300 mt-1'}>Unknown version</p>
                            ) : (
                                <div className={'mt-2'}>
                                    <GreyRowBox className={'flex items-center p-3'}>
                                        {(forks[currentVersion.type]?.icon || forks[currentVersion.type.toLowerCase()]?.icon || forks[currentVersion.type.toUpperCase()]?.icon) ? (
                                            <img
                                                src={forks[currentVersion.type]?.icon || forks[currentVersion.type.toLowerCase()]?.icon || forks[currentVersion.type.toUpperCase()]?.icon || ''}
                                                className={'w-8 h-8 rounded mr-2 object-contain p-1 flex-shrink-0'}
                                                alt='icon'
                                                onError={(e) => {
                                                    e.currentTarget.style.display = 'none';
                                                }}
                                            />
                                        ) : (
                                            <div className={'w-8 h-8 rounded mr-2 bg-neutral-500 flex items-center justify-center text-xs flex-shrink-0'}>
                                                IMG
                                            </div>
                                        )}
                                        <div className={'flex-1 min-w-0'}>
                                            <div className={'text-sm font-bold truncate'}>
                                                {currentVersion.type} {currentVersion.version}
                                            </div>
                                            <div className={'text-xs text-neutral-400 truncate'}>
                                                Build: {currentVersion.build}
                                            </div>
                                        </div>
                                    </GreyRowBox>
                                </div>
                            )}
                        </div>
                    </TitledGreyBox>
                    <div className={'mt-5 flex items-center justify-center text-sm text-neutral-400'}>
                        Powered by{' '}
                        <a
                            href='https://mcjars.app'
                            target='_blank'
                            rel='noopener noreferrer'
                            className={'flex justify-center items-center hover:text-green-300 cursor-pointer ml-2'}
                        >
                            <img
                                src='https://s3.mcjars.app/icons/vanilla.png'
                                className={'w-4 h-4 mx-1'}
                                alt='MCJars'
                            />
                            MCJars
                        </a>
                    </div>
                </div>
                {/* Main Content */}
                <div className={'w-full md:w-3/4'}>
                    {!versions || (loading && !versions.items?.length) ? (
                        <div className={'w-full flex justify-center mt-8'}>
                            <Spinner size={'large'} />
                        </div>
                    ) : (
                        <Pagination data={versions} onPageSelect={setPage}>
                            {({ items }) => (
                                <div className={'grid grid-cols-1 lg:grid-cols-2 gap-4'}>
                                    {items.map((version) => (
                                        <GreyRowBox
                                            key={version.id}
                                            className={
                                                'hover:bg-neutral-600 transition-colors duration-150 flex flex-col h-full items-start p-4 border border-transparent hover:border-neutral-500 cursor-pointer'
                                            }
                                            onClick={() => setSelectedVersion(version.id)}
                                        >
                                            <div className={'flex items-center w-full'}>
                                                {forks[provider]?.icon ? (
                                                    <img
                                                        src={forks[provider].icon}
                                                        alt={provider}
                                                        className={
                                                            'w-12 h-12 rounded mr-3 object-contain p-1 bg-neutral-800 flex-shrink-0'
                                                        }
                                                        onError={(e) => {
                                                            e.currentTarget.style.display = 'none';
                                                        }}
                                                    />
                                                ) : (
                                                    <div
                                                        className={
                                                            'w-12 h-12 rounded mr-3 bg-neutral-600 flex items-center justify-center text-neutral-400 font-bold text-xs flex-shrink-0'
                                                        }
                                                    >
                                                        VER
                                                    </div>
                                                )}
                                                <div className={'flex-1 min-w-0'}>
                                                    <p className={'text-base text-neutral-100 line-clamp-1'}>
                                                        Version {version.id}
                                                    </p>
                                                    <p
                                                        className={`text-xs line-clamp-1 mt-auto ${version.type === 'SNAPSHOT'
                                                            ? 'text-red-400'
                                                            : 'text-neutral-200'
                                                            }`}
                                                    >
                                                        {version.type} • {version.builds} Builds
                                                    </p>
                                                </div>
                                            </div>
                                        </GreyRowBox>
                                    ))}
                                    {items.length === 0 && (
                                        <GreyRowBox className={'col-span-2 justify-center text-neutral-400 p-8'}>
                                            No versions found matching your criteria.
                                        </GreyRowBox>
                                    )}
                                </div>
                            )}
                        </Pagination>
                    )}
                </div>
            </div>
            <VersionModal
                version={selectedVersion}
                fork={provider}
                onDismissed={() => setSelectedVersion(null)}
                onInstalled={() => {
                    setSelectedVersion(null);
                    loadCurrent();
                }}
            />
        </ServerContentBlock>
    );
};
